/// < reference types = "cypress"/>

describe('1st Assignment', () => 
{

  beforeEach(() => {
    cy.visit('https://auth.testproject.io/auth/realms/TP/protocol/openid-connect/auth?client_id=tp.app&redirect_uri=https%3A%2F%2Fapp.testproject.io%2Fcallback.html&response_type=id_token%20token&scope=openid%20profile&state=bc4c3103db4243acbb4bc2e79a63aaef&nonce=fad45a1aa40347859944e665dea2f7b4')
  })

    
    it('Valid Credentials', () => 
    {
    cy.get("#username").type('usman.allaudin@gmail.com')
    cy.get("#password").type('Khoobsoorat9876')
    cy.wait(4000)
    cy.get("#tp-sign-in").click()
    cy.wait(4000)
    cy.title().should('be.eq', 'TestProject')
})


    
    it('InValid Credentials', () => 
    {
    cy.get("#username").type('usman.allaufdin@gmail.com')
    cy.get("#password").type('Khoobsoorat9876')
    cy.wait(4000)
    cy.get("#tp-sign-in").click()
    cy.wait(4000)
    cy.title().should('be.eq', 'TestProject')
})
   

it('Empty fields', () => 
    {
    cy.get("#username")
    cy.get("#password")
    cy.wait(4000)
    cy.get("#tp-sign-in").click()
    cy.title().should('be.eq', 'TestProject')
})



  })

 //node_modules\.bin\cypress open
 //node_modules\.bin\cypress run