//<reference types = "cypress"/>


describe('3rd_Assignment', () => 
{
  beforeEach(() => {
    cy.visit('http://testautomationpractice.blogspot.com')
  })

    it('finds the value in all over the table', () => 
    {
    cy.get("table[name=BookTable]").contains('td','JAVA').should('be.visible') // finds the value in all overthe table
    })


    it('finds the value on a specific place', () => 
    {
    cy.get("#HTML1 > div.widget-content > table > tbody > tr:nth-child(7) > td:nth-child(3)").contains('Javascript').should('be.visible') // finds the value on a specific place
    })


    
  })

