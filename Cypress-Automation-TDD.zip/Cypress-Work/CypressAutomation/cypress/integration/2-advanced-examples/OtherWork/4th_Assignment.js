/// < reference types = "cypress"/>


describe('4th Assignment Hooks', () => 
{

    beforeEach(() => {
      cy.visit('https://auth.testproject.io/auth/realms/TP/protocol/openid-connect/auth?client_id=tp.app&redirect_uri=https%3A%2F%2Fapp.testproject.io%2Fcallback.html&response_type=id_token%20token&scope=openid%20profile&state=bc4c3103db4243acbb4bc2e79a63aaef&nonce=fad45a1aa40347859944e665dea2f7b4')
      cy.get("#username").type('usman.allaudin@gmail.com')
      cy.get("#password").type('Khoobsoorat9876')
      cy.wait(4000)
      cy.get("#tp-sign-in").click()
      cy.wait(50000)
      })

    it('Hooks Test 1st', () => 
    {
      cy.get("#mCSB_3_container > welcome-to-test-project-v2 > div > wtt-on-boarding-v2 > div > div.ob-v2-content > div > tp-mbw-dynamic-template > div > wtt-step-agent-v2 > div > div.sa-column.left > div.sa-column-content > div > div:nth-child(3) > div > div > div.action-button.finish").click()

    })

    it('Hooks Test 1st', () => 
    {
      cy.get("#mCSB_3_container > welcome-to-test-project-v2 > div > wtt-on-boarding-v2 > div > div.ob-v2-content > div > tp-mbw-dynamic-template > div > wtt-step-agent-v2 > div > div.sa-column.left > div.sa-column-content > div > div:nth-child(3) > div > div > div.action-button.finish").click()

    })

  })

 //node_modules\.bin\cypress open
 //node_modules\.bin\cypress run


