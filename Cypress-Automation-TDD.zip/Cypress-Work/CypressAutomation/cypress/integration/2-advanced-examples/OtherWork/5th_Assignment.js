//< reference types = "cypress"/>


describe('5th Assignment Custom Commands Data driven', function()
{

    

    it('Custom Command data driven 1st test valid credentials', function() 
    {
    cy.login('usman.allaudin@gmail.com', 'Khoobsoorat9876')
    cy.title().should('be.eq', 'TestProject')

    })


    it('Custom Command data driven 2nd test invalid credentials', function() 
    {
    cy.login('usman.allaudfin@gmail.com', 'Khoobsoorat9876')
    cy.title().should('not.be.eq', 'TestProject')

    })
})

 //node_modules\.bin\cypress open
 //node_modules\.bin\cypress run


