///< reference types = "cypress"/>


describe('MyTestSuit', () => 
{
    it('1st Test Verify Forward and backward navigation', () => 
    {

    cy.visit('https://testproject.io/')
    cy.wait(4000)
    cy.get("#wpcf7-f3838-o1 > form > div.home-hero-contact-form > span.wpcf7-form-control-wrap.your-email > input").type('usmaann10@gmail.com')
    cy.wait(4000)
    //cy.contains('Create an Account').click()
    cy.get("#wpcf7-f3838-o1 > form > div.home-hero-contact-form > input").click()

    })
  })

 //node_modules\.bin\cypress open
 //node_modules\.bin\cypress run