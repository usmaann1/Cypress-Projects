< reference types = "cypress"/>


describe('MyFirstTest', () => 
{
    it('1st Test Verify Title of the Page', () => 
    {

    cy.visit('https://www.daraz.pk/')
    cy.title().should('eq', 'Online Shopping in Pakistan: Fashion, Electronics & Books - Daraz.pk')

    })
  })

 //node_modules\.bin\cypress open
 //node_modules\.bin\cypress run


