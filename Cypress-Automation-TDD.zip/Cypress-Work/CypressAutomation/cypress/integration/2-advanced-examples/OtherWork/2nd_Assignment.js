//<reference types = "cypress"/>


describe('2nd Assignment', () => 
{
    it('2nd Assignment to Verify Forward and backward navigation in Browser', () => 
    {

    cy.visit('https://www.freshworks.com/')
    cy.get("body > header > nav > div > div > ul > li:nth-child(5) > a").click()
    cy.wait(4000)
    cy.go('back')
    cy.wait(4000)
    cy.go('forward')

    })
  })

