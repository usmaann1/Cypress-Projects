
//< reference types = "cypress"/>

import loginPage from '../PageObjects/LoginPage'

describe('6th Assignment POM', function()
{

    it('POM 1st Test case', function() 
    {
      const lp = new loginPage  //How can i run all defined functions without calling every single functio name
      //lp.loginPage
      lp.visit()
      lp.fillemail('usman.allaudin@gmail.com')
      lp.fillpassword('Khoobsoorat9876')
      lp.clickonsubmit()
   
    })
})

 //node_modules\.bin\cypress open
 //node_modules\.bin\cypress run


