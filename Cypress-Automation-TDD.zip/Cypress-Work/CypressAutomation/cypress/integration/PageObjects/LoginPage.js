
class loginPage
{

visit()
{
cy.visit('https://auth.testproject.io/auth/realms/TP/protocol/openid-connect/auth?client_id=tp.app&redirect_uri=https%3A%2F%2Fapp.testproject.io%2Fcallback.html&response_type=id_token%20token&scope=openid%20profile&state=2bf091774eba4c9a88273294b37b0926&nonce=a12462fc969d4e54999d2261b9f13924')
}

fillemail(value)
{
    const un = cy.get("#username")
    un.clear()
    un.type(value)
}

fillpassword(value)
{
    const un = cy.get("#password")
    un.clear()
    un.type(value)
}

clickonsubmit()
{
    const un = cy.get("#tp-sign-in")
    un.click()
}

}
export default loginPage