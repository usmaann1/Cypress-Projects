/// <reference types = "Cypress"  />


import CSS_Selecters from './Selecters'
import 'cypress-iframe'
const selector = new CSS_Selecters()



//cy.contains(/Sunny Side Up SPF 30 Mist|Cloud Factory Cleansert/)   
//if we want to use OR betwen 2 products
class Assessment_Methods{


testcase1()
{
    selector.assessment_apis()              //inculuded assessment/result/answer's api's 
    selector.elements.gender_male().click() //gender selection
    cy.wait('@answerapi')
    cy.wait('@agequestionapi')
     

    selector.elementsquestions.age()
    selector.elements.age_any().click()   //age selection
    cy.wait('@answerapi')
    cy.wait('@cheeksapi')

     
    selector.elementsquestions.cheeksinthemorning()
    selector.elements.cheeks_morning_verydry().click()  //cheeks selection
    cy.wait('@answerapi')
    cy.wait('@tzoneapi')

     
    selector.elementsquestions.tzone()
    selector.elements.tzone_verydry().click()   //tzone selection
    cy.wait('@answerapi')
    cy.wait('@skinconcernapi')

     
    selector.elementsquestions.top2skinconcerns()
    selector.elements.top2_skin_concerns_wrinkles().click()  //skin concerns selection
     
    selector.elements.continue_btn().click()    //continue button
    cy.wait('@answerapi')
    cy.wait('@skinshadeapi')
     

    selector.elementsquestions.skinshade()
    selector.elements.skishade_2nd().click()     //skin shade selection
    cy.wait('@answerapi')
    cy.wait('@reactionapi')
     

    selector.elementsquestions.skinreaction()
    selector.elements.skinReactions_yes().click()   //skin reaction selection
    cy.wait('@answerapi')
    cy.wait('@ingredientapi')
     

    selector.elementsquestions.ingredients()
    selector.elements.ingredients_retinol().click()    //ingredients selection
    selector.elements.continue_btn().click()    //continue button
    cy.wait('@answerapi')
    cy.wait('@stressapi')
     
    
    selector.elementsquestions.stress()
    selector.elements.little_stress().click()    // stress selection
    cy.wait('@answerapi')
    cy.wait('@sleepapi')
     

    selector.elementsquestions.sleep()
    selector.elements.sleep_5to6().click()   //sleep selection
    cy.wait('@answerapi')
    cy.wait('@waterapi')
     

    selector.elementsquestions.waterconsumption()
    selector.elements.water_consumption().click()    //water consumption selection
    cy.wait('@answerapi')
    cy.wait('@spenddayapi')
     

    selector.elementsquestions.dayspend()
    selector.elements.indoors_wtoutAC().click()     //environment selection
    cy.wait('@answerapi')
    cy.wait('@lifestyleapi')
     

    selector.elementsquestions.lifestylepart()
    selector.elements.lifestyle_regular_workout().click()   //lifestyle selection
    selector.elements.continue_btn().click()     //continue button
    cy.wait('@answerapi')
    cy.wait('@makeupapi')
     

    selector.elementsquestions.makeup()
    selector.elements.wear_makeup_occasionally().click()    //makeup wearing selection
    cy.wait('@answerapi')
    cy.wait('@smokeapi')
     

    selector.elementsquestions.smoke()
    selector.elements.smoke_occasionally().click()      //smoking selection
    cy.wait('@answerapi')
    cy.wait('@productpreferenceapi')
      

    selector.elementsquestions.productpreference()
    selector.elements.product_preference_vegan().click()      //product preference selection
    selector.elements.continue_btn().click()    //continue button
    cy.wait('@answerapi')
     

    selector.elements.staying_month_textbox().clear().type('Lahore')     //click on text box
    selector.genericwait()
    selector.elements.city_selection().click()         //city selection from dropdown
    selector.genericwait()
    selector.elements.continue_btn().click()     //continue bbutton
    cy.wait('@>20weatherapi')
    

    selector.elements.continue_btn().click()     //continue button
    cy.wait('@mp4videoapi')
    

    selector.elements.skipto_results_btn().click()      // skip to results button
    cy.wait('@resultpage')
    cy.wait('@resultonproductpage')
    
    
    selector.producttype.dayserum().should('exist')           //verifing the product type
    selector.producttype.nightserum().should('exist')          //verifing the product type
    selector.producttype.moisturiser().should('exist')         //verifing the product type
    //selector.producttype.nightcream().should('exist')           //verifing the product type
    selector.genericwait()


    selector.elements.add_day_night_set().click()               //add product set button
    cy.wait('@addsetbtnapi')


    selector.elements.product_btn().click()                    //product button
    cy.wait('@resultonproductpage')
    

    selector.productname.daydropoflight().should('exist')            //verifing the day serum
    selector.productname.nightdropofsoftness().should('exist')       //verifing the night serum
    selector.productname.crazyrichmoisturiser().should('exist')   //verifing the day cream
    //selector.productname.dndnights().should('exist')              //verifing the night cream
    cy.wait(2000)

}



testcase2()
{
    selector.assessment_apis()              //inculuded assessment/result/answer's api's
    selector.elements.gender_male().click() //gender selection
    cy.wait('@answerapi')
    cy.wait('@agequestionapi')

    selector.elementsquestions.age()
    selector.elements.age_any().click()   //age selection
    cy.wait('@answerapi')
    cy.wait('@cheeksapi')

    selector.elementsquestions.cheeksinthemorning()
    selector.elements.cheeks_morning_verydry().click()  //cheeks selection
    cy.wait('@answerapi')
    cy.wait('@tzoneapi')
    
    selector.elementsquestions.tzone()
    selector.elements.tzone_dry().click()   //tzone selection
    cy.wait('@answerapi')
    cy.wait('@skinconcernapi')

    selector.elementsquestions.top2skinconcerns()
    selector.elements.top2_skin_concerns_wrinkles().click()  //skin concerns selection
    selector.elements.continue_btn().click()                 //continue button
    cy.wait('@answerapi')
    cy.wait('@skinshadeapi')
    
    
    selector.elementsquestions.skinshade()
    selector.elements.skishade_2nd().click()     //skin shade selection
    cy.wait('@answerapi')
    cy.wait('@reactionapi')

    selector.elementsquestions.skinreaction()
    selector.elements.skinReactions_no().click()   //skin reaction selection
    cy.wait('@answerapi')
    cy.wait('@stressapi')

    selector.elementsquestions.stress()
    selector.elements.little_stress().click()    // stress selection
    cy.wait('@answerapi')
    cy.wait('@sleepapi')

    selector.elementsquestions.sleep()
    selector.elements.sleep_5to6().click()   //sleep selection
    cy.wait('@answerapi')
    cy.wait('@waterapi')

    selector.elementsquestions.waterconsumption()
    selector.elements.water_consumption().click()    //water consumption selection
    cy.wait('@answerapi')
    cy.wait('@spenddayapi')

    selector.elementsquestions.dayspend()
    selector.elements.indoors_wtoutAC().click()     //environment selection
    cy.wait('@answerapi')
    cy.wait('@lifestyleapi')

    selector.elementsquestions.lifestylepart()
    selector.elements.lifestyle_regular_workout().click()   //lifestyle selection
    selector.elements.continue_btn().click()               //continue button
    cy.wait('@answerapi')
    cy.wait('@makeupapi')

    selector.elementsquestions.makeup()
    selector.elements.wear_makeup_occasionally().click()    //makeup wearing selection
    cy.wait('@answerapi')
    cy.wait('@smokeapi')

    selector.elementsquestions.smoke()
    selector.elements.smoke_occasionally().click()      //smoking selection
    cy.wait('@answerapi')
    cy.wait('@productpreferenceapi')

    selector.elementsquestions.productpreference()
    selector.elements.product_preference_pregnancysafe().click()      //product preference selection
    selector.elements.continue_btn().click()                    //continue button
    
    
    selector.elements.staying_month_textbox().clear().type('Lahore')     //click on text box
    selector.genericwait()
    selector.elements.city_selection().click()         //city selection from dropdown
    selector.genericwait()
    selector.elements.continue_btn().click()     //continue bbutton
    cy.wait('@>20weatherapi')

    selector.elements.continue_btn().click()     //continue button
    cy.wait('@mp4videoapi')

    selector.elements.skipto_results_btn().click()      // skip to results button
    cy.wait('@resultpage')
    cy.wait('@resultonproductpage')

    selector.producttype.dayserum().should('exist')           //verifing the product type
    selector.producttype.nightserum().should('exist')          //verifing the product type
    selector.producttype.moisturiser().should('exist')         //verifing the product type
    //selector.producttype.nightcream().should('exist')           //verifing the product type

     
    selector.elements.add_day_night_set().click()               //add product set button
    cy.wait('@addsetbtnapi')


    selector.genericwait()
    selector.elements.product_btn().click()                    //product button
    cy.wait('@resultonproductpage')
     

    selector.productname.daydropoflight().should('exist')            //verifing the day serum
    selector.productname.nightdropofsoftness().should('exist')        //verifing the night serum
    selector.productname.crazyrichmoisturiser().should('exist')   //verifing the day cream
    //selector.productname.milkyway().should('exist')              //verifing the night cream
    
    cy.wait(3000)

}




testcase3()
{
    selector.assessment_apis()              //inculuded assessment/result/answer's api's
    selector.elements.gender_male().click() //gender selection
    cy.wait('@answerapi')
    cy.wait('@agequestionapi')
    
    selector.elementsquestions.age()
    selector.elementsquestions.age()
    selector.elements.age_any().click()   //age selection
    cy.wait('@answerapi')
    cy.wait('@cheeksapi')

    selector.elementsquestions.cheeksinthemorning()
    selector.elements.cheeks_morning_verydry().click()  //cheeks selection
    cy.wait('@answerapi')
    cy.wait('@tzoneapi')

    selector.elementsquestions.tzone()
    selector.elements.tzone_dry().click()   //tzone selection
    cy.wait('@answerapi')
    cy.wait('@skinconcernapi')

    selector.elementsquestions.top2skinconcerns()
    selector.elements.top2_skin_concerns_wrinkles().click()  //skin concerns selection
    selector.elements.continue_btn().click()    //continue button
    cy.wait('@answerapi')
    cy.wait('@skinshadeapi')

    selector.elementsquestions.skinshade()
    selector.elements.skishade_2nd().click()     //skin shade selection
    cy.wait('@answerapi')
    cy.wait('@reactionapi')

    selector.elementsquestions.skinreaction()
    selector.elements.skinReactions_no().click()   //skin reaction selection
    cy.wait('@answerapi')
    cy.wait('@stressapi')

    selector.elementsquestions.stress()
    selector.elements.little_stress().click()    // stress selection
    cy.wait('@answerapi')
    cy.wait('@sleepapi')

    selector.elementsquestions.sleep()
    selector.elements.sleep_5to6().click()   //sleep selection
    cy.wait('@answerapi')
    cy.wait('@waterapi')

    selector.elementsquestions.waterconsumption()
    selector.elements.water_consumption().click()    //water consumption selection
    cy.wait('@answerapi')
    cy.wait('@spenddayapi')

    selector.elementsquestions.dayspend()
    selector.elements.indoors_wtoutAC().click()     //environment selection
    cy.wait('@answerapi')
    cy.wait('@lifestyleapi')

    selector.elementsquestions.lifestylepart()
    selector.elements.lifestyle_regular_workout().click()   //lifestyle selection
    selector.elements.continue_btn().click()               //continue button
    cy.wait('@answerapi')
    cy.wait('@makeupapi')

    selector.elementsquestions.makeup()
    selector.elements.wear_makeup_occasionally().click()    //makeup wearing selection
    cy.wait('@answerapi')
    cy.wait('@smokeapi')

    selector.elementsquestions.smoke()
    selector.elements.smoke_occasionally().click()          //smoking selection
    cy.wait('@answerapi')
    cy.wait('@productpreferenceapi')

    selector.elementsquestions.productpreference()
    selector.elements.product_preference_vegan().click()      //product preference selection
    selector.elements.continue_btn().click()                  //continue button
    cy.wait('@answerapi')

    selector.elements.staying_month_textbox().clear().type('Lahore')     //click on text box
    selector.genericwait()
    selector.elements.city_selection().click()         //city selection from dropdown
    selector.genericwait()
    selector.elements.continue_btn().click()     //continue bbutton
    cy.wait('@>20weatherapi')
    selector.elements.continue_btn().click()     //continue button
    cy.wait('@mp4videoapi')

    selector.elements.skipto_results_btn().click()      // skip to results button
    cy.wait('@resultpage')
    cy.wait('@resultonproductpage')

    selector.producttype.dayserum().should('exist')           //verifing the product type
    selector.producttype.nightserum().should('exist')          //verifing the product type
    selector.producttype.moisturiser().should('exist')         //verifing the product type
    //selector.producttype.nightcream().should('exist')           //verifing the product type
    selector.genericwait()


    selector.elements.add_day_night_set().click()               //add product set button
    cy.wait('@addsetbtnapi')


    selector.elements.product_btn().click()                    //product button
    cy.wait('@resultonproductpage')
     

    selector.productname.daydropoflight().should('exist')            //verifing the day serum
    selector.productname.nightdropofsoftness().should('exist')       //verifing the night serum
    selector.productname.crazyrichmoisturiser().should('exist')   //verifing the day cream
    //selector.productname.dndnights().should('exist')              //verifing the night cream
    cy.wait(3000)
}




testcase4()
{
    selector.assessment_apis()              //inculuded assessment/result/answer's api's
    selector.elements.gender_male().click() //gender selection
    cy.wait('@answerapi')
    cy.wait('@agequestionapi')

    selector.elementsquestions.age()
    selector.elements.age_any().click()   //age selection
    cy.wait('@answerapi')
    cy.wait('@cheeksapi')

    selector.elementsquestions.cheeksinthemorning()
    selector.elements.cheeks_morning_verydry().click()  //cheeks selection
    cy.wait('@answerapi')
    cy.wait('@tzoneapi')

    selector.elementsquestions.tzone()
    selector.elements.tzone_normal().click()   //tzone selection
    cy.wait('@answerapi')
    cy.wait('@skinconcernapi')

    selector.elementsquestions.top2skinconcerns()
    selector.elements.top2_skin_concerns_wrinkles().click()  //skin concerns selection
    selector.elements.continue_btn().click()    //continue button
    cy.wait('@answerapi')
    cy.wait('@skinshadeapi')

    selector.elementsquestions.skinshade()
    selector.elements.skishade_2nd().click()     //skin shade selection
    cy.wait('@answerapi')
    cy.wait('@reactionapi')
    
    selector.elementsquestions.skinreaction()
    selector.elements.skinReactions_yes().click()   //skin reaction selection
    cy.wait('@answerapi')
    cy.wait('@ingredientapi')

    selector.elementsquestions.ingredients()
    selector.elements.ingredients_salicylicacid().click()    //ingredients selection
    selector.elements.continue_btn().click()           //continue button
    cy.wait('@answerapi')
    cy.wait('@stressapi')
    
    selector.elementsquestions.stress()
    selector.elements.little_stress().click()    // stress selection
    cy.wait('@answerapi')
    cy.wait('@sleepapi')
    
    selector.elementsquestions.sleep()
    selector.elements.sleep_5to6().click()   //sleep selection
    cy.wait('@answerapi')
    cy.wait('@waterapi')
    
    selector.elementsquestions.waterconsumption()
    selector.elements.water_consumption().click()    //water consumption selection
    cy.wait('@answerapi')
    cy.wait('@spenddayapi')
    
    selector.elementsquestions.dayspend()
    selector.elements.indoors_wtoutAC().click()     //environment selection
    cy.wait('@answerapi')
    cy.wait('@lifestyleapi')
    
    selector.elementsquestions.lifestylepart()
    selector.elements.lifestyle_regular_workout().click()   //lifestyle selection
    selector.elements.continue_btn().click()               //continue button
    cy.wait('@answerapi')
    cy.wait('@makeupapi')
    
    selector.elementsquestions.makeup()
    selector.elements.wear_makeup_occasionally().click()    //makeup wearing selection
    cy.wait('@answerapi')
    cy.wait('@smokeapi')
    
    selector.elementsquestions.smoke()
    selector.elements.smoke_occasionally().click()          //smoking selection
    cy.wait('@answerapi')
    cy.wait('@productpreferenceapi') 

    selector.elementsquestions.productpreference()
    selector.elements.product_preference_none().click()      //product preference selection
    cy.wait('@answerapi')
    
    selector.elements.staying_month_textbox().clear().type('Lahore')     //click on text box
    selector.genericwait()
    selector.elements.city_selection().click()         //city selection from dropdown
    selector.genericwait()
    selector.elements.continue_btn().click()     //continue bbutton
    cy.wait('@>20weatherapi')
    selector.elements.continue_btn().click()     //continue button
    cy.wait('@mp4videoapi')

    selector.elements.skipto_results_btn().click()      // skip to results button
    cy.wait('@resultpage')
    cy.wait('@resultonproductpage')
    
    selector.producttype.dayserum().should('exist')           //verifing the product type
    selector.producttype.nightserum().should('exist')          //verifing the product type
    selector.producttype.moisturiser().should('exist')         //verifing the product type
    //selector.producttype.nightcream().should('exist')           //verifing the product type
    selector.genericwait()

    
    selector.elements.add_day_night_set().click()               //add product set button
    cy.wait('@addsetbtnapi')
    
    selector.elements.product_btn().click()                    //product button
    cy.wait('@resultonproductpage')
     

    selector.productname.daydropoflight().should('exist')            //verifing the day serum
    selector.productname.dropofyouth().should('exist')              //verifing the night serum
    selector.productname.crazyrichmoisturiser().should('exist')   //verifing the day cream
    //selector.productname.dndnights().should('exist')              //verifing the night cream
    cy.wait(3000)

}





testcase5()
{
    selector.assessment_apis()              //inculuded assessment/result/answer's api's
    selector.elements.gender_male().click() //gender selection
    cy.wait('@answerapi')
    cy.wait('@agequestionapi')
    
    selector.elementsquestions.age()
    selector.elements.age_any().click()   //age selection
    cy.wait('@answerapi')
    cy.wait('@cheeksapi')
    
    selector.elementsquestions.cheeksinthemorning()
    selector.elements.cheeks_morning_verydry().click()  //cheeks selection
    cy.wait('@answerapi')
    cy.wait('@tzoneapi')
    
    selector.elementsquestions.tzone()
    selector.elements.tzone_normal().click()   //tzone selection
    cy.wait('@answerapi')
    cy.wait('@skinconcernapi')

    selector.elementsquestions.top2skinconcerns()
    selector.elements.top2_skin_concerns_wrinkles().click()  //skin concerns selection
    selector.elements.continue_btn().click()               //continue button
    cy.wait('@answerapi')
    cy.wait('@skinshadeapi')

    selector.elementsquestions.skinshade()
    selector.elements.skishade_2nd().click()     //skin shade selection
    cy.wait('@answerapi')
    cy.wait('@reactionapi')

    selector.elementsquestions.skinreaction()
    selector.elements.skinReactions_yes().click()   //skin reaction selection
    cy.wait('@answerapi')
    cy.wait('@ingredientapi')

    selector.elementsquestions.ingredients()
    selector.elements.ingredients_salicylicacid().click()    //ingredients selection
    selector.elements.continue_btn().click()           //continue button
    cy.wait('@answerapi')
    cy.wait('@stressapi')

    selector.elementsquestions.stress()
    selector.elements.little_stress().click()    // stress selection
    cy.wait('@answerapi')
    cy.wait('@sleepapi')

    selector.elementsquestions.sleep()
    selector.elements.sleep_5to6().click()   //sleep selection
    cy.wait('@answerapi')
    cy.wait('@waterapi')

    selector.elementsquestions.waterconsumption()
    selector.elements.water_consumption().click()    //water consumption selection
    cy.wait('@answerapi')
    cy.wait('@spenddayapi')

    selector.elementsquestions.dayspend()
    selector.elements.indoors_wtoutAC().click()     //environment selection
    cy.wait('@answerapi')
    cy.wait('@lifestyleapi')

    selector.elementsquestions.lifestylepart()
    selector.elements.lifestyle_regular_workout().click()   //lifestyle selection
    selector.elements.continue_btn().click()               //continue button
    cy.wait('@answerapi')
    cy.wait('@makeupapi')
    
    selector.elementsquestions.makeup()
    selector.elements.wear_makeup_occasionally().click()    //makeup wearing selection
    cy.wait('@answerapi')
    cy.wait('@smokeapi')

    selector.elementsquestions.smoke()
    selector.elements.smoke_occasionally().click()          //smoking selection
    cy.wait('@answerapi')
    cy.wait('@productpreferenceapi') 

    selector.elementsquestions.productpreference()
    selector.elements.product_preference_pregnancysafe().click()      //product preference selection
    selector.elements.continue_btn().click()             //continue button

    selector.elements.staying_month_textbox().clear().type('Lahore')     //click on text box
    selector.genericwait()
    selector.elements.city_selection().click()         //city selection from dropdown
    selector.genericwait()
    selector.elements.continue_btn().click()     //continue bbutton
    cy.wait('@>20weatherapi')
    selector.elements.continue_btn().click()     //continue button
    cy.wait('@mp4videoapi')

    selector.elements.skipto_results_btn().click()      // skip to results button
    cy.wait('@resultpage')
    cy.wait('@resultonproductpage')
    
    selector.producttype.dayserum().should('exist')           //verifing the product type
    selector.producttype.nightserum().should('exist')          //verifing the product type
    selector.producttype.moisturiser().should('exist')         //verifing the product type
    //selector.producttype.nightcream().should('exist')           //verifing the product type
    selector.genericwait()


    selector.elements.add_day_night_set().click()               //add product set button
    cy.wait('@addsetbtnapi')


    selector.elements.product_btn().click()                    //product button
    cy.wait('@resultonproductpage')
     

    selector.productname.daydropoflight().should('exist')            //verifing the day serum
    selector.productname.crazyrichmoisturiser().should('exist')   //verifing the day cream
    selector.productname.nightdropofsoftness().should('exist')         //verifing the night serum
    //selector.productname.milkyway().should('exist')              //verifing the night cream
    cy.wait(3000)

}




testcase6()
{
    selector.assessment_apis()              //inculuded assessment/result/answer's api's
    selector.elements.gender_male().click() //gender selection
    cy.wait('@answerapi')
    cy.wait('@agequestionapi')

    selector.elementsquestions.age()
    selector.elements.age_any().click()   //age selection
    cy.wait('@answerapi')
    cy.wait('@cheeksapi')

    selector.elementsquestions.cheeksinthemorning()
    selector.elements.cheeks_morning_verydry().click()  //cheeks selection
    cy.wait('@answerapi')
    cy.wait('@tzoneapi')

    selector.elementsquestions.tzone()
    selector.elements.tzone_normal().click()   //tzone selection
    cy.wait('@answerapi')
    cy.wait('@skinconcernapi')

    selector.elementsquestions.top2skinconcerns()
    selector.elements.top2_skin_concerns_wrinkles().click()  //skin concerns selection
    selector.elements.continue_btn().click()    //continue button
    cy.wait('@answerapi')
    cy.wait('@skinshadeapi')
   
    selector.elementsquestions.skinshade()
    selector.elements.skishade_2nd().click()     //skin shade selection
    cy.wait('@answerapi')
    cy.wait('@reactionapi')

    selector.elementsquestions.skinreaction()
    selector.elements.skinReactions_yes().click()   //skin reaction selection
    cy.wait('@answerapi')
    cy.wait('@ingredientapi')

    selector.elementsquestions.ingredients()
    selector.elements.ingredients_salicylicacid().click()    //ingredients selection
    selector.elements.continue_btn().click()           //continue button
    cy.wait('@answerapi')
    cy.wait('@stressapi')

    selector.elementsquestions.stress()
    selector.elements.little_stress().click()    // stress selection
    cy.wait('@answerapi')
    cy.wait('@sleepapi')

    selector.elementsquestions.sleep()
    selector.elements.sleep_5to6().click()   //sleep selection
    cy.wait('@answerapi')
    cy.wait('@waterapi')

    selector.elementsquestions.waterconsumption()
    selector.elements.water_consumption().click()    //water consumption selection
    cy.wait('@answerapi')
    cy.wait('@spenddayapi')

    selector.elementsquestions.dayspend()
    selector.elements.indoors_wtoutAC().click()     //environment selection
    cy.wait('@answerapi')
    cy.wait('@lifestyleapi')

    selector.elementsquestions.lifestylepart()
    selector.elements.lifestyle_regular_workout().click()   //lifestyle selection
    selector.elements.continue_btn().click()               //continue button
    cy.wait('@answerapi')
    cy.wait('@makeupapi')
    
    selector.elementsquestions.makeup()
    selector.elements.wear_makeup_occasionally().click()    //makeup wearing selection
    cy.wait('@answerapi')
    cy.wait('@smokeapi')

    selector.elementsquestions.smoke()
    selector.elements.smoke_occasionally().click()          //smoking selection
    cy.wait('@answerapi')
    cy.wait('@productpreferenceapi') 

    selector.elementsquestions.productpreference()
    selector.elements.product_preference_vegan().click()      //product preference selection
    selector.elements.continue_btn().click()                //continue bbutton
    cy.wait('@answerapi')

    selector.elements.staying_month_textbox().clear().type('Lahore')     //click on text box
    selector.genericwait()
    selector.elements.city_selection().click()         //city selection from dropdown
    selector.genericwait()
    selector.elements.continue_btn().click()     //continue bbutton
    cy.wait('@>20weatherapi')
    selector.elements.continue_btn().click()     //continue button
    cy.wait('@mp4videoapi')

    selector.elements.skipto_results_btn().click()      // skip to results button
    cy.wait('@resultpage')
    cy.wait('@resultonproductpage')
    
    selector.producttype.dayserum().should('exist')           //verifing the product type
    selector.producttype.nightserum().should('exist')          //verifing the product type
    selector.producttype.moisturiser().should('exist')         //verifing the product type
    //selector.producttype.nightcream().should('exist')           //verifing the product type
    selector.genericwait()

    selector.elements.add_day_night_set().click()               //add product set button
    cy.wait('@addsetbtnapi')

    selector.elements.product_btn().click()                    //product button
    cy.wait('@resultonproductpage')
 
    selector.productname.daydropoflight().should('exist')           //verifing the day serum
    selector.productname.crazyrichmoisturiser().should('exist')   //verifing the day cream
    selector.productname.nightdropofsoftness().should('exist')    //verifing the night serum
    //selector.productname.dndnights().should('exist')              //verifing the night cream
    cy.wait(3000)

}



testcase7()
{
    selector.assessment_apis()              //inculuded assessment/result/answer's api's
    selector.elements.gender_male().click() //gender selection
    cy.wait('@answerapi')
    cy.wait('@agequestionapi')

    selector.elementsquestions.age()
    selector.elements.age_any().click()   //age selection
    cy.wait('@answerapi')
    cy.wait('@cheeksapi')

    selector.elementsquestions.cheeksinthemorning()
    selector.elements.cheeks_morning_verydry().click()  //cheeks selection
    cy.wait('@answerapi')
    cy.wait('@tzoneapi')

    selector.elementsquestions.tzone()
    selector.elements.tzone_oily().click()   //tzone selection
    cy.wait('@answerapi')
    cy.wait('@skinconcernapi')

    selector.elementsquestions.top2skinconcerns()
    selector.elements.top2_skin_concerns_wrinkles().click()  //skin concerns selection  1
    selector.elements.top2_skin_concerns_redness().click()  //skin concerns selection   2
    cy.wait('@answerapi')
    cy.wait('@levelofrednessapi')
    
    selector.elementsquestions.levelofredness()
    selector.elements.levelofredness_mild().click()  //level of redness
    cy.wait('@answerapi')
    cy.wait('@skinshadeapi')

    selector.elementsquestions.skinshade()
    selector.elements.skishade_2nd().click()     //skin shade selection
    cy.wait('@answerapi')
    cy.wait('@reactionapi')

    selector.elementsquestions.skinreaction()
    selector.elements.skinReactions_yes().click()   //skin reaction selection
    cy.wait('@answerapi')
    cy.wait('@ingredientapi')

    selector.elementsquestions.ingredients()
    selector.elements.ingredients_retinol().click()    //ingredients selection
    selector.elements.continue_btn().click()    //continue button
    cy.wait('@answerapi')
    cy.wait('@stressapi')
    
    selector.elementsquestions.stress()
    selector.elements.little_stress().click()    // stress selection
    cy.wait('@answerapi')
    cy.wait('@sleepapi')

    selector.elementsquestions.sleep()
    selector.elements.sleep_5to6().click()   //sleep selection
    cy.wait('@answerapi')
    cy.wait('@waterapi')
    selector.elementsquestions.waterconsumption()
    selector.elements.water_consumption().click()    //water consumption selection
    cy.wait('@answerapi')
    cy.wait('@spenddayapi')

    selector.elementsquestions.dayspend()
    selector.elements.indoors_wtoutAC().click()     //environment selection
    cy.wait('@answerapi')
    cy.wait('@lifestyleapi')

    selector.elementsquestions.lifestylepart()
    selector.elements.lifestyle_regular_workout().click()   //lifestyle selection
    selector.elements.continue_btn().click()               //continue button
    cy.wait('@answerapi')
    cy.wait('@makeupapi')
    
    selector.elementsquestions.makeup()
    selector.elements.wear_makeup_occasionally().click()    //makeup wearing selection
    cy.wait('@answerapi')
    cy.wait('@smokeapi')

    selector.elementsquestions.smoke()
    selector.elements.smoke_occasionally().click()          //smoking selection
    cy.wait('@answerapi')
    cy.wait('@productpreferenceapi') 

    selector.elementsquestions.productpreference()
    selector.elements.product_preference_vegan().click()      //product preference selection
    selector.elements.continue_btn().click()                //continue bbutton
    cy.wait('@answerapi')

    selector.elements.staying_month_textbox().clear().type('Zurich')     //click on text box
    selector.genericwait()
    selector.elements.city_selection().click()         //city selection from dropdown
    selector.genericwait()
    selector.elements.continue_btn().click()     //continue bbutton
    cy.wait('@<20weatherapi')
    selector.elements.continue_btn().click()     //continue button
    cy.wait('@mp4videoapi')

    selector.elements.skipto_results_btn().click()      // skip to results button
    cy.wait('@resultpage')
    cy.wait('@resultonproductpage')
    
    selector.producttype.dayserum().should('exist')           //verifing the product type
    selector.producttype.nightserum().should('exist')          //verifing the product type
    selector.producttype.moisturiser().should('exist')         //verifing the product type
    //selector.producttype.nightcream().should('exist')           //verifing the product type
    selector.genericwait()

    selector.elements.add_day_night_set().click()               //add product set button
    cy.wait('@addsetbtnapi')

    selector.elements.product_btn().click()                    //product button
    cy.wait('@resultonproductpage')
     
    selector.productname.daydropoflight().should('exist')            //verifing the day serum
    selector.productname.crazyrichmoisturiser().should('exist')   //verifing the day cream
    selector.productname.nightdropofsoftness().should('exist')      //verifing the night serum
    //selector.productname.milkyway().should('exist')              //verifing the night cream
    cy.wait(3000)

}


testcase8()
{
    selector.assessment_apis()              //inculuded assessment/result/answer's api's
    selector.elements.gender_male().click() //gender selection
    cy.wait('@answerapi')
    cy.wait('@agequestionapi')

    selector.elementsquestions.age()
    selector.elements.age_any().click()   //age selection
    cy.wait('@answerapi')
    cy.wait('@cheeksapi')

    selector.elementsquestions.cheeksinthemorning()
    selector.elements.cheeks_morning_verydry().click()  //cheeks selection
    cy.wait('@answerapi')
    cy.wait('@tzoneapi')

    selector.elementsquestions.tzone()
    selector.elements.tzone_oily().click()   //tzone selection
    cy.wait('@answerapi')
    cy.wait('@skinconcernapi')

    selector.elementsquestions.top2skinconcerns()
    selector.elements.top2_skin_concerns_wrinkles().click()  //skin concerns selection  1
    selector.elements.top2_skin_concerns_redness().click()  //skin concerns selection   2
    cy.wait('@answerapi')
    cy.wait('@levelofrednessapi')
    
    selector.elementsquestions.levelofredness()
    selector.elements.levelofredness_mild().click()  //level of redness
    cy.wait('@answerapi')
    cy.wait('@skinshadeapi')

    selector.elementsquestions.skinshade()
    selector.elements.skishade_2nd().click()     //skin shade selection
    cy.wait('@answerapi')
    cy.wait('@reactionapi')

    selector.elementsquestions.skinreaction()
    selector.elements.skinReactions_yes().click()   //skin reaction selection
    cy.wait('@answerapi')
    cy.wait('@ingredientapi')

    selector.elementsquestions.ingredients()
    selector.elements.ingredients_retinol().click()    //ingredients selection
    selector.elements.continue_btn().click()           //continue button
    cy.wait('@answerapi')
    cy.wait('@stressapi')

    selector.elementsquestions.stress()
    selector.elements.little_stress().click()    // stress selection
    cy.wait('@answerapi')
    cy.wait('@sleepapi')

    selector.elementsquestions.sleep()
    selector.elements.sleep_5to6().click()   //sleep selection
    cy.wait('@answerapi')
    cy.wait('@waterapi')

    selector.elementsquestions.waterconsumption()
    selector.elements.water_consumption().click()    //water consumption selection
    cy.wait('@answerapi')
    cy.wait('@spenddayapi')

    selector.elementsquestions.dayspend()
    selector.elements.indoors_wtoutAC().click()     //environment selection
    cy.wait('@answerapi')
    cy.wait('@lifestyleapi')

    selector.elementsquestions.lifestylepart()
    selector.elements.lifestyle_regular_workout().click()   //lifestyle selection
    selector.elements.continue_btn().click()               //continue button
    cy.wait('@answerapi')
    cy.wait('@makeupapi')
    
    selector.elementsquestions.makeup()
    selector.elements.wear_makeup_occasionally().click()    //makeup wearing selection
    cy.wait('@answerapi')
    cy.wait('@smokeapi')

    selector.elementsquestions.smoke()
    selector.elements.smoke_occasionally().click()          //smoking selection
    cy.wait('@answerapi')
    cy.wait('@productpreferenceapi') 

    selector.elementsquestions.productpreference()
    selector.elements.product_preference_vegan().click()      //product preference selection
    selector.elements.continue_btn().click()                //continue bbutton
    cy.wait('@answerapi')

    selector.elements.staying_month_textbox().clear().type('Lahore')     //click on text box
    selector.genericwait()
    selector.elements.city_selection().click()         //city selection from dropdown
    selector.genericwait()
    selector.elements.continue_btn().click()     //continue bbutton
    cy.wait('@>20weatherapi')
    selector.elements.continue_btn().click()     //continue button
    cy.wait('@mp4videoapi')
    
    selector.elements.skipto_results_btn().click()      // skip to results button
    cy.wait('@resultpage')
    cy.wait('@resultonproductpage')
    
    selector.producttype.dayserum().should('exist')           //verifing the product type
    selector.producttype.nightserum().should('exist')          //verifing the product type
    selector.producttype.moisturiser().should('exist')         //verifing the product type
    //selector.producttype.nightcream().should('exist')           //verifing the product type
    selector.genericwait()

    selector.elements.add_day_night_set().click()               //add product set button
    cy.wait('@addsetbtnapi')

    selector.elements.product_btn().click()                    //product button
    cy.wait('@resultonproductpage')
     

    selector.productname.daydropoflight().should('exist')            //verifing the day serum
    selector.productname.dewdatemoisturiser().should('exist')       //verifing the day cream
    selector.productname.nightdropofsoftness().should('exist')         //verifing the night serum
    //selector.productname.milkyway().should('exist')              //verifing the Night cream
    cy.wait(3000)

}


testcase9()
{
    selector.assessment_apis()              //inculuded assessment/result/answer's api's
    selector.elements.gender_male().click() //gender selection
    cy.wait('@answerapi')
    cy.wait('@agequestionapi')

    selector.elementsquestions.age()
    selector.elements.age_any().click()   //age selection
    cy.wait('@answerapi')
    cy.wait('@cheeksapi')

    selector.elementsquestions.cheeksinthemorning()
    selector.elements.cheeks_morning_verydry().click()  //cheeks selection
    cy.wait('@answerapi')
    cy.wait('@tzoneapi')

    selector.elementsquestions.tzone()
    selector.elements.tzone_veryoily().click()   //tzone selection
    cy.wait('@answerapi')
    cy.wait('@skinconcernapi')

    selector.elementsquestions.top2skinconcerns()
    selector.elements.top2_skin_concerns_wrinkles().click()  //skin concerns selection  1
    selector.elements.top2_skin_concerns_redness().click()  //skin concerns selection   2
    cy.wait('@answerapi')
    cy.wait('@levelofrednessapi')
    
    
    selector.elementsquestions.levelofredness()
    selector.elements.levelofredness_mild().click()  //level of redness
    cy.wait('@answerapi')
    cy.wait('@skinshadeapi')

    selector.elementsquestions.skinshade()
    selector.elements.skishade_2nd().click()     //skin shade selection
    cy.wait('@answerapi')
    cy.wait('@reactionapi')

    selector.elementsquestions.skinreaction()
    selector.elements.skinReactions_no().click()   //skin reaction selection Yes or No
    cy.wait('@answerapi')
    cy.wait('@stressapi')

    selector.elementsquestions.stress()
    selector.elements.little_stress().click()    // stress selection
    cy.wait('@answerapi')
    cy.wait('@sleepapi')

    selector.elementsquestions.sleep()
    selector.elements.sleep_5to6().click()   //sleep selection
    cy.wait('@answerapi')
    cy.wait('@waterapi')

    selector.elementsquestions.waterconsumption()
    selector.elements.water_consumption().click()    //water consumption selection
    cy.wait('@answerapi')
    cy.wait('@spenddayapi')

    selector.elementsquestions.dayspend()
    selector.elements.indoors_wtoutAC().click()     //environment selection
    cy.wait('@answerapi')
    cy.wait('@lifestyleapi')

    selector.elementsquestions.lifestylepart()
    selector.elements.lifestyle_regular_workout().click()   //lifestyle selection
    selector.elements.continue_btn().click()               //continue button
    cy.wait('@answerapi')
    cy.wait('@makeupapi')
    
    selector.elementsquestions.makeup()
    selector.elements.wear_makeup_occasionally().click()    //makeup wearing selection
    cy.wait('@answerapi')
    cy.wait('@smokeapi')

    selector.elementsquestions.smoke()
    selector.elements.smoke_occasionally().click()          //smoking selection
    cy.wait('@answerapi')
    cy.wait('@productpreferenceapi') 

    selector.elementsquestions.productpreference()
    selector.elements.product_preference_none().click()      //product preference selection
    cy.wait('@answerapi')

    selector.elements.staying_month_textbox().clear().type('Zurich')     //click on text box
    selector.genericwait()
    selector.elements.city_selection().click()         //city selection from dropdown
    selector.genericwait()
    selector.elements.continue_btn().click()     //continue bbutton
    cy.wait('@<20weatherapi')
    selector.elements.continue_btn().click()     //continue button
    cy.wait('@mp4videoapi')

    selector.elements.skipto_results_btn().click()      // skip to results button
    cy.wait('@resultpage')
    cy.wait('@resultonproductpage')
    
    selector.producttype.dayserum().should('exist')           //verifing the product type
    selector.producttype.nightserum().should('exist')          //verifing the product type
    selector.producttype.moisturiser().should('exist')         //verifing the product type
    //selector.producttype.nightcream().should('exist')           //verifing the product type
    selector.genericwait()

    selector.elements.add_day_night_set().click()               //add product set button
    cy.wait('@addsetbtnapi')


    selector.elements.product_btn().click()                    //product button
    cy.wait('@resultonproductpage')
     

    selector.productname.daydropofsoftness().should('exist')            //verifing the day serum
    selector.productname.crazyrichmoisturiser().should('exist')   //verifing the day cream
    selector.productname.dropofyouth().should('exist')         //verifing the night serum
    //selector.productname.milkyway().should('exist')              //verifing the night cream
    cy.wait(3000)

}



testcase10()
{
    selector.assessment_apis()              //inculuded assessment/result/answer's api's
    selector.elements.gender_male().click() //gender selection
    cy.wait('@answerapi')
    cy.wait('@agequestionapi')

    selector.elementsquestions.age()
    selector.elements.age_any().click()   //age selection
    cy.wait('@answerapi')
    cy.wait('@cheeksapi')

    selector.elementsquestions.cheeksinthemorning()
    selector.elements.cheeks_morning_verydry().click()  //cheeks selection
    cy.wait('@answerapi')
    cy.wait('@tzoneapi')

    selector.elementsquestions.tzone()
    selector.elements.tzone_veryoily().click()   //tzone selection
    cy.wait('@answerapi')
    cy.wait('@skinconcernapi')

    selector.elementsquestions.top2skinconcerns()
    selector.elements.top2_skin_concerns_wrinkles().click()  //skin concerns selection  1
    selector.elements.top2_skin_concerns_redness().click()  //skin concerns selection   2
    cy.wait('@answerapi')
    cy.wait('@levelofrednessapi')
    
    selector.elementsquestions.levelofredness()
    selector.elements.levelofredness_mild().click()  //level of redness
    cy.wait('@answerapi')
    cy.wait('@skinshadeapi')

    selector.elementsquestions.skinshade()
    selector.elements.skishade_2nd().click()     //skin shade selection
    cy.wait('@answerapi')
    cy.wait('@reactionapi')

    selector.elementsquestions.skinreaction()
    selector.elements.skinReactions_no().click()   //skin reaction selection Yes or No
     cy.wait('@answerapi')
    cy.wait('@stressapi')

    selector.elementsquestions.stress()
    selector.elements.little_stress().click()    // stress selection
    cy.wait('@answerapi')
    cy.wait('@sleepapi')

    selector.elementsquestions.sleep()
    selector.elements.sleep_5to6().click()   //sleep selection
    cy.wait('@answerapi')
    cy.wait('@waterapi')

    selector.elementsquestions.waterconsumption()
    selector.elements.water_consumption().click()    //water consumption selection
    cy.wait('@answerapi')
    cy.wait('@spenddayapi')

    selector.elementsquestions.dayspend()
    selector.elements.indoors_wtoutAC().click()     //environment selection
    cy.wait('@answerapi')
    cy.wait('@lifestyleapi')

    selector.elementsquestions.lifestylepart()
    selector.elements.lifestyle_regular_workout().click()   //lifestyle selection
    selector.elements.continue_btn().click()               //continue button
    cy.wait('@answerapi')
    cy.wait('@makeupapi')
    
    selector.elementsquestions.makeup()
    selector.elements.wear_makeup_occasionally().click()    //makeup wearing selection
    cy.wait('@answerapi')
    cy.wait('@smokeapi')

    selector.elementsquestions.smoke()
    selector.elements.smoke_occasionally().click()          //smoking selection
    cy.wait('@answerapi')
    cy.wait('@productpreferenceapi') 
    
    selector.elementsquestions.productpreference()
    selector.elements.product_preference_vegan().click()      //product preference selection
    selector.elements.continue_btn().click()                //continue bbutton
    cy.wait('@answerapi')

    selector.elements.staying_month_textbox().clear().type('Lahore')     //click on text box
    selector.genericwait()
    selector.elements.city_selection().click()         //city selection from dropdown
    selector.genericwait()
    selector.elements.continue_btn().click()     //continue bbutton
    cy.wait('@>20weatherapi')
    selector.elements.continue_btn().click()     //continue button
    cy.wait('@mp4videoapi')

    selector.elements.skipto_results_btn().click()      // skip to results button
    cy.wait('@resultpage')
    cy.wait('@resultonproductpage')
    
    selector.producttype.dayserum().should('exist')           //verifing the product type
    selector.producttype.nightserum().should('exist')          //verifing the product type
    selector.producttype.moisturiser().should('exist')         //verifing the product type
    //selector.producttype.nightcream().should('exist')           //verifing the product type
    selector.genericwait()


    selector.elements.add_day_night_set().click()               //add product set button
    cy.wait('@addsetbtnapi')


    selector.elements.product_btn().click()                    //product button
    cy.wait('@resultonproductpage')
     

    selector.productname.daydropofsoftness().should('exist')       //verifing the day serum 
    selector.productname.dewdatemoisturiser().should('exist')     //verifing the day cream
    selector.productname.nightdropoflight().should('exist')         //verifing the night serum
    //selector.productname.milkyway().should('exist')              //verifing the night cream
    cy.wait(3000)

}


testcase11()
{
    selector.assessment_apis()              //inculuded assessment/result/answer's api's
    selector.elements.gender_male().click() //gender selection
    cy.wait('@answerapi')
    cy.wait('@agequestionapi')

    selector.elementsquestions.age()
    selector.elements.age_any().click()   //age selection
    cy.wait('@answerapi')
    cy.wait('@cheeksapi')

    selector.elementsquestions.cheeksinthemorning()
    selector.elements.cheeks_morning_verydry().click()  //cheeks selection
    cy.wait('@answerapi')
    cy.wait('@tzoneapi')

    selector.elementsquestions.tzone()
    selector.elements.tzone_veryoily().click()   //tzone selection
    cy.wait('@answerapi')
    cy.wait('@skinconcernapi')
	
    selector.elementsquestions.top2skinconcerns()
    selector.elements.top2_skin_concerns_wrinkles().click()  //skin concerns selection  1
    selector.elements.top2_skin_concerns_redness().click()  //skin concerns selection   2
    cy.wait('@answerapi')
    cy.wait('@levelofrednessapi')
    
    selector.elementsquestions.levelofredness()
    selector.elements.levelofredness_mild().click()  //level of redness
    cy.wait('@answerapi')
    cy.wait('@skinshadeapi')

    selector.elementsquestions.skinshade()
    selector.elements.skishade_2nd().click()     //skin shade selection
    cy.wait('@answerapi')
    cy.wait('@reactionapi')

    selector.elementsquestions.skinreaction()
    selector.elements.skinReactions_no().click()   //skin reaction selection Yes or No
    cy.wait('@answerapi')
    cy.wait('@stressapi')

    selector.elementsquestions.stress()
    selector.elements.little_stress().click()    // stress selection
    cy.wait('@answerapi')
    cy.wait('@sleepapi')

    selector.elementsquestions.sleep()
    selector.elements.sleep_5to6().click()   //sleep selection
    cy.wait('@answerapi')
    cy.wait('@waterapi')

    selector.elementsquestions.waterconsumption()
    selector.elements.water_consumption().click()    //water consumption selection
    cy.wait('@answerapi')
    cy.wait('@spenddayapi')

    selector.elementsquestions.dayspend()
    selector.elements.indoors_wtoutAC().click()     //environment selection
    cy.wait('@answerapi')
    cy.wait('@lifestyleapi')

    selector.elementsquestions.lifestylepart()
    selector.elements.lifestyle_regular_workout().click()   //lifestyle selection
    selector.elements.continue_btn().click()               //continue button
    cy.wait('@answerapi')
    cy.wait('@makeupapi')
    
    selector.elementsquestions.makeup()
    selector.elements.wear_makeup_occasionally().click()    //makeup wearing selection
    cy.wait('@answerapi')
    cy.wait('@smokeapi')

    selector.elementsquestions.smoke()
    selector.elements.smoke_occasionally().click()          //smoking selection
    cy.wait('@answerapi')
    cy.wait('@productpreferenceapi') 
    

    selector.elementsquestions.productpreference()
    selector.elements.product_preference_pregnancysafe().click()      //product preference selection
    selector.elements.continue_btn().click()             //continue button
    cy.wait('@answerapi')


    selector.elements.staying_month_textbox().clear().type('Lahore')     //click on text box
    selector.genericwait()
    selector.elements.city_selection().click()         //city selection from dropdown
    selector.genericwait()
    selector.elements.continue_btn().click()     //continue bbutton
    cy.wait('@>20weatherapi')
    selector.elements.continue_btn().click()     //continue button
    cy.wait('@mp4videoapi')

    selector.elements.skipto_results_btn().click()      // skip to results button
    cy.wait('@resultpage')
    cy.wait('@resultonproductpage')
    
    selector.producttype.dayserum().should('exist')           //verifing the product type
    selector.producttype.nightserum().should('exist')          //verifing the product type
    selector.producttype.moisturiser().should('exist')         //verifing the product type
    //selector.producttype.nightcream().should('exist')           //verifing the product type
    selector.genericwait()


    selector.elements.add_day_night_set().click()               //add product set button
    cy.wait('@addsetbtnapi')
    
    selector.elements.product_btn().click()                    //product button
    cy.wait('@resultonproductpage')
     

    selector.productname.daydropofsoftness().should('exist')       //verifing the day serum 
    selector.productname.dewdatemoisturiser().should('exist')     //verifing the day cream
    selector.productname.nightdropoflight().should('exist')         //verifing the night serum
    selector.productname.milkyway().should('exist')              //verifing the night cream
    cy.wait(3000)

}


testcase12()
{
    selector.assessment_apis()              //inculuded assessment/result/answer's api's
    selector.elements.gender_male().click() //gender selection
    cy.wait('@answerapi')
    cy.wait('@agequestionapi')

    selector.elementsquestions.age()
    selector.elements.age_any().click()   //age selection
    cy.wait('@answerapi')
    cy.wait('@cheeksapi')
    
    selector.elementsquestions.cheeksinthemorning()
    selector.elements.cheeks_morning_dry().click()  //cheeks selection
    cy.wait('@answerapi')
    cy.wait('@tzoneapi')

    selector.elementsquestions.tzone()
    selector.elements.tzone_verydry().click()   //tzone selection
    cy.wait('@answerapi')
    cy.wait('@skinconcernapi')

    selector.elementsquestions.top2skinconcerns()
    selector.elements.top2_skin_concerns_wrinkles().click()  //skin concerns selection  1
    selector.elements.top2_skin_concerns_redness().click()  //skin concerns selection   2
    cy.wait('@answerapi')
    cy.wait('@levelofrednessapi')

    selector.elementsquestions.levelofredness()
    selector.elements.levelofredness_mild().click()  //level of redness
    cy.wait('@answerapi')
    cy.wait('@skinshadeapi')

    selector.elementsquestions.skinshade()
    selector.elements.skishade_2nd().click()     //skin shade selection
    cy.wait('@answerapi')
    cy.wait('@reactionapi')

    selector.elementsquestions.skinreaction()
    selector.elements.skinReactions_yes().click()   //skin reaction selection Yes or No
    cy.wait('@answerapi')
    cy.wait('@ingredientapi')

    selector.elementsquestions.ingredients()
    selector.elements.ingredients_salicylicacid().click()    //ingredients selection
    selector.elements.continue_btn().click()                 //continue button
    cy.wait('@answerapi')
    cy.wait('@stressapi')

    selector.elementsquestions.stress()
    selector.elements.little_stress().click()    // stress selection
    cy.wait('@answerapi')
    cy.wait('@sleepapi')

    selector.elementsquestions.sleep()
    selector.elements.sleep_5to6().click()   //sleep selection
    cy.wait('@answerapi')
    cy.wait('@waterapi')

    selector.elementsquestions.waterconsumption()
    selector.elements.water_consumption().click()    //water consumption selection
    cy.wait('@answerapi')
    cy.wait('@spenddayapi')
    
    selector.elementsquestions.dayspend()
    selector.elements.indoors_wtoutAC().click()     //environment selection
    cy.wait('@answerapi')
    cy.wait('@lifestyleapi')

    selector.elementsquestions.lifestylepart()
    selector.elements.lifestyle_regular_workout().click()   //lifestyle selection
    selector.elements.continue_btn().click()               //continue button
    cy.wait('@answerapi')
    cy.wait('@makeupapi')
    
    selector.elementsquestions.makeup()
    selector.elements.wear_makeup_occasionally().click()    //makeup wearing selection
    cy.wait('@answerapi')
    cy.wait('@smokeapi')

    selector.elementsquestions.smoke()
    selector.elements.smoke_occasionally().click()          //smoking selection
    cy.wait('@answerapi')
    cy.wait('@productpreferenceapi') 
    
    selector.elementsquestions.productpreference()
    selector.elements.product_preference_none().click()      //product preference selection
    cy.wait('@answerapi')
    

    selector.elements.staying_month_textbox().clear().type('Lahore')     //click on text box
    selector.genericwait()
    selector.elements.city_selection().click()         //city selection from dropdown
    selector.genericwait()
    selector.elements.continue_btn().click()     //continue bbutton
    cy.wait('@>20weatherapi')
    selector.elements.continue_btn().click()     //continue button
    cy.wait('@mp4videoapi')

    selector.elements.skipto_results_btn().click()      // skip to results button
    cy.wait('@resultpage')
    cy.wait('@resultonproductpage')
    
    selector.producttype.dayserum().should('exist')           //verifing the product type
    selector.producttype.nightserum().should('exist')          //verifing the product type
    selector.producttype.moisturiser().should('exist')         //verifing the product type
    //selector.producttype.nightcream().should('exist')           //verifing the product type
    selector.genericwait()


    selector.elements.add_day_night_set().click()               //add product set button
    cy.wait('@addsetbtnapi')
    
    selector.elements.product_btn().click()                    //product button
    cy.wait('@resultonproductpage')
     

    selector.productname.daydropofsoftness().should('exist')       //verifing the day serum 
    selector.productname.crazyrichmoisturiser().should('exist')     //verifing the day cream
    selector.productname.dropofyouth().should('exist')         //verifing the night serum
    selector.productname.dndnights().should('exist')              //verifing the night cream
    cy.wait(3000)

}



testcase13()
{
    selector.assessment_apis()                   //inculuded assessment/result/answer's api's
    selector.elements.gender_male().click()      //gender selection
    cy.wait('@answerapi')
    cy.wait('@agequestionapi')

    selector.elementsquestions.age()
    selector.elements.age_any().click()   //age selection
    cy.wait('@answerapi')
    cy.wait('@cheeksapi')

    selector.elementsquestions.cheeksinthemorning()
    selector.elements.cheeks_morning_dry().click()  //cheeks selection
    cy.wait('@answerapi')
    cy.wait('@tzoneapi')

    selector.elementsquestions.tzone()
    selector.elements.tzone_verydry().click()   //tzone selection
    cy.wait('@answerapi')
    cy.wait('@skinconcernapi')

    selector.elementsquestions.top2skinconcerns()
    selector.elements.top2_skin_concerns_wrinkles().click()  //skin concerns selection  1
    selector.elements.top2_skin_concerns_redness().click()  //skin concerns selection   2
    cy.wait('@answerapi')
    cy.wait('@levelofrednessapi')
    
    selector.elementsquestions.levelofredness()
    selector.elements.levelofredness_mild().click()  //level of redness
    cy.wait('@answerapi')
    cy.wait('@skinshadeapi')

    selector.elementsquestions.skinshade()
    selector.elements.skishade_2nd().click()     //skin shade selection
    cy.wait('@answerapi')
    cy.wait('@reactionapi')

    selector.elementsquestions.skinreaction()
    selector.elements.skinReactions_yes().click()   //skin reaction selection Yes or No
    cy.wait('@answerapi')
    cy.wait('@ingredientapi')

    selector.elementsquestions.ingredients()
    selector.elements.ingredients_salicylicacid().click()    //ingredients selection
    selector.elements.continue_btn().click()                 //continue button
    cy.wait('@answerapi')
    cy.wait('@stressapi')

    selector.elementsquestions.stress()
    selector.elements.little_stress().click()    // stress selection
    cy.wait('@answerapi')
    cy.wait('@sleepapi')

    selector.elementsquestions.sleep()
    selector.elements.sleep_5to6().click()   //sleep selection
    cy.wait('@answerapi')
    cy.wait('@waterapi') 

    selector.elementsquestions.waterconsumption()
    selector.elements.water_consumption().click()    //water consumption selection
    cy.wait('@answerapi')
    cy.wait('@spenddayapi')

    selector.elementsquestions.dayspend()
    selector.elements.indoors_wtoutAC().click()     //environment selection
    cy.wait('@answerapi')
    cy.wait('@lifestyleapi')

    selector.elementsquestions.lifestylepart()
    selector.elements.lifestyle_regular_workout().click()   //lifestyle selection
    selector.elements.continue_btn().click()               //continue button
    cy.wait('@answerapi')
    cy.wait('@makeupapi')
    
    selector.elementsquestions.makeup()
    selector.elements.wear_makeup_occasionally().click()    //makeup wearing selection
    cy.wait('@answerapi')
    cy.wait('@smokeapi')

    selector.elementsquestions.smoke()
    selector.elements.smoke_occasionally().click()          //smoking selection
    cy.wait('@answerapi')
    cy.wait('@productpreferenceapi') 

    selector.elementsquestions.productpreference()
    selector.elements.product_preference_pregnancysafe().click()      //product preference selection
    selector.elements.continue_btn().click()           //continue button
    

    selector.elements.staying_month_textbox().clear().type('Lahore')     //click on text box
    selector.genericwait()
    selector.elements.city_selection().click()         //city selection from dropdown
    selector.genericwait()
    selector.elements.continue_btn().click()     //continue bbutton
    cy.wait('@>20weatherapi')
    selector.elements.continue_btn().click()     //continue button
    cy.wait('@mp4videoapi')

    selector.elements.skipto_results_btn().click()      // skip to results button
    cy.wait('@resultpage')
    cy.wait('@resultonproductpage')
    
    selector.producttype.dayserum().should('exist')           //verifing the product type
    selector.producttype.nightserum().should('exist')          //verifing the product type
    selector.producttype.moisturiser().should('exist')         //verifing the product type
    //selector.producttype.nightcream().should('exist')           //verifing the product type
    selector.genericwait()


    selector.elements.add_day_night_set().click()               //add product set button
    cy.wait('@addsetbtnapi')
    
    selector.elements.product_btn().click()                    //product button
    cy.wait('@resultonproductpage')
     

    selector.productname.daydropofsoftness().should('exist')       //verifing the day serum 
    selector.productname.crazyrichmoisturiser().should('exist')     //verifing the day cream
    selector.productname.nightdropoflight().should('exist')         //verifing the night serum
    selector.productname.milkyway().should('exist')              //verifing the night cream
    cy.wait(3000)

}



testcase14()
{
    selector.assessment_apis()              //inculuded assessment/result/answer's api's
    selector.elements.gender_male().click() //gender selection
    cy.wait('@answerapi')
    cy.wait('@agequestionapi')

    selector.elementsquestions.age()
    selector.elements.age_any().click()   //age selection
    cy.wait('@answerapi')
    cy.wait('@cheeksapi')

    selector.elementsquestions.cheeksinthemorning()
    selector.elements.cheeks_morning_dry().click()  //cheeks selection
    cy.wait('@answerapi')
    cy.wait('@tzoneapi')

    selector.elementsquestions.tzone()
    selector.elements.tzone_verydry().click()   //tzone selection
    cy.wait('@answerapi')
    cy.wait('@skinconcernapi')


    selector.elementsquestions.top2skinconcerns()
    selector.elements.top2_skin_concerns_wrinkles().click()  //skin concerns selection  1
    selector.elements.top2_skin_concerns_redness().click()  //skin concerns selection   2
    cy.wait('@answerapi')
    cy.wait('@levelofrednessapi')
    

    selector.elementsquestions.levelofredness()
    selector.elements.levelofredness_mild().click()  //level of redness
    cy.wait('@answerapi')
    cy.wait('@skinshadeapi')

    selector.elementsquestions.skinshade()
    selector.elements.skishade_2nd().click()     //skin shade selection
    cy.wait('@answerapi')
    cy.wait('@reactionapi')

    selector.elementsquestions.skinreaction()
    selector.elements.skinReactions_yes().click()   //skin reaction selection Yes or No
    cy.wait('@answerapi')
    cy.wait('@ingredientapi')

    selector.elementsquestions.ingredients()
    selector.elements.ingredients_salicylicacid().click()    //ingredients selection
    selector.elements.continue_btn().click()                 //continue button
    cy.wait('@answerapi')
    cy.wait('@stressapi')

    selector.elementsquestions.stress()
    selector.elements.little_stress().click()    // stress selection
    cy.wait('@answerapi')
    cy.wait('@sleepapi')

    selector.elementsquestions.sleep()
    selector.elements.sleep_5to6().click()   //sleep selection
    cy.wait('@answerapi')
    cy.wait('@waterapi')

    selector.elementsquestions.waterconsumption()
    selector.elements.water_consumption().click()    //water consumption selection
    cy.wait('@answerapi')
    cy.wait('@spenddayapi')

    selector.elementsquestions.dayspend()
    selector.elements.indoors_wtoutAC().click()     //environment selection
    cy.wait('@answerapi')
    cy.wait('@lifestyleapi')

    selector.elementsquestions.lifestylepart()
    selector.elements.lifestyle_regular_workout().click()   //lifestyle selection
    selector.elements.continue_btn().click()               //continue button
    cy.wait('@answerapi')
    cy.wait('@makeupapi')
    
    selector.elementsquestions.makeup()
    selector.elements.wear_makeup_occasionally().click()    //makeup wearing selection
    cy.wait('@answerapi')
    cy.wait('@smokeapi')

    selector.elementsquestions.smoke()
    selector.elements.smoke_occasionally().click()          //smoking selection
    cy.wait('@answerapi')
    cy.wait('@productpreferenceapi') 

    selector.elementsquestions.productpreference()
    selector.elements.product_preference_vegan().click()      //product preference selection
    selector.elements.continue_btn().click()           //continue button
    cy.wait('@answerapi')

    selector.elements.staying_month_textbox().clear().type('Lahore')     //click on text box
    selector.genericwait()
    selector.elements.city_selection().click()         //city selection from dropdown
    selector.genericwait()
    selector.elements.continue_btn().click()     //continue bbutton
    cy.wait('@>20weatherapi')
    selector.elements.continue_btn().click()     //continue button
    cy.wait('@mp4videoapi')

    selector.elements.skipto_results_btn().click()      // skip to results button
    cy.wait('@resultpage')
    cy.wait('@resultonproductpage')
    
    selector.producttype.dayserum().should('exist')           //verifing the product type
    selector.producttype.nightserum().should('exist')          //verifing the product type
    selector.producttype.moisturiser().should('exist')         //verifing the product type
    //selector.producttype.nightcream().should('exist')           //verifing the product type
    selector.genericwait()


    selector.elements.add_day_night_set().click()               //add product set button
    cy.wait('@addsetbtnapi')
    
    selector.elements.product_btn().click()                    //product button
    cy.wait('@resultonproductpage')
     
    selector.productname.daydropofsoftness().should('exist')       //verifing the day serum 
    selector.productname.crazyrichmoisturiser().should('exist')     //verifing the day cream
    selector.productname.nightdropoflight().should('exist')         //verifing the night serum
    selector.productname.dndnights().should('exist')              //verifing the night cream
    cy.wait(3000)

}


testcase15()
{
    selector.assessment_apis()              //inculuded assessment/result/answer's api's
    selector.elements.gender_male().click() //gender selection
    cy.wait('@answerapi')
    cy.wait('@agequestionapi')

    selector.elementsquestions.age()
    selector.elements.age_any().click()   //age selection
    cy.wait('@answerapi')
    cy.wait('@cheeksapi')

    selector.elementsquestions.cheeksinthemorning()
    selector.elements.cheeks_morning_dry().click()  //cheeks selection
    cy.wait('@answerapi')
    cy.wait('@tzoneapi')

    selector.elementsquestions.tzone()
    selector.elements.tzone_dry().click()   //tzone selection
    cy.wait('@answerapi')
    cy.wait('@skinconcernapi')

    selector.elementsquestions.top2skinconcerns()
    selector.elements.top2_skin_concerns_wrinkles().click()  //skin concerns selection  1
    selector.elements.top2_skin_concerns_acne().click()  //skin concerns selection   2
    cy.wait('@answerapi')
    cy.wait('@getacneapi')

    selector.elementsquestions.getacne()
    selector.elements.get_acne_always().click()  // select acny stay period
    cy.wait('@answerapi')
    cy.wait('@describeacneapi')


    selector.elementsquestions.describeacne()
    selector.elements.acnehardones().click()     //select acne type
     cy.wait('@answerapi')
    cy.wait('@skinshadeapi')

    selector.elementsquestions.skinshade()
    selector.elements.skishade_2nd().click()     //skin shade selection
    cy.wait('@answerapi')
    cy.wait('@reactionapi')

    selector.elementsquestions.skinreaction()
    selector.elements.skinReactions_yes().click()   //skin reaction selection Yes or No
    cy.wait('@answerapi')
    cy.wait('@ingredientapi')

    selector.elementsquestions.ingredients()
    selector.elements.ingredients_retinol().click()    //ingredients selection
    selector.elements.continue_btn().click()                 //continue button
    cy.wait('@answerapi')
    cy.wait('@stressapi')

    selector.elementsquestions.stress()
    selector.elements.little_stress().click()    // stress selection
    cy.wait('@answerapi')
    cy.wait('@sleepapi')

    selector.elementsquestions.sleep()
    selector.elements.sleep_5to6().click()   //sleep selection
    cy.wait('@answerapi')
    cy.wait('@waterapi')

    selector.elementsquestions.waterconsumption()
    selector.elements.water_consumption().click()    //water consumption selection
    cy.wait('@answerapi')
    cy.wait('@spenddayapi')

    selector.elementsquestions.dayspend()
    selector.elements.indoors_wtoutAC().click()     //environment selection
    cy.wait('@answerapi')
    cy.wait('@lifestyleapi')

    selector.elementsquestions.lifestylepart()
    selector.elements.lifestyle_regular_workout().click()   //lifestyle selection
    selector.elements.continue_btn().click()               //continue button
    cy.wait('@answerapi')
    cy.wait('@makeupapi')
    
    selector.elementsquestions.makeup()
    selector.elements.wear_makeup_occasionally().click()    //makeup wearing selection
    cy.wait('@answerapi')
    cy.wait('@smokeapi')

    selector.elementsquestions.smoke()
    selector.elements.smoke_occasionally().click()          //smoking selection
    cy.wait('@answerapi')
    cy.wait('@productpreferenceapi') 

    selector.elementsquestions.productpreference()
    selector.elements.product_preference_vegan().click()      //product preference selection
    selector.elements.continue_btn().click()           //continue button
    cy.wait('@answerapi')

    selector.elements.staying_month_textbox().clear().type('Lahore')     //click on text box
    selector.genericwait()
    selector.elements.city_selection().click()         //city selection from dropdown
    selector.genericwait()
    selector.elements.continue_btn().click()     //continue bbutton
    cy.wait('@>20weatherapi')
    selector.elements.continue_btn().click()     //continue button
    cy.wait('@mp4videoapi')

    selector.elements.skipto_results_btn().click()      // skip to results button
    cy.wait('@resultpage')
    cy.wait('@resultonproductpage')
    
    selector.producttype.dayserum().should('exist')           //verifing the product type
    selector.producttype.nightserum().should('exist')          //verifing the product type
    selector.producttype.moisturiser().should('exist')         //verifing the product type
    //selector.producttype.nightcream().should('exist')           //verifing the product type
    selector.genericwait()


    selector.elements.add_day_night_set().click()               //add product set button
    cy.wait('@addsetbtnapi')
    
    selector.elements.product_btn().click()                    //product button
    cy.wait('@resultonproductpage')
     

    selector.productname.daydropoflight().should('exist')       //verifing the day serum 
    selector.productname.crazyrichmoisturiser().should('exist')     //verifing the day cream
    selector.productname.night_dropofbalance().should('exist')         //verifing the night serum
    selector.productname.dndnights().should('exist')              //verifing the night cream
    cy.wait(3000)

}


testcase16()
{
    selector.assessment_apis()              //inculuded assessment/result/answer's api's
    selector.elements.gender_male().click() //gender selection
    cy.wait('@answerapi')
    cy.wait('@agequestionapi')

    selector.elementsquestions.age()
    selector.elements.age_any().click()   //age selection
    cy.wait('@answerapi')
    cy.wait('@cheeksapi')

    selector.elementsquestions.cheeksinthemorning()
    selector.elements.cheeks_morning_dry().click()  //cheeks selection
    cy.wait('@answerapi')
    cy.wait('@tzoneapi')

    selector.elementsquestions.tzone()
    selector.elements.tzone_dry().click()   //tzone selection
    cy.wait('@answerapi')
    cy.wait('@skinconcernapi')

    selector.elementsquestions.top2skinconcerns()
    selector.elements.top2_skin_concerns_wrinkles().click()  //skin concerns selection  1
    selector.elements.top2_skin_concerns_acne().click()  //skin concerns selection   2
    cy.wait('@answerapi')
    cy.wait('@getacneapi')

    
    selector.elementsquestions.getacne()
    selector.elements.get_acne_always().click()  // select acny stay period
    cy.wait('@answerapi')
    cy.wait('@describeacneapi')


    selector.elementsquestions.describeacne()
    selector.elements.acnehardones().click()     //select acne type
    cy.wait('@answerapi')
    cy.wait('@skinshadeapi')

    selector.elementsquestions.skinshade()
    selector.elements.skishade_2nd().click()     //skin shade selection
    cy.wait('@answerapi')
    cy.wait('@reactionapi')

    selector.elementsquestions.skinreaction()
    selector.elements.skinReactions_yes().click()   //skin reaction selection Yes or No
    cy.wait('@answerapi')
    cy.wait('@ingredientapi')

    selector.elementsquestions.ingredients()
    selector.elements.ingredients_retinol().click()    //ingredients selection
    selector.elements.continue_btn().click()                 //continue button
    cy.wait('@answerapi')
    cy.wait('@stressapi')

    selector.elementsquestions.stress()
    selector.elements.little_stress().click()    // stress selection
    cy.wait('@answerapi')
    cy.wait('@sleepapi')

    selector.elementsquestions.sleep()
    selector.elements.sleep_5to6().click()   //sleep selection
    cy.wait('@answerapi')
    cy.wait('@waterapi')

    selector.elementsquestions.waterconsumption()
    selector.elements.water_consumption().click()    //water consumption selection
    cy.wait('@answerapi')
    cy.wait('@spenddayapi')

    selector.elementsquestions.dayspend()
    selector.elements.indoors_wtoutAC().click()     //environment selection
    cy.wait('@answerapi')
    cy.wait('@lifestyleapi')

    selector.elementsquestions.lifestylepart()
    selector.elements.lifestyle_regular_workout().click()   //lifestyle selection
    selector.elements.continue_btn().click()               //continue button
    cy.wait('@answerapi')
    cy.wait('@makeupapi')
    
    selector.elementsquestions.makeup()
    selector.elements.wear_makeup_occasionally().click()    //makeup wearing selection
    cy.wait('@answerapi')
    cy.wait('@smokeapi')

    selector.elementsquestions.smoke()
    selector.elements.smoke_occasionally().click()          //smoking selection
    cy.wait('@answerapi')
    cy.wait('@productpreferenceapi') 

    selector.elementsquestions.productpreference()
    selector.elements.product_preference_pregnancysafe().click()      //product preference selection
    selector.elements.continue_btn().click()           //continue button
    cy.wait('@answerapi')

    selector.elements.staying_month_textbox().clear().type('Lahore')     //click on text box
    selector.genericwait()
    selector.elements.city_selection().click()         //city selection from dropdown
    selector.genericwait()
    selector.elements.continue_btn().click()     //continue bbutton
    cy.wait('@>20weatherapi')
    selector.elements.continue_btn().click()     //continue button
    cy.wait('@mp4videoapi')

    selector.elements.skipto_results_btn().click()      // skip to results button
    cy.wait('@resultpage')
    cy.wait('@resultonproductpage')
    
    selector.producttype.dayserum().should('exist')           //verifing the product type
    selector.producttype.nightserum().should('exist')          //verifing the product type
    selector.producttype.moisturiser().should('exist')         //verifing the product type
    //selector.producttype.nightcream().should('exist')           //verifing the product type
    selector.genericwait()


    selector.elements.add_day_night_set().click()               //add product set button
    cy.wait('@addsetbtnapi')
    
    selector.elements.product_btn().click()                    //product button
    cy.wait('@resultonproductpage')
     

    selector.productname.daydropoflight().should('exist')       //verifing the day serum 
    selector.productname.crazyrichmoisturiser().should('exist')     //verifing the day cream
    selector.productname.night_dropofbalance().should('exist')         //verifing the night serum
    selector.productname.milkyway().should('exist')              //verifing the night cream
    cy.wait(3000)

}


testcase17()
{
    selector.assessment_apis()              //inculuded assessment/result/answer's api's
    selector.elements.gender_male().click() //gender selection
    cy.wait('@answerapi')
    cy.wait('@agequestionapi')

    selector.elementsquestions.age()
    selector.elements.age_any().click()   //age selection
    cy.wait('@answerapi')
    cy.wait('@cheeksapi')

    selector.elementsquestions.cheeksinthemorning()
    selector.elements.cheeks_morning_dry().click()  //cheeks selection
    cy.wait('@answerapi')
    cy.wait('@tzoneapi')

    selector.elementsquestions.tzone()
    selector.elements.tzone_normal().click()   //tzone selection
    cy.wait('@answerapi')
    cy.wait('@skinconcernapi')

    selector.elementsquestions.top2skinconcerns()
    selector.elements.top2_skin_concerns_wrinkles().click()  //skin concerns selection  1
    selector.elements.top2_skin_concerns_acne().click()  //skin concerns selection   2
    cy.wait('@answerapi')
    cy.wait('@getacneapi')


    selector.elementsquestions.getacne()
    selector.elements.get_acne_always().click()  // select acny stay period
    cy.wait('@answerapi')
    cy.wait('@describeacneapi')


    selector.elementsquestions.describeacne()
    selector.elements.acnehardones().click()     //select acne type
    cy.wait('@answerapi')
    cy.wait('@skinshadeapi')

    selector.elementsquestions.skinshade()
    selector.elements.skishade_2nd().click()     //skin shade selection
    cy.wait('@answerapi')
    cy.wait('@reactionapi')

    selector.elementsquestions.skinreaction()
    selector.elements.skinReactions_no().click()   //skin reaction selection Yes or No
    cy.wait('@answerapi')
    cy.wait('@stressapi')

    selector.elementsquestions.stress()
    selector.elements.little_stress().click()    // stress selection
    cy.wait('@answerapi')
    cy.wait('@sleepapi')

    selector.elementsquestions.sleep()
    selector.elements.sleep_5to6().click()      //sleep selection
    cy.wait('@answerapi')
    cy.wait('@waterapi')

    selector.elementsquestions.waterconsumption()
    selector.elements.water_consumption().click()    //water consumption selection
    cy.wait('@answerapi')
    cy.wait('@spenddayapi')

    selector.elementsquestions.dayspend()
    selector.elements.indoors_wtoutAC().click()     //environment selection
    cy.wait('@answerapi')
    cy.wait('@lifestyleapi')

    selector.elementsquestions.lifestylepart()
    selector.elements.lifestyle_regular_workout().click()   //lifestyle selection
    selector.elements.continue_btn().click()               //continue button
    cy.wait('@answerapi')
    cy.wait('@makeupapi')
    
    selector.elementsquestions.makeup()
    selector.elements.wear_makeup_occasionally().click()    //makeup wearing selection
    cy.wait('@answerapi')
    cy.wait('@smokeapi')

    selector.elementsquestions.smoke()
    selector.elements.smoke_occasionally().click()          //smoking selection
    cy.wait('@answerapi')
    cy.wait('@productpreferenceapi') 

    selector.elementsquestions.productpreference()
    selector.elements.product_preference_none().click()      //product preference selection
    cy.wait('@answerapi')
    

    selector.elements.staying_month_textbox().clear().type('Lahore')     //click on text box
    selector.genericwait()
    selector.elements.city_selection().click()         //city selection from dropdown
    selector.genericwait()
    selector.elements.continue_btn().click()     //continue bbutton
    cy.wait('@>20weatherapi')
    selector.elements.continue_btn().click()     //continue button
    cy.wait('@mp4videoapi')

    selector.elements.skipto_results_btn().click()      // skip to results button
    cy.wait('@resultpage')
    cy.wait('@resultonproductpage')
    
    selector.producttype.dayserum().should('exist')           //verifing the product type
    selector.producttype.nightserum().should('exist')          //verifing the product type
    selector.producttype.moisturiser().should('exist')         //verifing the product type
    //selector.producttype.nightcream().should('exist')           //verifing the product type
    selector.genericwait()


    selector.elements.add_day_night_set().click()               //add product set button
    cy.wait('@addsetbtnapi')
    
    selector.elements.product_btn().click()                    //product button
    cy.wait('@resultonproductpage')
     

    selector.productname.day_dropofbalance().should('exist')       //verifing the day serum 
    selector.productname.crazyrichmoisturiser().should('exist')     //verifing the day cream
    selector.productname.dropofyouth().should('exist')         //verifing the night serum
    selector.productname.dndnights().should('exist')              //verifing the night cream
    cy.wait(3000)

}


testcase18()
{
    selector.assessment_apis()              //inculuded assessment/result/answer's api's
    selector.elements.gender_male().click() //gender selection
    cy.wait('@answerapi')
    cy.wait('@agequestionapi')

    selector.elementsquestions.age()
    selector.elements.age_any().click()   //age selection
    cy.wait('@answerapi')
    cy.wait('@cheeksapi')

    selector.elementsquestions.cheeksinthemorning()
    selector.elements.cheeks_morning_dry().click()  //cheeks selection
    cy.wait('@answerapi')
    cy.wait('@tzoneapi')

    selector.elementsquestions.tzone()
    selector.elements.tzone_normal().click()   //tzone selection
    cy.wait('@answerapi')
    cy.wait('@skinconcernapi')

    selector.elementsquestions.top2skinconcerns()
    selector.elements.top2_skin_concerns_wrinkles().click()  //skin concerns selection  1
    selector.elements.top2_skin_concerns_acne().click()  //skin concerns selection   2
    cy.wait('@answerapi')
    cy.wait('@getacneapi')

     
    selector.elementsquestions.getacne()
    selector.elements.get_acne_always().click()  // select acny stay period
    cy.wait('@answerapi')
    cy.wait('@describeacneapi')


    selector.elementsquestions.describeacne()
    selector.elements.acnehardones().click()     //select acne type
    cy.wait('@answerapi')
    cy.wait('@skinshadeapi')

    selector.elementsquestions.skinshade()
    selector.elements.skishade_2nd().click()     //skin shade selection
    cy.wait('@answerapi')
    cy.wait('@reactionapi')

    selector.elementsquestions.skinreaction()
    selector.elements.skinReactions_no().click()   //skin reaction selection Yes or No
    cy.wait('@answerapi')
    cy.wait('@stressapi')

    selector.elementsquestions.stress()
    selector.elements.little_stress().click()    // stress selection
    cy.wait('@answerapi')
    cy.wait('@sleepapi')

    selector.elementsquestions.sleep()
    selector.elements.sleep_5to6().click()      //sleep selection
    cy.wait('@answerapi')
    cy.wait('@waterapi')

    selector.elementsquestions.waterconsumption()
    selector.elements.water_consumption().click()    //water consumption selection
    cy.wait('@answerapi')
    cy.wait('@spenddayapi')

    selector.elementsquestions.dayspend()
    selector.elements.indoors_wtoutAC().click()     //environment selection
    cy.wait('@answerapi')
    cy.wait('@lifestyleapi')

    selector.elementsquestions.lifestylepart()
    selector.elements.lifestyle_regular_workout().click()   //lifestyle selection
    selector.elements.continue_btn().click()               //continue button
    cy.wait('@answerapi')
    cy.wait('@makeupapi')
    
    selector.elementsquestions.makeup()
    selector.elements.wear_makeup_occasionally().click()    //makeup wearing selection
    cy.wait('@answerapi')
    cy.wait('@smokeapi')

    selector.elementsquestions.smoke()
    selector.elements.smoke_occasionally().click()          //smoking selection
    cy.wait('@answerapi')
    cy.wait('@productpreferenceapi') 

    selector.elementsquestions.productpreference()
    selector.elements.product_preference_vegan().click()      //product preference selection
    selector.elements.continue_btn().click()           //continue button
    cy.wait('@answerapi')

    selector.elements.staying_month_textbox().clear().type('Lahore')     //click on text box
    selector.genericwait()
    selector.elements.city_selection().click()         //city selection from dropdown
    selector.genericwait()
    selector.elements.continue_btn().click()     //continue bbutton
    cy.wait('@>20weatherapi')
    selector.elements.continue_btn().click()     //continue button
    cy.wait('@mp4videoapi')

    selector.elements.skipto_results_btn().click()      // skip to results button
    cy.wait('@resultpage')
    cy.wait('@resultonproductpage')
    
    selector.producttype.dayserum().should('exist')           //verifing the product type
    selector.producttype.nightserum().should('exist')          //verifing the product type
    selector.producttype.moisturiser().should('exist')         //verifing the product type
    //selector.producttype.nightcream().should('exist')           //verifing the product type
    selector.genericwait()


    selector.elements.add_day_night_set().click()               //add product set button
    cy.wait('@addsetbtnapi')
    
    selector.elements.product_btn().click()                    //product button
    cy.wait('@resultonproductpage')
     

    selector.productname.day_dropofbalance().should('exist')       //verifing the day serum 
    selector.productname.crazyrichmoisturiser().should('exist')     //verifing the day cream
    selector.productname.nightdropoflight().should('exist')         //verifing the night serum
    selector.productname.dndnights().should('exist')              //verifing the night cream
    cy.wait(3000)

}


testcase19()
{
    selector.assessment_apis()              //inculuded assessment/result/answer's api's
    selector.elements.gender_male().click() //gender selection
    cy.wait('@answerapi')
    cy.wait('@agequestionapi')

    selector.elementsquestions.age()
    selector.elements.age_any().click()   //age selection
    cy.wait('@answerapi')
    cy.wait('@cheeksapi')

    selector.elementsquestions.cheeksinthemorning()
    selector.elements.cheeks_morning_dry().click()  //cheeks selection
    cy.wait('@answerapi')
    cy.wait('@tzoneapi')

    selector.elementsquestions.tzone()
    selector.elements.tzone_normal().click()   //tzone selection
    cy.wait('@answerapi')
    cy.wait('@skinconcernapi')

    selector.elementsquestions.top2skinconcerns()
    selector.elements.top2_skin_concerns_wrinkles().click()  //skin concerns selection  1
    selector.elements.top2_skin_concerns_acne().click()  //skin concerns selection   2
    cy.wait('@answerapi')
    cy.wait('@getacneapi')

    
    
    selector.elementsquestions.getacne()
    selector.elements.get_acne_always().click()  // select acny stay period
    cy.wait('@answerapi')
    cy.wait('@describeacneapi')


    selector.elementsquestions.describeacne()
    selector.elements.acnehardones().click()     //select acne type
     cy.wait('@answerapi')
    cy.wait('@skinshadeapi')

    selector.elementsquestions.skinshade()
    selector.elements.skishade_2nd().click()     //skin shade selection
    cy.wait('@answerapi')
    cy.wait('@reactionapi')

    selector.elementsquestions.skinreaction()
    selector.elements.skinReactions_no().click()   //skin reaction selection Yes or No
    cy.wait('@answerapi')
    cy.wait('@stressapi')

    selector.elementsquestions.stress()
    selector.elements.little_stress().click()    // stress selection
    cy.wait('@answerapi')
    cy.wait('@sleepapi')

    selector.elementsquestions.sleep()
    selector.elements.sleep_5to6().click()      //sleep selection
    cy.wait('@answerapi')
    cy.wait('@waterapi')

    selector.elementsquestions.waterconsumption()
    selector.elements.water_consumption().click()    //water consumption selection
    cy.wait('@answerapi')
    cy.wait('@spenddayapi')

    selector.elementsquestions.dayspend()
    selector.elements.indoors_wtoutAC().click()     //environment selection
    cy.wait('@answerapi')
    cy.wait('@lifestyleapi')

    selector.elementsquestions.lifestylepart()
    selector.elements.lifestyle_regular_workout().click()   //lifestyle selection
    selector.elements.continue_btn().click()               //continue button
    cy.wait('@answerapi')
    cy.wait('@makeupapi')
    
    selector.elementsquestions.makeup()
    selector.elements.wear_makeup_occasionally().click()    //makeup wearing selection
    cy.wait('@answerapi')
    cy.wait('@smokeapi')

    selector.elementsquestions.smoke()
    selector.elements.smoke_occasionally().click()          //smoking selection
    cy.wait('@answerapi')
    cy.wait('@productpreferenceapi') 

    selector.elementsquestions.productpreference()
    selector.elements.product_preference_pregnancysafe().click()      //product preference selection
    selector.elements.continue_btn().click()           //continue button
    

    selector.elements.staying_month_textbox().clear().type('Lahore')     //click on text box
    selector.genericwait()
    selector.elements.city_selection().click()         //city selection from dropdown
    selector.genericwait()
    selector.elements.continue_btn().click()     //continue bbutton
    cy.wait('@>20weatherapi')
    selector.elements.continue_btn().click()     //continue button
    cy.wait('@mp4videoapi')

    selector.elements.skipto_results_btn().click()      // skip to results button
    cy.wait('@resultpage')
    cy.wait('@resultonproductpage')
    
    selector.producttype.dayserum().should('exist')           //verifing the product type
    selector.producttype.nightserum().should('exist')          //verifing the product type
    selector.producttype.moisturiser().should('exist')         //verifing the product type
    //selector.producttype.nightcream().should('exist')           //verifing the product type
    selector.genericwait()


    selector.elements.add_day_night_set().click()               //add product set button
    cy.wait('@addsetbtnapi')
    
    selector.elements.product_btn().click()                    //product button
    cy.wait('@resultonproductpage')
     

    selector.productname.day_dropofbalance().should('exist')       //verifing the day serum 
    selector.productname.crazyrichmoisturiser().should('exist')     //verifing the day cream
    selector.productname.nightdropoflight().should('exist')         //verifing the night serum
    selector.productname.milkyway().should('exist')              //verifing the night cream
    cy.wait(3000)

}


testcase21()
{
    selector.assessment_apis()              //inculuded assessment/result/answer's api's
    selector.elements.gender_male().click() //gender selection
    cy.wait('@answerapi')
    cy.wait('@agequestionapi')

    selector.elementsquestions.age()
    selector.elements.age_any().click()   //age selection
    cy.wait('@answerapi')
    cy.wait('@cheeksapi')

    selector.elementsquestions.cheeksinthemorning()
    selector.elements.cheeks_morning_dry().click()  //cheeks selection
    cy.wait('@answerapi')
    cy.wait('@tzoneapi')

    selector.elementsquestions.tzone()
    selector.elements.tzone_oily().click()   //tzone selection
    cy.wait('@answerapi')
    cy.wait('@skinconcernapi')

    selector.elementsquestions.top2skinconcerns()
    selector.elements.top2_skin_concerns_wrinkles().click()  //skin concerns selection  1
    selector.elements.top2_skin_concerns_acne().click()  //skin concerns selection   2
    cy.wait('@answerapi')
    cy.wait('@getacneapi')
  
    
    selector.elementsquestions.getacne()
    selector.elements.get_acne_always().click()  // select acny stay period
    cy.wait('@answerapi')
    cy.wait('@describeacneapi')


    selector.elementsquestions.describeacne()
    selector.elements.acnehardones().click()     //select acne type
     cy.wait('@answerapi')
    cy.wait('@skinshadeapi')

    selector.elementsquestions.skinshade()
    selector.elements.skishade_2nd().click()     //skin shade selection
    cy.wait('@answerapi')
    cy.wait('@reactionapi')

    selector.elementsquestions.skinreaction()
    selector.elements.skinReactions_yes().click()   //skin reaction selection Yes or No
    cy.wait('@answerapi')
    cy.wait('@ingredientapi')

    selector.elementsquestions.ingredients()
    selector.elements.ingredients_salicylicacid().click()    //ingredients selection
    selector.elements.continue_btn().click()     //continue button
    cy.wait('@answerapi')
    cy.wait('@stressapi')
    
    selector.elementsquestions.stress()
    selector.elements.little_stress().click()    // stress selection
    cy.wait('@answerapi')
    cy.wait('@sleepapi')

    selector.elementsquestions.sleep()
    selector.elements.sleep_5to6().click()      //sleep selection
    cy.wait('@answerapi')
    cy.wait('@waterapi')

    selector.elementsquestions.waterconsumption()
    selector.elements.water_consumption().click()    //water consumption selection
    cy.wait('@answerapi')
    cy.wait('@spenddayapi')

    selector.elementsquestions.dayspend()
    selector.elements.indoors_wtoutAC().click()     //environment selection
    cy.wait('@answerapi')
    cy.wait('@lifestyleapi')

    selector.elementsquestions.lifestylepart()
    selector.elements.lifestyle_regular_workout().click()   //lifestyle selection
    selector.elements.continue_btn().click()               //continue button
    cy.wait('@answerapi')
    cy.wait('@makeupapi')
    
    selector.elementsquestions.makeup()
    selector.elements.wear_makeup_occasionally().click()    //makeup wearing selection
    cy.wait('@answerapi')
    cy.wait('@smokeapi')

    selector.elementsquestions.smoke()
    selector.elements.smoke_occasionally().click()          //smoking selection
    cy.wait('@answerapi')
    cy.wait('@productpreferenceapi') 

    selector.elementsquestions.productpreference()
    selector.elements.product_preference_none().click()      //product preference selection
    cy.wait('@answerapi')
    

    selector.elements.staying_month_textbox().clear().type('Lahore')     //click on text box
    selector.genericwait()
    selector.elements.city_selection().click()         //city selection from dropdown
    selector.genericwait()
    selector.elements.continue_btn().click()     //continue bbutton
    cy.wait('@>20weatherapi')
    selector.elements.continue_btn().click()     //continue button
    cy.wait('@mp4videoapi')

    selector.elements.skipto_results_btn().click()      // skip to results button
    cy.wait('@resultpage')
    cy.wait('@resultonproductpage')
    
    selector.producttype.dayserum().should('exist')           //verifing the product type
    selector.producttype.nightserum().should('exist')          //verifing the product type
    selector.producttype.moisturiser().should('exist')         //verifing the product type
    //selector.producttype.nightcream().should('exist')           //verifing the product type
    selector.genericwait()


    selector.elements.add_day_night_set().click()               //add product set button
    cy.wait('@addsetbtnapi')
    
    selector.elements.product_btn().click()                    //product button
    cy.wait('@resultonproductpage')     

    selector.productname.daydropofsoftness().should('exist')       //verifing the day serum 
    selector.productname.dewdatemoisturiser().should('exist')     //verifing the day cream
    selector.productname.dropofyouth().should('exist')         //verifing the night serum
    selector.productname.milkyway().should('exist')              //verifing the night cream
    cy.wait(3000)

}


testcase22()
{
    selector.assessment_apis()              //inculuded assessment/result/answer's api's
    selector.elements.gender_male().click() //gender selection
    cy.wait('@answerapi')
    cy.wait('@agequestionapi')

    selector.elementsquestions.age()
    selector.elements.age_any().click()   //age selection
    cy.wait('@answerapi')
    cy.wait('@cheeksapi')

    selector.elementsquestions.cheeksinthemorning()
    selector.elements.cheeks_morning_dry().click()  //cheeks selection
    cy.wait('@answerapi')
    cy.wait('@tzoneapi')

    selector.elementsquestions.tzone()
    selector.elements.tzone_oily().click()   //tzone selection
    cy.wait('@answerapi')
    cy.wait('@skinconcernapi')

    selector.elementsquestions.top2skinconcerns()
    selector.elements.top2_skin_concerns_wrinkles().click()  //skin concerns selection  1
    selector.elements.top2_skin_concerns_acne().click()  //skin concerns selection   2
    cy.wait('@answerapi')
    cy.wait('@getacneapi')

     
    selector.elementsquestions.getacne()
    selector.elements.get_acne_always().click()  // select acny stay period
    cy.wait('@answerapi')
    cy.wait('@describeacneapi')


    selector.elementsquestions.describeacne()
    selector.elements.acnehardones().click()     //select acne type
     cy.wait('@answerapi')
    cy.wait('@skinshadeapi')

    selector.elementsquestions.skinshade()
    selector.elements.skishade_2nd().click()     //skin shade selection
    cy.wait('@answerapi')
    cy.wait('@reactionapi')

    selector.elementsquestions.skinreaction()
    selector.elements.skinReactions_yes().click()   //skin reaction selection Yes or No
    cy.wait('@answerapi')
    cy.wait('@ingredientapi')

    selector.elementsquestions.ingredients()
    selector.elements.ingredients_salicylicacid().click()    //ingredients selection
    selector.elements.continue_btn().click()     //continue button
    cy.wait('@answerapi')
    cy.wait('@stressapi')

    selector.elementsquestions.stress()
    selector.elements.little_stress().click()    // stress selection
    cy.wait('@answerapi')
    cy.wait('@sleepapi')

    selector.elementsquestions.sleep()
    selector.elements.sleep_5to6().click()      //sleep selection
    cy.wait('@answerapi')
    cy.wait('@waterapi')

    selector.elementsquestions.waterconsumption()
    selector.elements.water_consumption().click()    //water consumption selection
    cy.wait('@answerapi')
    cy.wait('@spenddayapi')

    selector.elementsquestions.dayspend()
    selector.elements.indoors_wtoutAC().click()     //environment selection
    cy.wait('@answerapi')
    cy.wait('@lifestyleapi')

    selector.elementsquestions.lifestylepart()
    selector.elements.lifestyle_regular_workout().click()   //lifestyle selection
    selector.elements.continue_btn().click()               //continue button
    cy.wait('@answerapi')
    cy.wait('@makeupapi')
    
    selector.elementsquestions.makeup()
    selector.elements.wear_makeup_occasionally().click()    //makeup wearing selection
    cy.wait('@answerapi')
    cy.wait('@smokeapi')

    selector.elementsquestions.smoke()
    selector.elements.smoke_occasionally().click()          //smoking selection
    cy.wait('@answerapi')
    cy.wait('@productpreferenceapi') 

    selector.elementsquestions.productpreference()
    selector.elements.product_preference_vegan().click()      //product preference selection
    selector.elements.continue_btn().click()                 //continue bbutton
    cy.wait('@answerapi')

    selector.elements.staying_month_textbox().clear().type('Lahore')     //click on text box
    selector.genericwait()
    selector.elements.city_selection().click()         //city selection from dropdown
    selector.genericwait()
    selector.elements.continue_btn().click()     //continue bbutton
    cy.wait('@>20weatherapi')
    selector.elements.continue_btn().click()     //continue button
    cy.wait('@mp4videoapi')

    selector.elements.skipto_results_btn().click()      // skip to results button
    cy.wait('@resultpage')
    cy.wait('@resultonproductpage')
    
    selector.producttype.dayserum().should('exist')           //verifing the product type
    selector.producttype.nightserum().should('exist')          //verifing the product type
    selector.producttype.moisturiser().should('exist')         //verifing the product type
    //selector.producttype.nightcream().should('exist')           //verifing the product type
    selector.genericwait()


    selector.elements.add_day_night_set().click()               //add product set button
    cy.wait('@addsetbtnapi')
    
    selector.elements.product_btn().click()                    //product button
    cy.wait('@resultonproductpage')
     

    selector.productname.daydropofsoftness().should('exist')       //verifing the day serum 
    selector.productname.dewdatemoisturiser().should('exist')     //verifing the day cream
    selector.productname.nightdropoflight().should('exist')       //verifing the night serum
    selector.productname.milkyway().should('exist')              //verifing the night cream
    cy.wait(3000)

}


testcase23()
{
    selector.assessment_apis()              //inculuded assessment/result/answer's api's
    selector.elements.gender_male().click() //gender selection
    cy.wait('@answerapi')
    cy.wait('@agequestionapi')

    selector.elementsquestions.age()
    selector.elements.age_any().click()   //age selection
    cy.wait('@answerapi')
    cy.wait('@cheeksapi')

    selector.elementsquestions.cheeksinthemorning()
    selector.elements.cheeks_morning_dry().click()  //cheeks selection
    cy.wait('@answerapi')
    cy.wait('@tzoneapi')

    selector.elementsquestions.tzone()
    selector.elements.tzone_oily().click()   //tzone selection
    cy.wait('@answerapi')
    cy.wait('@skinconcernapi')

    selector.elementsquestions.top2skinconcerns()
    selector.elements.top2_skin_concerns_wrinkles().click()  //skin concerns selection  1
    selector.elements.top2_skin_concerns_acne().click()  //skin concerns selection   2
    cy.wait('@answerapi')
    cy.wait('@getacneapi')

    
    selector.elementsquestions.getacne()
    selector.elements.get_acne_always().click()  // select acny stay period
    cy.wait('@answerapi')
    cy.wait('@describeacneapi')


    selector.elementsquestions.describeacne()
    selector.elements.acnehardones().click()     //select acne type
    cy.wait('@answerapi')
    cy.wait('@skinshadeapi')

    selector.elementsquestions.skinshade()
    selector.elements.skishade_2nd().click()     //skin shade selection
    cy.wait('@answerapi')
    cy.wait('@reactionapi')

    selector.elementsquestions.skinreaction()
    selector.elements.skinReactions_yes().click()   //skin reaction selection Yes or No
    cy.wait('@answerapi')
    cy.wait('@ingredientapi')

    selector.elementsquestions.ingredients()
    selector.elements.ingredients_salicylicacid().click()    //ingredients selection
    selector.elements.continue_btn().click()     //continue button
    cy.wait('@answerapi')
    cy.wait('@stressapi')
    
    selector.elementsquestions.stress()
    selector.elements.little_stress().click()    // stress selection
    cy.wait('@answerapi')
    cy.wait('@sleepapi')

    selector.elementsquestions.sleep()
    selector.elements.sleep_5to6().click()      //sleep selection
    cy.wait('@answerapi')
    cy.wait('@waterapi')

    selector.elementsquestions.waterconsumption()
    selector.elements.water_consumption().click()    //water consumption selection
    cy.wait('@answerapi')
    cy.wait('@spenddayapi')

    selector.elementsquestions.dayspend()
    selector.elements.indoors_wtoutAC().click()     //environment selection
    cy.wait('@answerapi')
    cy.wait('@lifestyleapi')

    selector.elementsquestions.lifestylepart()
    selector.elements.lifestyle_regular_workout().click()   //lifestyle selection
    selector.elements.continue_btn().click()               //continue button
    cy.wait('@answerapi')
    cy.wait('@makeupapi')
    
    selector.elementsquestions.makeup()
    selector.elements.wear_makeup_occasionally().click()    //makeup wearing selection
    cy.wait('@answerapi')
    cy.wait('@smokeapi')

    selector.elementsquestions.smoke()
    selector.elements.smoke_occasionally().click()          //smoking selection
    cy.wait('@answerapi')
    cy.wait('@productpreferenceapi') 

    selector.elementsquestions.productpreference()
    selector.elements.product_preference_pregnancysafe().click()      //product preference selection
    selector.elements.continue_btn().click()                             //continue bbutton
    cy.wait('@answerapi')

    selector.elements.staying_month_textbox().clear().type('Lahore')     //click on text box
    selector.genericwait()
    selector.elements.city_selection().click()         //city selection from dropdown
    selector.genericwait()
    selector.elements.continue_btn().click()     //continue bbutton
    cy.wait('@>20weatherapi')
    selector.elements.continue_btn().click()     //continue button
    cy.wait('@mp4videoapi')

    selector.elements.skipto_results_btn().click()      // skip to results button
    cy.wait('@resultpage')
    cy.wait('@resultonproductpage')
    
    selector.producttype.dayserum().should('exist')           //verifing the product type
    selector.producttype.nightserum().should('exist')          //verifing the product type
    selector.producttype.moisturiser().should('exist')         //verifing the product type
    //selector.producttype.nightcream().should('exist')           //verifing the product type
    selector.genericwait()


    selector.elements.add_day_night_set().click()               //add product set button
    cy.wait('@addsetbtnapi')
    
    selector.elements.product_btn().click()                    //product button
    cy.wait('@resultonproductpage')
     

    selector.productname.daydropofsoftness().should('exist')       //verifing the day serum 
    selector.productname.dewdatemoisturiser().should('exist')     //verifing the day cream
    selector.productname.nightdropoflight().should('exist')       //verifing the night serum
    selector.productname.milkyway().should('exist')              //verifing the night cream
    cy.wait(3000)

}


testcase24()
{
    selector.assessment_apis()              //inculuded assessment/result/answer's api's
    selector.elements.gender_male().click() //gender selection
    cy.wait('@answerapi')
    cy.wait('@agequestionapi')

    selector.elementsquestions.age()
    selector.elements.age_any().click()   //age selection
    cy.wait('@answerapi')
    cy.wait('@cheeksapi')

    selector.elementsquestions.cheeksinthemorning()
    selector.elements.cheeks_morning_dry().click()  //cheeks selection
    cy.wait('@answerapi')
    cy.wait('@tzoneapi')

    selector.elementsquestions.tzone()
    selector.elements.tzone_veryoily().click()   //tzone selection
    cy.wait('@answerapi')
    cy.wait('@skinconcernapi')

    selector.elementsquestions.top2skinconcerns()
    selector.elements.top2_skin_concerns_wrinkles().click()  //skin concerns selection  1
    selector.elements.top2_skin_concerns_pigmentation().click()  //skin concerns selection   2
    cy.wait('@answerapi')
    cy.wait('@skinshadeapi')

    selector.elementsquestions.skinshade()
    selector.elements.skishade_2nd().click()     //skin shade selection
    cy.wait('@answerapi')
    cy.wait('@reactionapi')

    selector.elementsquestions.skinreaction()
    selector.elements.skinReactions_yes().click()   //skin reaction selection Yes or No
    cy.wait('@answerapi')
    cy.wait('@ingredientapi')
    
    selector.elementsquestions.ingredients()
    selector.elements.ingredients_retinol().click()    //ingredients selection
    selector.elements.continue_btn().click()     //continue button
    cy.wait('@answerapi')
    cy.wait('@stressapi')

    selector.elementsquestions.stress()
    selector.elements.little_stress().click()    // stress selection
    cy.wait('@answerapi')
    cy.wait('@sleepapi')
    -
    selector.elementsquestions.sleep()
    selector.elements.sleep_5to6().click()      //sleep selection
    cy.wait('@answerapi')
    cy.wait('@waterapi')

    selector.elementsquestions.waterconsumption()
    selector.elements.water_consumption().click()    //water consumption selection
    cy.wait('@answerapi')
    cy.wait('@spenddayapi')

    selector.elementsquestions.dayspend()
    selector.elements.indoors_wtoutAC().click()     //environment selection
    cy.wait('@answerapi')
    cy.wait('@lifestyleapi')

    selector.elementsquestions.lifestylepart()
    selector.elements.lifestyle_regular_workout().click()   //lifestyle selection
    selector.elements.continue_btn().click()               //continue button
    cy.wait('@answerapi')
    cy.wait('@makeupapi')
    
    selector.elementsquestions.makeup()
    selector.elements.wear_makeup_occasionally().click()    //makeup wearing selection
    cy.wait('@answerapi')
    cy.wait('@smokeapi')

    selector.elementsquestions.smoke()
    selector.elements.smoke_occasionally().click()          //smoking selection
    cy.wait('@answerapi')
    cy.wait('@productpreferenceapi') 

    selector.elementsquestions.productpreference()
    selector.elements.product_preference_pregnancysafe().click()      //product preference selection
    selector.elements.continue_btn().click()                  //continue bbutton
    cy.wait('@answerapi')

    selector.elements.staying_month_textbox().clear().type('Zurich')     //click on text box
    selector.genericwait()
    selector.elements.city_selection().click()         //city selection from dropdown
    selector.genericwait()
    selector.elements.continue_btn().click()     //continue bbutton
    cy.wait('@<20weatherapi')
    selector.elements.continue_btn().click()     //continue button
    cy.wait('@mp4videoapi')

    selector.elements.skipto_results_btn().click()      // skip to results button
    cy.wait('@resultpage')
    cy.wait('@resultonproductpage')
    
    selector.producttype.dayserum().should('exist')           //verifing the product type
    selector.producttype.nightserum().should('exist')          //verifing the product type
    selector.producttype.moisturiser().should('exist')         //verifing the product type
    //selector.producttype.nightcream().should('exist')           //verifing the product type
    selector.genericwait()


    selector.elements.add_day_night_set().click()               //add product set button
    cy.wait('@addsetbtnapi')
    
    selector.elements.product_btn().click()                    //product button
    cy.wait('@resultonproductpage')    

    selector.productname.daydropoflight().should('exist')       //verifing the day serum 
    selector.productname.dewdatemoisturiser().should('exist')     //verifing the day cream
    selector.productname.nightdropofsoftness().should('exist')       //verifing the night serum
    selector.productname.milkyway().should('exist')              //verifing the night cream
    cy.wait(3000)

}


testcase25()
{
    selector.assessment_apis()              //inculuded assessment/result/answer's api's
    selector.elements.gender_male().click() //gender selection
    cy.wait('@answerapi')
    cy.wait('@agequestionapi')

    selector.elementsquestions.age()
    selector.elements.age_any().click()   //age selection
    cy.wait('@answerapi')
    cy.wait('@cheeksapi')

    selector.elementsquestions.cheeksinthemorning()
    selector.elements.cheeks_morning_dry().click()  //cheeks selection
    cy.wait('@answerapi')
    cy.wait('@tzoneapi')

    selector.elementsquestions.tzone()
    selector.elements.tzone_veryoily().click()   //tzone selection
    cy.wait('@answerapi')
    cy.wait('@skinconcernapi')

    selector.elementsquestions.top2skinconcerns()
    selector.elements.top2_skin_concerns_wrinkles().click()  //skin concerns selection  1
    selector.elements.top2_skin_concerns_pigmentation().click()  //skin concerns selection   2
    cy.wait('@answerapi')
    cy.wait('@skinshadeapi')

    selector.elementsquestions.skinshade()
    selector.elements.skishade_2nd().click()     //skin shade selection
    cy.wait('@answerapi')
    cy.wait('@reactionapi')

    selector.elementsquestions.skinreaction()
    selector.elements.skinReactions_yes().click()   //skin reaction selection Yes or No
    cy.wait('@answerapi')
    cy.wait('@ingredientapi')

    selector.elementsquestions.ingredients()
    selector.elements.ingredients_retinol().click()    //ingredients selection
    selector.elements.continue_btn().click()            //continue button
    cy.wait('@answerapi')
    cy.wait('@stressapi')
    
    selector.elementsquestions.stress()
    selector.elements.little_stress().click()    // stress selection
    cy.wait('@answerapi')
    cy.wait('@sleepapi')

    selector.elementsquestions.sleep()
    selector.elements.sleep_5to6().click()      //sleep selection
    cy.wait('@answerapi')
    cy.wait('@waterapi')

    selector.elementsquestions.waterconsumption()
    selector.elements.water_consumption().click()    //water consumption selection
    cy.wait('@answerapi')
    cy.wait('@spenddayapi')

    selector.elementsquestions.dayspend()
    selector.elements.indoors_wtoutAC().click()     //environment selection
    cy.wait('@answerapi')
    cy.wait('@lifestyleapi')

    selector.elementsquestions.lifestylepart()
    selector.elements.lifestyle_regular_workout().click()   //lifestyle selection
    selector.elements.continue_btn().click()               //continue button
    cy.wait('@answerapi')
    cy.wait('@makeupapi')
    
    selector.elementsquestions.makeup()
    selector.elements.wear_makeup_occasionally().click()    //makeup wearing selection
    cy.wait('@answerapi')
    cy.wait('@smokeapi')

    selector.elementsquestions.smoke()
    selector.elements.smoke_occasionally().click()          //smoking selection
    cy.wait('@answerapi')
    cy.wait('@productpreferenceapi') 

    selector.elementsquestions.productpreference()
    selector.elements.product_preference_pregnancysafe().click()      //product preference selection
    selector.elements.continue_btn().click()     //continue bbutton


    selector.elements.staying_month_textbox().clear().type('Lahore')     //click on text box
    selector.genericwait()
    selector.elements.city_selection().click()         //city selection from dropdown
    selector.genericwait()
    selector.elements.continue_btn().click()     //continue bbutton
    cy.wait('@>20weatherapi')
    selector.elements.continue_btn().click()     //continue button
    cy.wait('@mp4videoapi')

    selector.elements.skipto_results_btn().click()      // skip to results button
    cy.wait('@resultpage')
    cy.wait('@resultonproductpage')
    
    selector.producttype.dayserum().should('exist')           //verifing the product type
    selector.producttype.nightserum().should('exist')          //verifing the product type
    selector.producttype.moisturiser().should('exist')         //verifing the product type
    //selector.producttype.nightcream().should('exist')           //verifing the product type
    selector.genericwait()


    selector.elements.add_day_night_set().click()               //add product set button
    cy.wait('@addsetbtnapi')
    
    selector.elements.product_btn().click()                    //product button
    cy.wait('@resultonproductpage')
     

    selector.productname.daydropoflight().should('exist')       //verifing the day serum 
    selector.productname.mm().should('exist')                   //verifing the day cream
    selector.productname.nightdropofsoftness().should('exist')       //verifing the night serum
    selector.productname.milkyway().should('exist')              //verifing the night cream
    cy.wait(3000)

}


testcase26()
{
    selector.assessment_apis()              //inculuded assessment/result/answer's api's
    selector.elements.gender_male().click() //gender selection
    cy.wait('@answerapi')
    cy.wait('@agequestionapi')

    selector.elementsquestions.age()
    selector.elements.age_any().click()   //age selection
    cy.wait('@answerapi')
    cy.wait('@cheeksapi')

    selector.elementsquestions.cheeksinthemorning()
    selector.elements.cheeks_morning_normal().click()  //cheeks selection
    cy.wait('@answerapi')
    cy.wait('@tzoneapi')

    selector.elementsquestions.tzone()
    selector.elements.tzone_verydry().click()   //tzone selection
    cy.wait('@answerapi')
    cy.wait('@skinconcernapi')


    selector.elementsquestions.top2skinconcerns()
    selector.elements.top2_skin_concerns_wrinkles().click()  //skin concerns selection  1
    selector.elements.top2_skin_concerns_pigmentation().click()  //skin concerns selection   2
    cy.wait('@answerapi')
    cy.wait('@skinshadeapi')

    selector.elementsquestions.skinshade()
    selector.elements.skishade_2nd().click()     //skin shade selection
    cy.wait('@answerapi')
    cy.wait('@reactionapi')

    selector.elementsquestions.skinreaction()
    selector.elements.skinReactions_no().click()   //skin reaction selection Yes or No
    cy.wait('@answerapi')
    cy.wait('@stressapi')

    selector.elementsquestions.stress()
    selector.elements.little_stress().click()    // stress selection
    cy.wait('@answerapi')
    cy.wait('@sleepapi')

    selector.elementsquestions.sleep()
    selector.elements.sleep_5to6().click()      //sleep selection
    cy.wait('@answerapi')
    cy.wait('@waterapi')

    selector.elementsquestions.waterconsumption()
    selector.elements.water_consumption().click()    //water consumption selection
    cy.wait('@answerapi')
    cy.wait('@spenddayapi')

    selector.elementsquestions.dayspend()
    selector.elements.indoors_wtoutAC().click()     //environment selection
    cy.wait('@answerapi')
    cy.wait('@lifestyleapi')

    selector.elementsquestions.lifestylepart()
    selector.elements.lifestyle_regular_workout().click()   //lifestyle selection
    selector.elements.continue_btn().click()               //continue button
    cy.wait('@answerapi')
    cy.wait('@makeupapi')
    
    selector.elementsquestions.makeup()
    selector.elements.wear_makeup_occasionally().click()    //makeup wearing selection
    cy.wait('@answerapi')
    cy.wait('@smokeapi')

    selector.elementsquestions.smoke()
    selector.elements.smoke_occasionally().click()          //smoking selection
    cy.wait('@answerapi')
    cy.wait('@productpreferenceapi') 

    selector.elementsquestions.productpreference()
    selector.elements.product_preference_none().click()      //product preference selection
    cy.wait('@answerapi')


    selector.elements.staying_month_textbox().clear().type('Lahore')     //click on text box
    selector.genericwait()
    selector.elements.city_selection().click()         //city selection from dropdown
    selector.genericwait()
    selector.elements.continue_btn().click()     //continue bbutton
    cy.wait('@>20weatherapi')
    selector.elements.continue_btn().click()     //continue button
    cy.wait('@mp4videoapi')

    selector.elements.skipto_results_btn().click()      // skip to results button
    cy.wait('@resultpage')
    cy.wait('@resultonproductpage')
    
    selector.producttype.dayserum().should('exist')           //verifing the product type
    selector.producttype.nightserum().should('exist')          //verifing the product type
    selector.producttype.moisturiser().should('exist')         //verifing the product type
    //selector.producttype.nightcream().should('exist')           //verifing the product type
    selector.genericwait()


    selector.elements.add_day_night_set().click()               //add product set button
    cy.wait('@addsetbtnapi')
    
    selector.elements.product_btn().click()                    //product button
    cy.wait('@resultonproductpage')
     

    selector.productname.daydropoflight().should('exist')       //verifing the day serum 
    selector.productname.crazyrichmoisturiser().should('exist')      //verifing the day cream
    selector.productname.dropofyouth().should('exist')       //verifing the night serum
    selector.productname.dndnights().should('exist')              //verifing the night cream
    cy.wait(3000)

}


testcase27()
{
    selector.assessment_apis()              //inculuded assessment/result/answer's api's
    selector.elements.gender_male().click() //gender selection
    cy.wait('@answerapi')
    cy.wait('@agequestionapi')

    selector.elementsquestions.age()
    selector.elements.age_any().click()   //age selection
    cy.wait('@answerapi')
    cy.wait('@cheeksapi')

    selector.elementsquestions.cheeksinthemorning()
    selector.elements.cheeks_morning_normal().click()  //cheeks selection
    cy.wait('@answerapi')
    cy.wait('@tzoneapi')

    selector.elementsquestions.tzone()
    selector.elements.tzone_verydry().click()   //tzone selection
    cy.wait('@answerapi')
    cy.wait('@skinconcernapi')


    selector.elementsquestions.top2skinconcerns()
    selector.elements.top2_skin_concerns_wrinkles().click()  //skin concerns selection  1
    selector.elements.top2_skin_concerns_pigmentation().click()  //skin concerns selection   2
    cy.wait('@answerapi')
    cy.wait('@skinshadeapi')

    selector.elementsquestions.skinshade()
    selector.elements.skishade_2nd().click()     //skin shade selection
    cy.wait('@answerapi')
    cy.wait('@reactionapi')

    selector.elementsquestions.skinreaction()
    selector.elements.skinReactions_no().click()   //skin reaction selection Yes or No
    cy.wait('@answerapi')
    cy.wait('@stressapi')

    selector.elementsquestions.stress()
    selector.elements.little_stress().click()    // stress selection
    cy.wait('@answerapi')
    cy.wait('@sleepapi')

    selector.elementsquestions.sleep()
    selector.elements.sleep_5to6().click()      //sleep selection
    cy.wait('@answerapi')
    cy.wait('@waterapi')

    selector.elementsquestions.waterconsumption()
    selector.elements.water_consumption().click()    //water consumption selection
    cy.wait('@answerapi')
    cy.wait('@spenddayapi')

    selector.elementsquestions.dayspend()
    selector.elements.indoors_wtoutAC().click()     //environment selection
    cy.wait('@answerapi')
    cy.wait('@lifestyleapi')

    selector.elementsquestions.lifestylepart()
    selector.elements.lifestyle_regular_workout().click()   //lifestyle selection
    selector.elements.continue_btn().click()               //continue button
    cy.wait('@answerapi')
    cy.wait('@makeupapi')
    
    selector.elementsquestions.makeup()
    selector.elements.wear_makeup_occasionally().click()    //makeup wearing selection
    cy.wait('@answerapi')
    cy.wait('@smokeapi')

    selector.elementsquestions.smoke()
    selector.elements.smoke_occasionally().click()          //smoking selection
    cy.wait('@answerapi')
    cy.wait('@productpreferenceapi') 

    selector.elementsquestions.productpreference()
    selector.elements.product_preference_vegan().click()      //product preference selection
    selector.elements.continue_btn().click()     //continue bbutton
    cy.wait('@answerapi')


    selector.elements.staying_month_textbox().clear().type('Lahore')     //click on text box
    selector.genericwait()
    selector.elements.city_selection().click()         //city selection from dropdown
    selector.genericwait()
    selector.elements.continue_btn().click()     //continue bbutton
    cy.wait('@>20weatherapi')
    selector.elements.continue_btn().click()     //continue button
    cy.wait('@mp4videoapi')

    selector.elements.skipto_results_btn().click()      // skip to results button
    cy.wait('@resultpage')
    cy.wait('@resultonproductpage')
    
    selector.producttype.dayserum().should('exist')           //verifing the product type
    selector.producttype.nightserum().should('exist')          //verifing the product type
    selector.producttype.moisturiser().should('exist')         //verifing the product type
    //selector.producttype.nightcream().should('exist')           //verifing the product type
    selector.genericwait()


    selector.elements.add_day_night_set().click()               //add product set button
    cy.wait('@addsetbtnapi')
    
    selector.elements.product_btn().click()                    //product button
    cy.wait('@resultonproductpage')
     

    selector.productname.daydropoflight().should('exist')       //verifing the day serum 
    selector.productname.crazyrichmoisturiser().should('exist')      //verifing the day cream
    selector.productname.nightdropofsoftness().should('exist')       //verifing the night serum
    selector.productname.dndnights().should('exist')              //verifing the night cream
    cy.wait(3000)

}


testcase28()
{
    selector.assessment_apis()              //inculuded assessment/result/answer's api's
    selector.elements.gender_male().click() //gender selection
    cy.wait('@answerapi')
    cy.wait('@agequestionapi')

    selector.elementsquestions.age()
    selector.elements.age_any().click()   //age selection
    cy.wait('@answerapi')
    cy.wait('@cheeksapi')

    selector.elementsquestions.cheeksinthemorning()
    selector.elements.cheeks_morning_normal().click()  //cheeks selection
    cy.wait('@answerapi')
    cy.wait('@tzoneapi')

    selector.elementsquestions.tzone()
    selector.elements.tzone_verydry().click()   //tzone selection
    cy.wait('@answerapi')
    cy.wait('@skinconcernapi')


    selector.elementsquestions.top2skinconcerns()
    selector.elements.top2_skin_concerns_wrinkles().click()  //skin concerns selection  1
    selector.elements.top2_skin_concerns_pigmentation().click()  //skin concerns selection   2
    cy.wait('@answerapi')
    cy.wait('@skinshadeapi')

    selector.elementsquestions.skinshade()
    selector.elements.skishade_2nd().click()     //skin shade selection
    cy.wait('@answerapi')
    cy.wait('@reactionapi')

    selector.elementsquestions.skinreaction()
    selector.elements.skinReactions_no().click()   //skin reaction selection Yes or No
    cy.wait('@answerapi')
    cy.wait('@stressapi')

    selector.elementsquestions.stress()
    selector.elements.little_stress().click()    // stress selection
    cy.wait('@answerapi')
    cy.wait('@sleepapi')

    selector.elementsquestions.sleep()
    selector.elements.sleep_5to6().click()      //sleep selection
    cy.wait('@answerapi')
    cy.wait('@waterapi')

    selector.elementsquestions.waterconsumption()
    selector.elements.water_consumption().click()    //water consumption selection
    cy.wait('@answerapi')
    cy.wait('@spenddayapi')

    selector.elementsquestions.dayspend()
    selector.elements.indoors_wtoutAC().click()     //environment selection
    cy.wait('@answerapi')
    cy.wait('@lifestyleapi')

    selector.elementsquestions.lifestylepart()
    selector.elements.lifestyle_regular_workout().click()   //lifestyle selection
    selector.elements.continue_btn().click()               //continue button
    cy.wait('@answerapi')
    cy.wait('@makeupapi')
    
    selector.elementsquestions.makeup()
    selector.elements.wear_makeup_occasionally().click()    //makeup wearing selection
    cy.wait('@answerapi')
    cy.wait('@smokeapi')

    selector.elementsquestions.smoke()
    selector.elements.smoke_occasionally().click()          //smoking selection
    cy.wait('@answerapi')
    cy.wait('@productpreferenceapi') 

    selector.elementsquestions.productpreference()
    selector.elements.product_preference_pregnancysafe().click()      //product preference selection
    selector.elements.continue_btn().click()                          //continue button
    cy.wait('@answerapi')


    selector.elements.staying_month_textbox().clear().type('Lahore')     //click on text box
    selector.genericwait()
    selector.elements.city_selection().click()         //city selection from dropdown
    selector.genericwait()
    selector.elements.continue_btn().click()     //continue bbutton
    cy.wait('@>20weatherapi')
    selector.elements.continue_btn().click()     //continue button
    cy.wait('@mp4videoapi')

    selector.elements.skipto_results_btn().click()      // skip to results button
    cy.wait('@resultpage')
    cy.wait('@resultonproductpage')
    
    selector.producttype.dayserum().should('exist')           //verifing the product type
    selector.producttype.nightserum().should('exist')          //verifing the product type
    selector.producttype.moisturiser().should('exist')         //verifing the product type
    //selector.producttype.nightcream().should('exist')           //verifing the product type
    selector.genericwait()


    selector.elements.add_day_night_set().click()               //add product set button
    cy.wait('@addsetbtnapi')
    
    selector.elements.product_btn().click()                    //product button
    cy.wait('@resultonproductpage')
     

    selector.productname.daydropoflight().should('exist')       //verifing the day serum 
    selector.productname.crazyrichmoisturiser().should('exist')      //verifing the day cream
    selector.productname.nightdropofsoftness().should('exist')       //verifing the night serum
    selector.productname.milkyway().should('exist')              //verifing the night cream
    cy.wait(3000)

}


testcase29()
{
    selector.assessment_apis()              //inculuded assessment/result/answer's api's
    selector.elements.gender_male().click() //gender selection
    cy.wait('@answerapi')
    cy.wait('@agequestionapi')

    selector.elementsquestions.age()
    selector.elements.age_any().click()   //age selection
    cy.wait('@answerapi')
    cy.wait('@cheeksapi')

    selector.elementsquestions.cheeksinthemorning()
    selector.elements.cheeks_morning_normal().click()  //cheeks selection
    cy.wait('@answerapi')
    cy.wait('@tzoneapi')

    selector.elementsquestions.tzone()
    selector.elements.tzone_dry().click()   //tzone selection
    cy.wait('@answerapi')
    cy.wait('@skinconcernapi')

    selector.elementsquestions.top2skinconcerns()
    selector.elements.top2_skin_concerns_wrinkles().click()  //skin concerns selection  1
    selector.elements.top2_skin_concerns_pigmentation().click()  //skin concerns selection   2
    cy.wait('@answerapi')
    cy.wait('@skinshadeapi')

    selector.elementsquestions.skinshade()
    selector.elements.skishade_2nd().click()     //skin shade selection
    cy.wait('@answerapi')
    cy.wait('@reactionapi')

    selector.elementsquestions.skinreaction()
    selector.elements.skinReactions_yes().click()   //skin reaction selection Yes or No
    cy.wait('@answerapi')
    cy.wait('@ingredientapi')

    selector.elementsquestions.ingredients()
    selector.elements.ingredients_salicylicacid().click()    //ingredients selection
    selector.elements.continue_btn().click()                 //continue button
    cy.wait('@answerapi')
    cy.wait('@stressapi')

    selector.elementsquestions.stress()
    selector.elements.little_stress().click()    // stress selection
    cy.wait('@answerapi')
    cy.wait('@sleepapi')

    selector.elementsquestions.sleep()
    selector.elements.sleep_5to6().click()      //sleep selection
    cy.wait('@answerapi')
    cy.wait('@waterapi')

    selector.elementsquestions.waterconsumption()
    selector.elements.water_consumption().click()    //water consumption selection
    cy.wait('@answerapi')
    cy.wait('@spenddayapi')

    selector.elementsquestions.dayspend()
    selector.elements.indoors_wtoutAC().click()     //environment selection
    cy.wait('@answerapi')
    cy.wait('@lifestyleapi')

    selector.elementsquestions.lifestylepart()
    selector.elements.lifestyle_regular_workout().click()   //lifestyle selection
    selector.elements.continue_btn().click()               //continue button
    cy.wait('@answerapi')
    cy.wait('@makeupapi')
    
    selector.elementsquestions.makeup()
    selector.elements.wear_makeup_occasionally().click()    //makeup wearing selection
    cy.wait('@answerapi')
    cy.wait('@smokeapi')

    selector.elementsquestions.smoke()
    selector.elements.smoke_occasionally().click()          //smoking selection
    cy.wait('@answerapi')
    cy.wait('@productpreferenceapi') 

    selector.elementsquestions.productpreference()
    selector.elements.product_preference_none().click()      //product preference selection
    cy.wait('@answerapi')

    selector.elements.staying_month_textbox().clear().type('Lahore')     //click on text box
    selector.genericwait()
    selector.elements.city_selection().click()         //city selection from dropdown
    selector.genericwait()
    selector.elements.continue_btn().click()     //continue bbutton
    cy.wait('@>20weatherapi')
    selector.elements.continue_btn().click()     //continue button
    cy.wait('@mp4videoapi')

    selector.elements.skipto_results_btn().click()      // skip to results button
    cy.wait('@resultpage')
    cy.wait('@resultonproductpage')
    
    selector.producttype.dayserum().should('exist')           //verifing the product type
    selector.producttype.nightserum().should('exist')          //verifing the product type
    selector.producttype.moisturiser().should('exist')         //verifing the product type
    //selector.producttype.nightcream().should('exist')           //verifing the product type
    selector.genericwait()


    selector.elements.add_day_night_set().click()               //add product set button
    cy.wait('@addsetbtnapi')
    
    selector.elements.product_btn().click()                    //product button
    cy.wait('@resultonproductpage')
     

    selector.productname.daydropoflight().should('exist')       //verifing the day serum 
    selector.productname.dewdatemoisturiser().should('exist')      //verifing the day cream
    selector.productname.dropofyouth().should('exist')       //verifing the night serum
    selector.productname.dndnights().should('exist')              //verifing the night cream
    cy.wait(3000)

}



testcase30()
{
    selector.assessment_apis()              //inculuded assessment/result/answer's api's
    selector.elements.gender_male().click() //gender selection
    cy.wait('@answerapi')
    cy.wait('@agequestionapi')

    selector.elementsquestions.age()
    selector.elements.age_any().click()   //age selection
    cy.wait('@answerapi')
    cy.wait('@cheeksapi')

    selector.elementsquestions.cheeksinthemorning()
    selector.elements.cheeks_morning_normal().click()  //cheeks selection
    cy.wait('@answerapi')
    cy.wait('@tzoneapi')

    selector.elementsquestions.tzone()
    selector.elements.tzone_dry().click()   //tzone selection
    cy.wait('@answerapi')
    cy.wait('@skinconcernapi')

    selector.elementsquestions.top2skinconcerns()
    selector.elements.top2_skin_concerns_wrinkles().click()  //skin concerns selection  1
    selector.elements.top2_skin_concerns_pigmentation().click()  //skin concerns selection   2
    cy.wait('@answerapi')
    cy.wait('@skinshadeapi')

    selector.elementsquestions.skinshade()
    selector.elements.skishade_2nd().click()     //skin shade selection
    cy.wait('@answerapi')
    cy.wait('@reactionapi')

    selector.elementsquestions.skinreaction()
    selector.elements.skinReactions_yes().click()   //skin reaction selection Yes or No
    cy.wait('@answerapi')
    cy.wait('@ingredientapi')

    selector.elementsquestions.ingredients()
    selector.elements.ingredients_salicylicacid().click()    //ingredients selection
    selector.elements.continue_btn().click()                 //continue button
    cy.wait('@answerapi')
    cy.wait('@stressapi')

    selector.elementsquestions.stress()
    selector.elements.little_stress().click()    // stress selection
    cy.wait('@answerapi')
    cy.wait('@sleepapi')

    selector.elementsquestions.sleep()
    selector.elements.sleep_5to6().click()      //sleep selection
    cy.wait('@answerapi')
    cy.wait('@waterapi')

    selector.elementsquestions.waterconsumption()
    selector.elements.water_consumption().click()    //water consumption selection
    cy.wait('@answerapi')
    cy.wait('@spenddayapi')

    selector.elementsquestions.dayspend()
    selector.elements.indoors_wtoutAC().click()     //environment selection
    cy.wait('@answerapi')
    cy.wait('@lifestyleapi')

    selector.elementsquestions.lifestylepart()
    selector.elements.lifestyle_regular_workout().click()   //lifestyle selection
    selector.elements.continue_btn().click()               //continue button
    cy.wait('@answerapi')
    cy.wait('@makeupapi')
    
    selector.elementsquestions.makeup()
    selector.elements.wear_makeup_occasionally().click()    //makeup wearing selection
    cy.wait('@answerapi')
    cy.wait('@smokeapi')

    selector.elementsquestions.smoke()
    selector.elements.smoke_occasionally().click()          //smoking selection
    cy.wait('@answerapi')
    cy.wait('@productpreferenceapi') 

    selector.elementsquestions.productpreference()
    selector.elements.product_preference_vegan().click()      //product preference selection
    selector.elements.continue_btn().click()     //continue button
    cy.wait('@answerapi')


    selector.elements.staying_month_textbox().clear().type('Lahore')     //click on text box
    selector.genericwait()
    selector.elements.city_selection().click()         //city selection from dropdown
    selector.genericwait()
    selector.elements.continue_btn().click()     //continue bbutton
    cy.wait('@>20weatherapi')
    selector.elements.continue_btn().click()     //continue button
    cy.wait('@mp4videoapi')

    selector.elements.skipto_results_btn().click()      // skip to results button
    cy.wait('@resultpage')
    cy.wait('@resultonproductpage')
    
    selector.producttype.dayserum().should('exist')           //verifing the product type
    selector.producttype.nightserum().should('exist')          //verifing the product type
    selector.producttype.moisturiser().should('exist')         //verifing the product type
    //selector.producttype.nightcream().should('exist')           //verifing the product type
    selector.genericwait()


    selector.elements.add_day_night_set().click()               //add product set button
    cy.wait('@addsetbtnapi')
    
    selector.elements.product_btn().click()                    //product button
    cy.wait('@resultonproductpage')
     

    selector.productname.daydropoflight().should('exist')       //verifing the day serum 
    selector.productname.dewdatemoisturiser().should('exist')      //verifing the day cream
    selector.productname.nightdropofsoftness().should('exist')       //verifing the night serum
    selector.productname.dndnights().should('exist')              //verifing the night cream
    cy.wait(3000)

}


testcase31()
{
    selector.assessment_apis()              //inculuded assessment/result/answer's api's
    selector.elements.gender_male().click() //gender selection
    cy.wait('@answerapi')
    cy.wait('@agequestionapi')

    selector.elementsquestions.age()
    selector.elements.age_any().click()   //age selection
    cy.wait('@answerapi')
    cy.wait('@cheeksapi')

    selector.elementsquestions.cheeksinthemorning()
    selector.elements.cheeks_morning_normal().click()  //cheeks selection
    cy.wait('@answerapi')
    cy.wait('@tzoneapi')

    selector.elementsquestions.tzone()
    selector.elements.tzone_dry().click()   //tzone selection
    cy.wait('@answerapi')
    cy.wait('@skinconcernapi')

    selector.elementsquestions.top2skinconcerns()
    selector.elements.top2_skin_concerns_wrinkles().click()  //skin concerns selection  1
    selector.elements.top2_skin_concerns_pigmentation().click()  //skin concerns selection   2
    cy.wait('@answerapi')
    cy.wait('@skinshadeapi')

    selector.elementsquestions.skinshade()
    selector.elements.skishade_2nd().click()     //skin shade selection
    cy.wait('@answerapi')
    cy.wait('@reactionapi')

    selector.elementsquestions.skinreaction()
    selector.elements.skinReactions_yes().click()   //skin reaction selection Yes or No
    cy.wait('@answerapi')
    cy.wait('@ingredientapi')

    selector.elementsquestions.ingredients()
    selector.elements.ingredients_salicylicacid().click()    //ingredients selection
    selector.elements.continue_btn().click()                 //continue button
    cy.wait('@answerapi')
    cy.wait('@stressapi')

    selector.elementsquestions.stress()
    selector.elements.little_stress().click()    // stress selection
    cy.wait('@answerapi')
    cy.wait('@sleepapi')

    selector.elementsquestions.sleep()
    selector.elements.sleep_5to6().click()      //sleep selection
    cy.wait('@answerapi')
    cy.wait('@waterapi')

    selector.elementsquestions.waterconsumption()
    selector.elements.water_consumption().click()    //water consumption selection
    cy.wait('@answerapi')
    cy.wait('@spenddayapi')

    selector.elementsquestions.dayspend()
    selector.elements.indoors_wtoutAC().click()     //environment selection
    cy.wait('@answerapi')
    cy.wait('@lifestyleapi')

    selector.elementsquestions.lifestylepart()
    selector.elements.lifestyle_regular_workout().click()   //lifestyle selection
    selector.elements.continue_btn().click()               //continue button
    cy.wait('@answerapi')
    cy.wait('@makeupapi')
    
    selector.elementsquestions.makeup()
    selector.elements.wear_makeup_occasionally().click()    //makeup wearing selection
    cy.wait('@answerapi')
    cy.wait('@smokeapi')

    selector.elementsquestions.smoke()
    selector.elements.smoke_occasionally().click()          //smoking selection
    cy.wait('@answerapi')
    cy.wait('@productpreferenceapi') 

    selector.elementsquestions.productpreference()
    selector.elements.product_preference_pregnancysafe().click()      //product preference selection
    selector.elements.continue_btn().click()     //continue button
    cy.wait('@answerapi')


    selector.elements.staying_month_textbox().clear().type('Lahore')     //click on text box
    selector.genericwait()
    selector.elements.city_selection().click()         //city selection from dropdown
    selector.genericwait()
    selector.elements.continue_btn().click()     //continue bbutton
    cy.wait('@>20weatherapi')
    selector.elements.continue_btn().click()     //continue button
    cy.wait('@mp4videoapi')

    selector.elements.skipto_results_btn().click()      // skip to results button
    cy.wait('@resultpage')
    cy.wait('@resultonproductpage')
    
    selector.producttype.dayserum().should('exist')           //verifing the product type
    selector.producttype.nightserum().should('exist')          //verifing the product type
    selector.producttype.moisturiser().should('exist')         //verifing the product type
    //selector.producttype.nightcream().should('exist')           //verifing the product type
    selector.genericwait()


    selector.elements.add_day_night_set().click()               //add product set button
    cy.wait('@addsetbtnapi')
    
    selector.elements.product_btn().click()                    //product button
    cy.wait('@resultonproductpage')
     

    selector.productname.daydropoflight().should('exist')       //verifing the day serum 
    selector.productname.dewdatemoisturiser().should('exist')      //verifing the day cream
    selector.productname.nightdropofsoftness().should('exist')       //verifing the night serum
    selector.productname.milkyway().should('exist')              //verifing the night cream
    cy.wait(3000)

}


testcase32()
{
    selector.assessment_apis()              //inculuded assessment/result/answer's api's
    selector.elements.gender_male().click() //gender selection
    cy.wait('@answerapi')
    cy.wait('@agequestionapi')

    selector.elementsquestions.age()
    selector.elements.age_any().click()   //age selection
    cy.wait('@answerapi')
    cy.wait('@cheeksapi')

    selector.elementsquestions.cheeksinthemorning()
    selector.elements.cheeks_morning_normal().click()  //cheeks selection
    cy.wait('@answerapi')
    cy.wait('@tzoneapi')

    selector.elementsquestions.tzone()
    selector.elements.tzone_normal().click()   //tzone selection
    cy.wait('@answerapi')
    cy.wait('@skinconcernapi')

    selector.elementsquestions.top2skinconcerns()
    selector.elements.top2_skin_concerns_wrinkles().click()  //skin concerns selection  1
    selector.elements.top2_skin_concerns_blackWhitehead().click()  //skin concerns selection   2
    cy.wait('@answerapi')
    cy.wait('@skinshadeapi')

    selector.elementsquestions.skinshade()
    selector.elements.skishade_2nd().click()     //skin shade selection
    cy.wait('@answerapi')
    cy.wait('@reactionapi')

    selector.elementsquestions.skinreaction()
    selector.elements.skinReactions_yes().click()   //skin reaction selection Yes or No
    cy.wait('@answerapi')
    cy.wait('@ingredientapi')

    selector.elementsquestions.ingredients()
    selector.elements.ingredients_retinol().click()    //ingredients selection
    selector.elements.continue_btn().click()                 //continue button
    cy.wait('@answerapi')
    cy.wait('@stressapi')

    selector.elementsquestions.stress()
    selector.elements.little_stress().click()    // stress selection
    cy.wait('@answerapi')
    cy.wait('@sleepapi')

    selector.elementsquestions.sleep()
    selector.elements.sleep_5to6().click()      //sleep selection
    cy.wait('@answerapi')
    cy.wait('@waterapi')

    selector.elementsquestions.waterconsumption()
    selector.elements.water_consumption().click()    //water consumption selection
    cy.wait('@answerapi')
    cy.wait('@spenddayapi')

    selector.elementsquestions.dayspend()
    selector.elements.indoors_wtoutAC().click()     //environment selection
    cy.wait('@answerapi')
    cy.wait('@lifestyleapi')

    selector.elementsquestions.lifestylepart()
    selector.elements.lifestyle_regular_workout().click()   //lifestyle selection
    selector.elements.continue_btn().click()               //continue button
    cy.wait('@answerapi')
    cy.wait('@makeupapi')
    
    selector.elementsquestions.makeup()
    selector.elements.wear_makeup_occasionally().click()    //makeup wearing selection
    cy.wait('@answerapi')
    cy.wait('@smokeapi')

    selector.elementsquestions.smoke()
    selector.elements.smoke_occasionally().click()          //smoking selection
    cy.wait('@answerapi')
    cy.wait('@productpreferenceapi') 

    selector.elementsquestions.productpreference()
    selector.elements.product_preference_pregnancysafe().click()      //product preference selection
    selector.elements.continue_btn().click()     //continue button
    cy.wait('@answerapi')

    selector.elements.staying_month_textbox().clear().type('Lahore')     //click on text box
    selector.genericwait()
    selector.elements.city_selection().click()         //city selection from dropdown
    selector.genericwait()
    selector.elements.continue_btn().click()     //continue bbutton
    cy.wait('@>20weatherapi')
    selector.elements.continue_btn().click()     //continue button
    cy.wait('@mp4videoapi')

    selector.elements.skipto_results_btn().click()      // skip to results button
    cy.wait('@resultpage')
    cy.wait('@resultonproductpage')
    
    selector.producttype.dayserum().should('exist')           //verifing the product type
    selector.producttype.nightserum().should('exist')          //verifing the product type
    selector.producttype.moisturiser().should('exist')         //verifing the product type
    //selector.producttype.nightcream().should('exist')           //verifing the product type
    selector.genericwait()


    selector.elements.add_day_night_set().click()               //add product set button
    cy.wait('@addsetbtnapi')
    
    selector.elements.product_btn().click()                    //product button
    cy.wait('@resultonproductpage')
     

    selector.productname.daydropofperfection().should('exist')       //verifing the day serum 
    selector.productname.dewdatemoisturiser().should('exist')      //verifing the day cream
    selector.productname.nightdropoflight().should('exist')       //verifing the night serum
    selector.productname.milkyway().should('exist')              //verifing the night cream
    cy.wait(3000)

}


testcase33()
{
    selector.assessment_apis()              //inculuded assessment/result/answer's api's
    selector.elements.gender_male().click() //gender selection
    cy.wait('@answerapi')
    cy.wait('@agequestionapi')

    selector.elementsquestions.age()
    selector.elements.age_any().click()   //age selection
    cy.wait('@answerapi')
    cy.wait('@cheeksapi')

    selector.elementsquestions.cheeksinthemorning()
    selector.elements.cheeks_morning_normal().click()  //cheeks selection
    cy.wait('@answerapi')
    cy.wait('@tzoneapi')

    selector.elementsquestions.tzone()
    selector.elements.tzone_oily().click()   //tzone selection
    cy.wait('@answerapi')
    cy.wait('@skinconcernapi')

    selector.elementsquestions.top2skinconcerns()
    selector.elements.top2_skin_concerns_wrinkles().click()  //skin concerns selection  1
    selector.elements.top2_skin_concerns_blackWhitehead().click()  //skin concerns selection   2
    cy.wait('@answerapi')
    cy.wait('@skinshadeapi')

    selector.elementsquestions.skinshade()
    selector.elements.skishade_2nd().click()     //skin shade selection
    cy.wait('@answerapi')
    cy.wait('@reactionapi')

    selector.elementsquestions.skinreaction()
    selector.elements.skinReactions_no().click()   //skin reaction selection Yes or No
    cy.wait('@answerapi')
    cy.wait('@stressapi')

    selector.elementsquestions.stress()
    selector.elements.little_stress().click()    // stress selection
    cy.wait('@answerapi')
    cy.wait('@sleepapi')

    selector.elementsquestions.sleep()
    selector.elements.sleep_5to6().click()      //sleep selection
    cy.wait('@answerapi')
    cy.wait('@waterapi')

    selector.elementsquestions.waterconsumption()
    selector.elements.water_consumption().click()    //water consumption selection
    cy.wait('@answerapi')
    cy.wait('@spenddayapi')

    selector.elementsquestions.dayspend()
    selector.elements.indoors_wtoutAC().click()     //environment selection
    cy.wait('@answerapi')
    cy.wait('@lifestyleapi')

    selector.elementsquestions.lifestylepart()
    selector.elements.lifestyle_regular_workout().click()   //lifestyle selection
    selector.elements.continue_btn().click()               //continue button
    cy.wait('@answerapi')
    cy.wait('@makeupapi')
    
    selector.elementsquestions.makeup()
    selector.elements.wear_makeup_occasionally().click()    //makeup wearing selection
    cy.wait('@answerapi')
    cy.wait('@smokeapi')

    selector.elementsquestions.smoke()
    selector.elements.smoke_occasionally().click()          //smoking selection
    cy.wait('@answerapi')
    cy.wait('@productpreferenceapi') 

    selector.elementsquestions.productpreference()
    selector.elements.product_preference_none().click()      //product preference selection
    cy.wait('@answerapi')

    selector.elements.staying_month_textbox().clear().type('Zurich')     //click on text box
    selector.genericwait()
    selector.elements.city_selection().click()         //city selection from dropdown
    selector.genericwait()
    selector.elements.continue_btn().click()     //continue bbutton
    cy.wait('@<20weatherapi')
    selector.elements.continue_btn().click()     //continue button
    cy.wait('@mp4videoapi')

    selector.elements.skipto_results_btn().click()      // skip to results button
    cy.wait('@resultpage')
    cy.wait('@resultonproductpage')
    
    selector.producttype.dayserum().should('exist')           //verifing the product type
    selector.producttype.nightserum().should('exist')          //verifing the product type
    selector.producttype.moisturiser().should('exist')         //verifing the product type
    //selector.producttype.nightcream().should('exist')           //verifing the product type
    selector.genericwait()


    selector.elements.add_day_night_set().click()               //add product set button
    cy.wait('@addsetbtnapi')
    
    selector.elements.product_btn().click()                    //product button
    cy.wait('@resultonproductpage')
     

    selector.productname.daydropofperfection().should('exist')       //verifing the day serum 
    selector.productname.dewdatemoisturiser().should('exist')      //verifing the day cream
    selector.productname.dropofyouth().should('exist')       //verifing the night serum
    selector.productname.milkyway().should('exist')              //verifing the night cream
    cy.wait(3000)

}


testcase34()
{
    selector.assessment_apis()              //inculuded assessment/result/answer's api's
    selector.elements.gender_male().click() //gender selection
    cy.wait('@answerapi')
    cy.wait('@agequestionapi')

    selector.elementsquestions.age()
    selector.elements.age_any().click()   //age selection
    cy.wait('@answerapi')
    cy.wait('@cheeksapi')

    selector.elementsquestions.cheeksinthemorning()
    selector.elements.cheeks_morning_normal().click()  //cheeks selection
    cy.wait('@answerapi')
    cy.wait('@tzoneapi')

    selector.elementsquestions.tzone()
    selector.elements.tzone_oily().click()   //tzone selection
    cy.wait('@answerapi')
    cy.wait('@skinconcernapi')

    selector.elementsquestions.top2skinconcerns()
    selector.elements.top2_skin_concerns_wrinkles().click()  //skin concerns selection  1
    selector.elements.top2_skin_concerns_blackWhitehead().click()  //skin concerns selection   2
    cy.wait('@answerapi')
    cy.wait('@skinshadeapi')

    selector.elementsquestions.skinshade()
    selector.elements.skishade_2nd().click()     //skin shade selection
    cy.wait('@answerapi')
    cy.wait('@reactionapi')

    selector.elementsquestions.skinreaction()
    selector.elements.skinReactions_no().click()   //skin reaction selection Yes or No
    cy.wait('@answerapi')
    cy.wait('@stressapi')

    selector.elementsquestions.stress()
    selector.elements.little_stress().click()    // stress selection
    cy.wait('@answerapi')
    cy.wait('@sleepapi')

    selector.elementsquestions.sleep()
    selector.elements.sleep_5to6().click()      //sleep selection
    cy.wait('@answerapi')
    cy.wait('@waterapi')

    selector.elementsquestions.waterconsumption()
    selector.elements.water_consumption().click()    //water consumption selection
    cy.wait('@answerapi')
    cy.wait('@spenddayapi')

    selector.elementsquestions.dayspend()
    selector.elements.indoors_wtoutAC().click()     //environment selection
    cy.wait('@answerapi')
    cy.wait('@lifestyleapi')

    selector.elementsquestions.lifestylepart()
    selector.elements.lifestyle_regular_workout().click()   //lifestyle selection
    selector.elements.continue_btn().click()               //continue button
    cy.wait('@answerapi')
    cy.wait('@makeupapi')
    
    selector.elementsquestions.makeup()
    selector.elements.wear_makeup_occasionally().click()    //makeup wearing selection
    cy.wait('@answerapi')
    cy.wait('@smokeapi')

    selector.elementsquestions.smoke()
    selector.elements.smoke_occasionally().click()          //smoking selection
    cy.wait('@answerapi')
    cy.wait('@productpreferenceapi') 

    selector.elementsquestions.productpreference()
    selector.elements.product_preference_vegan().click()      //product preference selection
    selector.elements.continue_btn().click()                 //continue button
    cy.wait('@answerapi')


    selector.elements.staying_month_textbox().clear().type('Lahore')     //click on text box
    selector.genericwait()
    selector.elements.city_selection().click()         //city selection from dropdown
    selector.genericwait()
    selector.elements.continue_btn().click()     //continue bbutton
    cy.wait('@>20weatherapi')
    selector.elements.continue_btn().click()     //continue button
    cy.wait('@mp4videoapi')

    selector.elements.skipto_results_btn().click()      // skip to results button
    cy.wait('@resultpage')
    cy.wait('@resultonproductpage')
    
    selector.producttype.dayserum().should('exist')           //verifing the product type
    selector.producttype.nightserum().should('exist')          //verifing the product type
    selector.producttype.moisturiser().should('exist')         //verifing the product type
    //selector.producttype.nightcream().should('exist')           //verifing the product type
    selector.genericwait()


    selector.elements.add_day_night_set().click()               //add product set button
    cy.wait('@addsetbtnapi')
    
    selector.elements.product_btn().click()                    //product button
    cy.wait('@resultonproductpage')
     

    selector.productname.daydropofperfection().should('exist')       //verifing the day serum 
    selector.productname.mm().should('exist')      //verifing the day cream
    selector.productname.nightdropoflight().should('exist')       //verifing the night serum
    selector.productname.milkyway().should('exist')              //verifing the night cream
    cy.wait(3000)

}


testcase35()
{
    selector.assessment_apis()              //inculuded assessment/result/answer's api's
    selector.elements.gender_male().click() //gender selection
    cy.wait('@answerapi')
    cy.wait('@agequestionapi')

    selector.elementsquestions.age()
    selector.elements.age_any().click()   //age selection
    cy.wait('@answerapi')
    cy.wait('@cheeksapi')

    selector.elementsquestions.cheeksinthemorning()
    selector.elements.cheeks_morning_normal().click()  //cheeks selection
    cy.wait('@answerapi')
    cy.wait('@tzoneapi')

    selector.elementsquestions.tzone()
    selector.elements.tzone_veryoily().click()   //tzone selection
    cy.wait('@answerapi')
    cy.wait('@skinconcernapi')

    selector.elementsquestions.top2skinconcerns()
    selector.elements.top2_skin_concerns_redness().click()  //skin concerns selection  1
    selector.elements.continue_btn().click()     //continue button
    cy.wait('@answerapi')
    cy.wait('@levelofrednessapi')

    selector.elementsquestions.levelofredness()
    selector.elements.levelofredness_mild().click()  //level of redness
    cy.wait('@answerapi')
    cy.wait('@skinshadeapi')
   
    
    selector.elementsquestions.skinshade()
    selector.elements.skishade_2nd().click()     //skin shade selection
    cy.wait('@answerapi')
    cy.wait('@reactionapi')

    selector.elementsquestions.skinreaction()
    selector.elements.skinReactions_no().click()   //skin reaction selection Yes or No
    cy.wait('@answerapi')
    cy.wait('@stressapi')

    selector.elementsquestions.stress()
    selector.elements.little_stress().click()    // stress selection
    cy.wait('@answerapi')
    cy.wait('@sleepapi')

    selector.elementsquestions.sleep()
    selector.elements.sleep_5to6().click()      //sleep selection
    cy.wait('@answerapi')
    cy.wait('@waterapi')

    selector.elementsquestions.waterconsumption()
    selector.elements.water_consumption().click()    //water consumption selection
    cy.wait('@answerapi')
    cy.wait('@spenddayapi')

    selector.elementsquestions.dayspend()
    selector.elements.indoors_wtoutAC().click()     //environment selection
    cy.wait('@answerapi')
    cy.wait('@lifestyleapi')

    selector.elementsquestions.lifestylepart()
    selector.elements.lifestyle_regular_workout().click()   //lifestyle selection
    selector.elements.continue_btn().click()               //continue button
    cy.wait('@answerapi')
    cy.wait('@makeupapi')
    
    selector.elementsquestions.makeup()
    selector.elements.wear_makeup_occasionally().click()    //makeup wearing selection
    cy.wait('@answerapi')
    cy.wait('@smokeapi')

    selector.elementsquestions.smoke()
    selector.elements.smoke_occasionally().click()          //smoking selection
    cy.wait('@answerapi')
    cy.wait('@productpreferenceapi') 

    selector.elementsquestions.productpreference()
    selector.elements.product_preference_none().click()      //product preference selection
    cy.wait('@answerapi')


    selector.elements.staying_month_textbox().clear().type('Lahore')     //click on text box
    selector.genericwait()
    selector.elements.city_selection().click()         //city selection from dropdown
    selector.genericwait()
    selector.elements.continue_btn().click()     //continue bbutton
    cy.wait('@>20weatherapi')
    selector.elements.continue_btn().click()     //continue button
    cy.wait('@mp4videoapi')

    selector.elements.skipto_results_btn().click()      // skip to results button
    cy.wait('@resultpage')
    cy.wait('@resultonproductpage')
    
    selector.producttype.dayserum().should('exist')           //verifing the product type
    selector.producttype.nightserum().should('exist')          //verifing the product type
    selector.producttype.moisturiser().should('exist')         //verifing the product type
    //selector.producttype.nightcream().should('exist')           //verifing the product type
    selector.genericwait()


    selector.elements.add_day_night_set().click()               //add product set button
    cy.wait('@addsetbtnapi')
    
    selector.elements.product_btn().click()                    //product button
    cy.wait('@resultonproductpage')
     

    selector.productname.daydropoflight().should('exist')       //verifing the day serum 
    selector.productname.mm().should('exist')                      //verifing the day cream
    selector.productname.nightdropofsoftness().should('exist')       //verifing the night serum
    selector.productname.milkyway().should('exist')              //verifing the night cream
    cy.wait(3000)

}


testcase36()
{
    selector.assessment_apis()              //inculuded assessment/result/answer's api's
    selector.elements.gender_male().click() //gender selection
    cy.wait('@answerapi')
    cy.wait('@agequestionapi')

    selector.elementsquestions.age()
    selector.elements.age_any().click()   //age selection
    cy.wait('@answerapi')
    cy.wait('@cheeksapi')

    selector.elementsquestions.cheeksinthemorning()
    selector.elements.cheeks_morning_oily().click()  //cheeks selection
    cy.wait('@answerapi')
    cy.wait('@tzoneapi')

    selector.elementsquestions.tzone()
    selector.elements.tzone_verydry().click()   //tzone selection
    cy.wait('@answerapi')
    cy.wait('@skinconcernapi')


    selector.elementsquestions.top2skinconcerns()
    selector.elements.top2_skin_concerns_acne().click()      //skin concerns selection  1
    selector.elements.top2_skin_concerns_redness().click()  //skin concerns selection  2
    cy.wait('@answerapi')
    cy.wait('@getacneapi')

    selector.elementsquestions.getacne()
    selector.elements.get_acne_always().click()  // select acny stay period
    cy.wait('@answerapi')
    cy.wait('@describeacneapi')

    selector.elementsquestions.describeacne()
    selector.elements.acnehardones().click()     //select acne type
    cy.wait('@answerapi')
    cy.wait('@levelofrednessapi')

    selector.elementsquestions.levelofredness()
    selector.elements.levelofredness_mild().click()  //level of redness
    cy.wait('@answerapi')
    cy.wait('@skinshadeapi')

    selector.elementsquestions.skinshade()
    selector.elements.skishade_2nd().click()     //skin shade selection
    cy.wait('@answerapi')
    cy.wait('@reactionapi')

    selector.elementsquestions.skinreaction()
    selector.elements.skinReactions_yes().click()   //skin reaction selection Yes or No
    cy.wait('@answerapi')
    cy.wait('@ingredientapi')

    selector.elementsquestions.ingredients()
    selector.elements.ingredients_retinol().click()        //ingredient selection
    selector.elements.continue_btn().click()                //continue button
    cy.wait('@answerapi')
    cy.wait('@stressapi')


    selector.elementsquestions.stress()
    selector.elements.little_stress().click()    // stress selection
    cy.wait('@answerapi')
    cy.wait('@sleepapi')


    selector.elementsquestions.sleep()
    selector.elements.sleep_5to6().click()      //sleep selection
    cy.wait('@answerapi')
    cy.wait('@waterapi')

    selector.elementsquestions.waterconsumption()
    selector.elements.water_consumption().click()    //water consumption selection
    cy.wait('@answerapi')
    cy.wait('@spenddayapi')

    selector.elementsquestions.dayspend()
    selector.elements.indoors_wtoutAC().click()     //environment selection
    cy.wait('@answerapi')
    cy.wait('@lifestyleapi')

    selector.elementsquestions.lifestylepart()
    selector.elements.lifestyle_regular_workout().click()   //lifestyle selection
    selector.elements.continue_btn().click()               //continue button
    cy.wait('@answerapi')
    cy.wait('@makeupapi')
    
    selector.elementsquestions.makeup()
    selector.elements.wear_makeup_occasionally().click()    //makeup wearing selection
    cy.wait('@answerapi')
    cy.wait('@smokeapi')

    selector.elementsquestions.smoke()
    selector.elements.smoke_occasionally().click()          //smoking selection
    cy.wait('@answerapi')
    cy.wait('@productpreferenceapi') 

    selector.elementsquestions.productpreference()
    selector.elements.product_preference_none().click()      //product preference selection
    cy.wait('@answerapi')


    selector.elements.staying_month_textbox().clear().type('Zurich')     //click on text box
    selector.genericwait()
    selector.elements.city_selection().click()         //city selection from dropdown
    selector.genericwait()
    selector.elements.continue_btn().click()     //continue bbutton
    cy.wait('@<20weatherapi')
    selector.elements.continue_btn().click()     //continue button
    cy.wait('@mp4videoapi')

    selector.elements.skipto_results_btn().click()      // skip to results button
    cy.wait('@resultpage')
    cy.wait('@resultonproductpage')
    
    selector.producttype.dayserum().should('exist')           //verifing the product type
    selector.producttype.nightserum().should('exist')          //verifing the product type
    selector.producttype.moisturiser().should('exist')         //verifing the product type
    //selector.producttype.nightcream().should('exist')           //verifing the product type
    selector.genericwait()


    selector.elements.add_day_night_set().click()               //add product set button
    cy.wait('@addsetbtnapi')
    
    selector.elements.product_btn().click()                    //product button
    cy.wait('@resultonproductpage')
     

    selector.productname.daydropofsoftness().should('exist')       //verifing the day serum 
    selector.productname.dewdatemoisturiser().should('exist')      //verifing the day cream
    selector.productname.night_dropofbalance().should('exist')       //verifing the night serum
    selector.productname.milkyway().should('exist')              //verifing the night cream
    cy.wait(3000)

}


testcase38()
{
    selector.assessment_apis()              //inculuded assessment/result/answer's api's
    selector.elements.gender_male().click() //gender selection
    cy.wait('@answerapi')
    cy.wait('@agequestionapi')

    selector.elementsquestions.age()
    selector.elements.age_any().click()   //age selection
    cy.wait('@answerapi')
    cy.wait('@cheeksapi')

    selector.elementsquestions.cheeksinthemorning()
    selector.elements.cheeks_morning_oily().click()  //cheeks selection
    cy.wait('@answerapi')
    cy.wait('@tzoneapi')

    selector.elementsquestions.tzone()
    selector.elements.tzone_verydry().click()   //tzone selection
    cy.wait('@answerapi')
    cy.wait('@skinconcernapi')


    selector.elementsquestions.top2skinconcerns()
    selector.elements.top2_skin_concerns_acne().click()      //skin concerns selection  1
    selector.elements.top2_skin_concerns_redness().click()  //skin concerns selection  2
    cy.wait('@answerapi')
    cy.wait('@getacneapi')
    

    selector.elementsquestions.getacne()
    selector.elements.get_acne_always().click()  // select acny stay period
    cy.wait('@answerapi')
    cy.wait('@describeacneapi')

    selector.elementsquestions.describeacne()
    selector.elements.acnehardones().click()     //select acne type
    cy.wait('@answerapi')
    cy.wait('@levelofrednessapi')

    selector.elementsquestions.levelofredness()
    selector.elements.levelofredness_mild().click()  //level of redness
    cy.wait('@answerapi')
    cy.wait('@skinshadeapi')

    selector.elementsquestions.skinshade()
    selector.elements.skishade_2nd().click()     //skin shade selection
    cy.wait('@answerapi')
    cy.wait('@reactionapi')

    selector.elementsquestions.skinreaction()
    selector.elements.skinReactions_yes().click()   //skin reaction selection Yes or No
    cy.wait('@answerapi')
    cy.wait('@ingredientapi')

    selector.elementsquestions.ingredients()
    selector.elements.ingredients_salicylicacid().click()    //Ingredient selection
    selector.elements.continue_btn().click()                //continue button
    cy.wait('@answerapi')
    cy.wait('@stressapi')


    selector.elementsquestions.stress()
    selector.elements.little_stress().click()    // stress selection
    cy.wait('@answerapi')
    cy.wait('@sleepapi')


    selector.elementsquestions.sleep()
    selector.elements.sleep_5to6().click()      //sleep selection
    cy.wait('@answerapi')
    cy.wait('@waterapi')


    selector.elementsquestions.waterconsumption()
    selector.elements.water_consumption().click()    //water consumption selection
    cy.wait('@answerapi')
    cy.wait('@spenddayapi')

    selector.elementsquestions.dayspend()
    selector.elements.indoors_wtoutAC().click()     //environment selection
    cy.wait('@answerapi')
    cy.wait('@lifestyleapi')

    selector.elementsquestions.lifestylepart()
    selector.elements.lifestyle_regular_workout().click()   //lifestyle selection
    selector.elements.continue_btn().click()               //continue button
    cy.wait('@answerapi')
    cy.wait('@makeupapi')
    
    selector.elementsquestions.makeup()
    selector.elements.wear_makeup_occasionally().click()    //makeup wearing selection
    cy.wait('@answerapi')
    cy.wait('@smokeapi')

    selector.elementsquestions.smoke()
    selector.elements.smoke_occasionally().click()          //smoking selection
    cy.wait('@answerapi')
    cy.wait('@productpreferenceapi') 

    selector.elementsquestions.productpreference()
    selector.elements.product_preference_none().click()      //product preference selection
    cy.wait('@answerapi')


    selector.elements.staying_month_textbox().clear().type('Lahore')     //click on text box
    selector.genericwait()
    selector.elements.city_selection().click()         //city selection from dropdown
    selector.genericwait()
    selector.elements.continue_btn().click()     //continue bbutton
    cy.wait('@>20weatherapi')
    selector.elements.continue_btn().click()     //continue button
    cy.wait('@mp4videoapi')


    selector.elements.skipto_results_btn().click()      // skip to results button
    cy.wait('@resultpage')
    cy.wait('@resultonproductpage')
    
    selector.producttype.dayserum().should('exist')           //verifing the product type
    selector.producttype.nightserum().should('exist')          //verifing the product type
    selector.producttype.moisturiser().should('exist')         //verifing the product type
    //selector.producttype.nightcream().should('exist')           //verifing the product type
    selector.genericwait()


    selector.elements.add_day_night_set().click()               //add product set button
    cy.wait('@addsetbtnapi')
    
    selector.elements.product_btn().click()                    //product button
    cy.wait('@resultonproductpage')
     

    selector.productname.daydropofsoftness().should('exist')       //verifing the day serum 
    selector.productname.mm().should('exist')                      //verifing the day cream
    selector.productname.dropofyouth().should('exist')       //verifing the night serum
    selector.productname.milkyway().should('exist')              //verifing the night cream
    cy.wait(3000)

}


testcase39()
{
    selector.assessment_apis()              //inculuded assessment/result/answer's api's
    selector.elements.gender_male().click() //gender selection
    cy.wait('@answerapi')
    cy.wait('@agequestionapi')

    selector.elementsquestions.age()
    selector.elements.age_any().click()   //age selection
    cy.wait('@answerapi')
    cy.wait('@cheeksapi')

    selector.elementsquestions.cheeksinthemorning()
    selector.elements.cheeks_morning_oily().click()  //cheeks selection
    cy.wait('@answerapi')
    cy.wait('@tzoneapi')

    selector.elementsquestions.tzone()
    selector.elements.tzone_verydry().click()   //tzone selection
    cy.wait('@answerapi')
    cy.wait('@skinconcernapi')


    selector.elementsquestions.top2skinconcerns()
    selector.elements.top2_skin_concerns_acne().click()      //skin concerns selection  1
    selector.elements.top2_skin_concerns_redness().click()  //skin concerns selection  2
    cy.wait('@answerapi')
    cy.wait('@getacneapi')
    

    selector.elementsquestions.getacne()
    selector.elements.get_acne_always().click()  // select acny stay period
    cy.wait('@answerapi')
    cy.wait('@describeacneapi')

    selector.elementsquestions.describeacne()
    selector.elements.acnehardones().click()     //select acne type
    cy.wait('@answerapi')
    cy.wait('@levelofrednessapi')

    selector.elementsquestions.levelofredness()
    selector.elements.levelofredness_mild().click()  //level of redness
    cy.wait('@answerapi')
    cy.wait('@skinshadeapi')

    selector.elementsquestions.skinshade()
    selector.elements.skishade_2nd().click()     //skin shade selection
    cy.wait('@answerapi')
    cy.wait('@reactionapi')

    selector.elementsquestions.skinreaction()
    selector.elements.skinReactions_yes().click()   //skin reaction selection Yes or No
    cy.wait('@answerapi')
    cy.wait('@ingredientapi')

    selector.elementsquestions.ingredients()
    selector.elements.ingredients_salicylicacid().click()    //Ingredeint selection
    selector.elements.continue_btn().click()                //continue button
    cy.wait('@answerapi')
    cy.wait('@stressapi')


    selector.elementsquestions.stress()
    selector.elements.little_stress().click()    // stress selection
    cy.wait('@answerapi')
    cy.wait('@sleepapi')



    selector.elementsquestions.sleep()
    selector.elements.sleep_5to6().click()      //sleep selection
    cy.wait('@answerapi')
    cy.wait('@waterapi')


    selector.elementsquestions.waterconsumption()
    selector.elements.water_consumption().click()    //water consumption selection
    cy.wait('@answerapi')
    cy.wait('@spenddayapi')

    selector.elementsquestions.dayspend()
    selector.elements.indoors_wtoutAC().click()     //environment selection
    cy.wait('@answerapi')
    cy.wait('@lifestyleapi')

    selector.elementsquestions.lifestylepart()
    selector.elements.lifestyle_regular_workout().click()   //lifestyle selection
    selector.elements.continue_btn().click()               //continue button
    cy.wait('@answerapi')
    cy.wait('@makeupapi')
    
    selector.elementsquestions.makeup()
    selector.elements.wear_makeup_occasionally().click()    //makeup wearing selection
    cy.wait('@answerapi')
    cy.wait('@smokeapi')

    selector.elementsquestions.smoke()
    selector.elements.smoke_occasionally().click()          //smoking selection
    cy.wait('@answerapi')
    cy.wait('@productpreferenceapi') 

    selector.elementsquestions.productpreference()
    selector.elements.product_preference_vegan().click()      //product preference selection
    selector.elements.continue_btn().click()     //continue button
    cy.wait('@answerapi')

    selector.elements.staying_month_textbox().clear().type('Lahore')     //click on text box
    selector.genericwait()
    selector.elements.city_selection().click()         //city selection from dropdown
    selector.genericwait()
    selector.elements.continue_btn().click()     //continue bbutton
    cy.wait('@>20weatherapi')
    selector.elements.continue_btn().click()     //continue button
    cy.wait('@mp4videoapi')

    selector.elements.skipto_results_btn().click()      // skip to results button
    cy.wait('@resultpage')
    cy.wait('@resultonproductpage')
    
    selector.producttype.dayserum().should('exist')           //verifing the product type
    selector.producttype.nightserum().should('exist')          //verifing the product type
    selector.producttype.moisturiser().should('exist')         //verifing the product type
    //selector.producttype.nightcream().should('exist')           //verifing the product type
    selector.genericwait()


    selector.elements.add_day_night_set().click()               //add product set button
    cy.wait('@addsetbtnapi')
    
    selector.elements.product_btn().click()                    //product button
    cy.wait('@resultonproductpage')
     

    selector.productname.daydropofsoftness().should('exist')       //verifing the day serum 
    selector.productname.mm().should('exist')                      //verifing the day cream
    selector.productname.nightdropoflight().should('exist')       //verifing the night serum
    selector.productname.milkyway().should('exist')              //verifing the night cream
    cy.wait(3000)

}


testcase40()
{
    selector.assessment_apis()              //inculuded assessment/result/answer's api's
    selector.elements.gender_male().click() //gender selection
    cy.wait('@answerapi')
    cy.wait('@agequestionapi')

    selector.elementsquestions.age()
    selector.elements.age_any().click()   //age selection
    cy.wait('@answerapi')
    cy.wait('@cheeksapi')

    selector.elementsquestions.cheeksinthemorning()
    selector.elements.cheeks_morning_oily().click()  //cheeks selection
    cy.wait('@answerapi')
    cy.wait('@tzoneapi')

    selector.elementsquestions.tzone()
    selector.elements.tzone_dry().click()   //tzone selection
    cy.wait('@answerapi')
    cy.wait('@skinconcernapi')

    selector.elementsquestions.top2skinconcerns()
    selector.elements.top2_skin_concerns_pigmentation().click()      //skin concerns selection  1
    selector.elements.top2_skin_concerns_redness().click()  //skin concerns selection  2
    cy.wait('@answerapi')
    cy.wait('@levelofrednessapi')
    

    selector.elementsquestions.levelofredness()
    selector.elements.levelofredness_mild().click()  //level of redness
    cy.wait('@answerapi')
    cy.wait('@skinshadeapi')

    selector.elementsquestions.skinshade()
    selector.elements.skishade_2nd().click()     //skin shade selection
    cy.wait('@answerapi')
    cy.wait('@reactionapi')

    selector.elementsquestions.skinreaction()
    selector.elements.skinReactions_yes().click()   //skin reaction selection Yes or No
    cy.wait('@answerapi')
    cy.wait('@ingredientapi')

    selector.elementsquestions.ingredients()
    selector.elements.ingredients_retinol().click()          //ingredeint selection
    selector.elements.continue_btn().click()                //continue button
    cy.wait('@answerapi')
    cy.wait('@stressapi')


    selector.elementsquestions.stress()
    selector.elements.little_stress().click()    // stress selection
    cy.wait('@answerapi')
    cy.wait('@sleepapi')


    selector.elementsquestions.sleep()
    selector.elements.sleep_5to6().click()      //sleep selection
    cy.wait('@answerapi')
    cy.wait('@waterapi')


    selector.elementsquestions.waterconsumption()
    selector.elements.water_consumption().click()    //water consumption selection
    cy.wait('@answerapi')
    cy.wait('@spenddayapi')

    selector.elementsquestions.dayspend()
    selector.elements.indoors_wtoutAC().click()     //environment selection
    cy.wait('@answerapi')
    cy.wait('@lifestyleapi')

    selector.elementsquestions.lifestylepart()
    selector.elements.lifestyle_regular_workout().click()   //lifestyle selection
    selector.elements.continue_btn().click()               //continue button
    cy.wait('@answerapi')
    cy.wait('@makeupapi')
    
    selector.elementsquestions.makeup()
    selector.elements.wear_makeup_occasionally().click()    //makeup wearing selection
    cy.wait('@answerapi')
    cy.wait('@smokeapi')

    selector.elementsquestions.smoke()
    selector.elements.smoke_occasionally().click()          //smoking selection
    cy.wait('@answerapi')
    cy.wait('@productpreferenceapi') 

    selector.elementsquestions.productpreference()
    selector.elements.product_preference_none().click()      //product preference selection
    cy.wait('@answerapi')


    selector.elements.staying_month_textbox().clear().type('Zurich')     //click on text box
    selector.genericwait()
    selector.elements.city_selection().click()         //city selection from dropdown
    selector.genericwait()
    selector.elements.continue_btn().click()     //continue bbutton
    cy.wait('@<20weatherapi')
    selector.elements.continue_btn().click()     //continue button
    cy.wait('@mp4videoapi')

    selector.elements.skipto_results_btn().click()      // skip to results button
    cy.wait('@resultpage')
    cy.wait('@resultonproductpage')
    
    selector.producttype.dayserum().should('exist')           //verifing the product type
    selector.producttype.nightserum().should('exist')          //verifing the product type
    selector.producttype.moisturiser().should('exist')         //verifing the product type
    //selector.producttype.nightcream().should('exist')           //verifing the product type
    selector.genericwait()


    selector.elements.add_day_night_set().click()               //add product set button
    cy.wait('@addsetbtnapi')
    
    selector.elements.product_btn().click()                    //product button
    cy.wait('@resultonproductpage')
     

    selector.productname.daydropoflight().should('exist')       //verifing the day serum 
    selector.productname.dewdatemoisturiser().should('exist')    //verifing the day cream
    selector.productname.nightdropofsoftness().should('exist')    //verifing the night serum
    selector.productname.milkyway().should('exist')              //verifing the night cream
    cy.wait(3000)

}


testcase41()
{
    selector.assessment_apis()              //inculuded assessment/result/answer's api's
    selector.elements.gender_male().click() //gender selection
    cy.wait('@answerapi')
    cy.wait('@agequestionapi')

    selector.elementsquestions.age()
    selector.elements.age_any().click()   //age selection
    cy.wait('@answerapi')
    cy.wait('@cheeksapi')

    selector.elementsquestions.cheeksinthemorning()
    selector.elements.cheeks_morning_oily().click()  //cheeks selection
    cy.wait('@answerapi')
    cy.wait('@tzoneapi')

    selector.elementsquestions.tzone()
    selector.elements.tzone_dry().click()   //tzone selection
    cy.wait('@answerapi')
    cy.wait('@skinconcernapi')

    selector.elementsquestions.top2skinconcerns()
    selector.elements.top2_skin_concerns_pigmentation().click()      //skin concerns selection  1
    selector.elements.top2_skin_concerns_redness().click()  //skin concerns selection  2
    cy.wait('@answerapi')
    cy.wait('@levelofrednessapi')
    

    selector.elementsquestions.levelofredness()
    selector.elements.levelofredness_mild().click()  //level of redness
    cy.wait('@answerapi')
    cy.wait('@skinshadeapi')


    selector.elementsquestions.skinshade()
    selector.elements.skishade_2nd().click()     //skin shade selection
    cy.wait('@answerapi')
    cy.wait('@reactionapi')

    selector.elementsquestions.skinreaction()
    selector.elements.skinReactions_no().click()   //skin reaction selection Yes or No
    cy.wait('@answerapi')
    cy.wait('@stressapi')


    selector.elementsquestions.stress()
    selector.elements.little_stress().click()    // stress selection
    cy.wait('@answerapi')
    cy.wait('@sleepapi')


    selector.elementsquestions.sleep()
    selector.elements.sleep_5to6().click()      //sleep selection
    cy.wait('@answerapi')
    cy.wait('@waterapi')


    selector.elementsquestions.waterconsumption()
    selector.elements.water_consumption().click()    //water consumption selection
    cy.wait('@answerapi')
    cy.wait('@spenddayapi')

    selector.elementsquestions.dayspend()
    selector.elements.indoors_wtoutAC().click()     //environment selection
    cy.wait('@answerapi')
    cy.wait('@lifestyleapi')

    selector.elementsquestions.lifestylepart()
    selector.elements.lifestyle_regular_workout().click()   //lifestyle selection
    selector.elements.continue_btn().click()               //continue button
    cy.wait('@answerapi')
    cy.wait('@makeupapi')
    
    selector.elementsquestions.makeup()
    selector.elements.wear_makeup_occasionally().click()    //makeup wearing selection
    cy.wait('@answerapi')
    cy.wait('@smokeapi')

    selector.elementsquestions.smoke()
    selector.elements.smoke_occasionally().click()          //smoking selection
    cy.wait('@answerapi')
    cy.wait('@productpreferenceapi') 

    selector.elementsquestions.productpreference()
    selector.elements.product_preference_none().click()      //product preference selection
    cy.wait('@answerapi')


    selector.elements.staying_month_textbox().clear().type('Zurich')     //click on text box
    selector.genericwait()
    selector.elements.city_selection().click()         //city selection from dropdown
    selector.genericwait()
    selector.elements.continue_btn().click()     //continue bbutton
    cy.wait('@<20weatherapi')
    selector.elements.continue_btn().click()     //continue button
    cy.wait('@mp4videoapi')

    selector.elements.skipto_results_btn().click()      // skip to results button
    cy.wait('@resultpage')
    cy.wait('@resultonproductpage')
    
    selector.producttype.dayserum().should('exist')           //verifing the product type
    selector.producttype.nightserum().should('exist')          //verifing the product type
    selector.producttype.moisturiser().should('exist')         //verifing the product type
    //selector.producttype.nightcream().should('exist')           //verifing the product type
    selector.genericwait()


    selector.elements.add_day_night_set().click()               //add product set button
    cy.wait('@addsetbtnapi')
    
    selector.elements.product_btn().click()                    //product button
    cy.wait('@resultonproductpage')
     

    selector.productname.daydropoflight().should('exist')       //verifing the day serum 
    selector.productname.dewdatemoisturiser().should('exist')    //verifing the day cream
    selector.productname.nightdropofsoftness().should('exist')    //verifing the night serum
    selector.productname.milkyway().should('exist')              //verifing the night cream
    cy.wait(3000)

}


testcase42()
{
    selector.assessment_apis()              //inculuded assessment/result/answer's api's
    selector.elements.gender_male().click() //gender selection
    cy.wait('@answerapi')
    cy.wait('@agequestionapi')

    selector.elementsquestions.age()
    selector.elements.age_any().click()   //age selection
    cy.wait('@answerapi')
    cy.wait('@cheeksapi')

    selector.elementsquestions.cheeksinthemorning()
    selector.elements.cheeks_morning_oily().click()  //cheeks selection
    cy.wait('@answerapi')
    cy.wait('@tzoneapi')

    selector.elementsquestions.tzone()
    selector.elements.tzone_dry().click()   //tzone selection
    cy.wait('@answerapi')
    cy.wait('@skinconcernapi')

    selector.elementsquestions.top2skinconcerns()
    selector.elements.top2_skin_concerns_pigmentation().click()      //skin concerns selection  1
    selector.elements.top2_skin_concerns_redness().click()  //skin concerns selection  2
    cy.wait('@answerapi')
    cy.wait('@levelofrednessapi')
    

    selector.elementsquestions.levelofredness()
    selector.elements.levelofredness_mild().click()  //level of redness
    cy.wait('@answerapi')
    cy.wait('@skinshadeapi')


    selector.elementsquestions.skinshade()
    selector.elements.skishade_2nd().click()     //skin shade selection
    cy.wait('@answerapi')
    cy.wait('@reactionapi')

    selector.elementsquestions.skinreaction()
    selector.elements.skinReactions_yes().click()   //skin reaction selection Yes or No
    cy.wait('@answerapi')
    cy.wait('@ingredientapi')

    selector.elementsquestions.ingredients()
    selector.elements.ingredients_salicylicacid().click()    //ingredients selection
    selector.elements.continue_btn().click()     //continue button
    cy.wait('@answerapi')
    cy.wait('@stressapi')

    selector.elementsquestions.stress()
    selector.elements.little_stress().click()    // stress selection
    cy.wait('@answerapi')
    cy.wait('@sleepapi')


    selector.elementsquestions.sleep()
    selector.elements.sleep_5to6().click()      //sleep selection
    cy.wait('@answerapi')
    cy.wait('@waterapi')


    selector.elementsquestions.waterconsumption()
    selector.elements.water_consumption().click()    //water consumption selection
    cy.wait('@answerapi')
    cy.wait('@spenddayapi')

    selector.elementsquestions.dayspend()
    selector.elements.indoors_wtoutAC().click()     //environment selection
    cy.wait('@answerapi')
    cy.wait('@lifestyleapi')

    selector.elementsquestions.lifestylepart()
    selector.elements.lifestyle_regular_workout().click()   //lifestyle selection
    selector.elements.continue_btn().click()               //continue button
    cy.wait('@answerapi')
    cy.wait('@makeupapi')
    
    selector.elementsquestions.makeup()
    selector.elements.wear_makeup_occasionally().click()    //makeup wearing selection
    cy.wait('@answerapi')
    cy.wait('@smokeapi')

    selector.elementsquestions.smoke()
    selector.elements.smoke_occasionally().click()          //smoking selection
    cy.wait('@answerapi')
    cy.wait('@productpreferenceapi') 

    selector.elementsquestions.productpreference()
    selector.elements.product_preference_none().click()      //product preference selection
    cy.wait('@answerapi')


    selector.elements.staying_month_textbox().clear().type('Zurich')     //click on text box
    selector.genericwait()
    selector.elements.city_selection().click()         //city selection from dropdown
    selector.genericwait()
    selector.elements.continue_btn().click()     //continue bbutton
    cy.wait('@<20weatherapi')
    selector.elements.continue_btn().click()     //continue button
    cy.wait('@mp4videoapi')

    selector.elements.skipto_results_btn().click()      // skip to results button
    cy.wait('@resultpage')
    cy.wait('@resultonproductpage')
    
    selector.producttype.dayserum().should('exist')           //verifing the product type
    selector.producttype.nightserum().should('exist')          //verifing the product type
    selector.producttype.moisturiser().should('exist')         //verifing the product type
    //selector.producttype.nightcream().should('exist')           //verifing the product type
    selector.genericwait()


    selector.elements.add_day_night_set().click()               //add product set button
    cy.wait('@addsetbtnapi')
    
    selector.elements.product_btn().click()                    //product button
    cy.wait('@resultonproductpage')
     

    selector.productname.daydropoflight().should('exist')       //verifing the day serum 
    selector.productname.dewdatemoisturiser().should('exist')    //verifing the day cream
    selector.productname.nightdropofsoftness().should('exist')    //verifing the night serum
    selector.productname.milkyway().should('exist')              //verifing the night cream
    cy.wait(3000)

}


testcase43()
{
    selector.assessment_apis()              //inculuded assessment/result/answer's api's
    selector.elements.gender_male().click() //gender selection
    cy.wait('@answerapi')
    cy.wait('@agequestionapi')

    selector.elementsquestions.age()
    selector.elements.age_any().click()   //age selection
    cy.wait('@answerapi')
    cy.wait('@cheeksapi')

    selector.elementsquestions.cheeksinthemorning()
    selector.elements.cheeks_morning_oily().click()  //cheeks selection
    cy.wait('@answerapi')
    cy.wait('@tzoneapi')

    selector.elementsquestions.tzone()
    selector.elements.tzone_dry().click()   //tzone selection
    cy.wait('@answerapi')
    cy.wait('@skinconcernapi')

    selector.elementsquestions.top2skinconcerns()
    selector.elements.top2_skin_concerns_blackWhitehead().click()      //skin concerns selection  1
    selector.elements.top2_skin_concerns_redness().click()  //skin concerns selection  2
    cy.wait('@levelofrednessapi')
    

    selector.elementsquestions.levelofredness()
    selector.elements.levelofredness_mild().click()  //level of redness
    cy.wait('@answerapi')
    cy.wait('@skinshadeapi')


    selector.elementsquestions.skinshade()
    selector.elements.skishade_2nd().click()     //skin shade selection
    cy.wait('@answerapi')
    cy.wait('@reactionapi')

    selector.elementsquestions.skinreaction()
    selector.elements.skinReactions_yes().click()   //skin reaction selection Yes or No
    cy.wait('@answerapi')
    cy.wait('@ingredientapi')


    
    selector.elementsquestions.ingredients()
    selector.elements.ingredients_retinol().click()    //ingredients selection
    selector.elements.continue_btn().click()     //continue button
    cy.wait('@answerapi')
    cy.wait('@stressapi')

    selector.elementsquestions.stress()
    selector.elements.little_stress().click()    // stress selection
    cy.wait('@answerapi')
    cy.wait('@sleepapi')


    selector.elementsquestions.sleep()
    selector.elements.sleep_5to6().click()      //sleep selection
    cy.wait('@answerapi')
    cy.wait('@waterapi')


    selector.elementsquestions.waterconsumption()
    selector.elements.water_consumption().click()    //water consumption selection
    cy.wait('@answerapi')
    cy.wait('@spenddayapi')

    selector.elementsquestions.dayspend()
    selector.elements.indoors_wtoutAC().click()     //environment selection
    cy.wait('@answerapi')
    cy.wait('@lifestyleapi')

    selector.elementsquestions.lifestylepart()
    selector.elements.lifestyle_regular_workout().click()   //lifestyle selection
    selector.elements.continue_btn().click()               //continue button
    cy.wait('@answerapi')
    cy.wait('@makeupapi')
    
    selector.elementsquestions.makeup()
    selector.elements.wear_makeup_occasionally().click()    //makeup wearing selection
    cy.wait('@answerapi')
    cy.wait('@smokeapi')

    selector.elementsquestions.smoke()
    selector.elements.smoke_occasionally().click()          //smoking selection
    cy.wait('@answerapi')
    cy.wait('@productpreferenceapi') 

    selector.elementsquestions.productpreference()
    selector.elements.product_preference_none().click()      //product preference selection
    cy.wait('@answerapi')


    selector.elements.staying_month_textbox().clear().type('Lahore')     //click on text box
    selector.genericwait()
    selector.elements.city_selection().click()         //city selection from dropdown
    selector.genericwait()
    selector.elements.continue_btn().click()     //continue bbutton
    cy.wait('@>20weatherapi')
    selector.elements.continue_btn().click()     //continue button
    cy.wait('@mp4videoapi')

    selector.elements.skipto_results_btn().click()      // skip to results button
    cy.wait('@resultpage')
    cy.wait('@resultonproductpage')
    
    selector.producttype.dayserum().should('exist')           //verifing the product type
    selector.producttype.nightserum().should('exist')          //verifing the product type
    selector.producttype.moisturiser().should('exist')         //verifing the product type
    //selector.producttype.nightcream().should('exist')           //verifing the product type
    selector.genericwait()


    selector.elements.add_day_night_set().click()               //add product set button
    cy.wait('@addsetbtnapi')
    
    selector.elements.product_btn().click()                    //product button
    cy.wait('@resultonproductpage')
     

    selector.productname.daydropofsoftness().should('exist')       //verifing the day serum 
    selector.productname.mm().should('exist')                   //verifing the day cream
    selector.productname.nightdropofperfection().should('exist')    //verifing the night serum
    selector.productname.milkyway().should('exist')              //verifing the night cream
    cy.wait(3000)

}


testcase44()
{
    selector.assessment_apis()              //inculuded assessment/result/answer's api's
    selector.elements.gender_male().click() //gender selection
    cy.wait('@answerapi')
    cy.wait('@agequestionapi')

    selector.elementsquestions.age()
    selector.elements.age_any().click()   //age selection
    cy.wait('@answerapi')
    cy.wait('@cheeksapi')

    selector.elementsquestions.cheeksinthemorning()
    selector.elements.cheeks_morning_oily().click()  //cheeks selection
    cy.wait('@answerapi')
    cy.wait('@tzoneapi')

    selector.elementsquestions.tzone()
    selector.elements.tzone_dry().click()   //tzone selection
    cy.wait('@answerapi')
    cy.wait('@skinconcernapi')

    selector.elementsquestions.top2skinconcerns()
    selector.elements.top2_skin_concerns_blackWhitehead().click()      //skin concerns selection  1
    selector.elements.top2_skin_concerns_redness().click()           //skin concerns selection  2
    cy.wait('@answerapi')
    cy.wait('@levelofrednessapi')
    

    selector.elementsquestions.levelofredness()
    selector.elements.levelofredness_mild().click()  //level of redness
    cy.wait('@answerapi')
    cy.wait('@skinshadeapi')


    selector.elementsquestions.skinshade()
    selector.elements.skishade_2nd().click()     //skin shade selection
    cy.wait('@answerapi')
    cy.wait('@reactionapi')

    selector.elementsquestions.skinreaction()
    selector.elements.skinReactions_yes().click()   //skin reaction selection Yes or No
    cy.wait('@answerapi')
    cy.wait('@ingredientapi')


    selector.elementsquestions.ingredients()
    selector.elements.ingredients_salicylicacid().click()    //ingredients selection
    selector.elements.continue_btn().click()     //continue button
    cy.wait('@answerapi')
    cy.wait('@stressapi')


    selector.elementsquestions.stress()
    selector.elements.little_stress().click()    // stress selection
    cy.wait('@answerapi')
    cy.wait('@sleepapi')


    selector.elementsquestions.sleep()
    selector.elements.sleep_5to6().click()      //sleep selection
    cy.wait('@answerapi')
    cy.wait('@waterapi')


    selector.elementsquestions.waterconsumption()
    selector.elements.water_consumption().click()    //water consumption selection
    cy.wait('@answerapi')
    cy.wait('@spenddayapi')


    selector.elementsquestions.dayspend()
    selector.elements.indoors_wtoutAC().click()     //environment selection
    cy.wait('@answerapi')
    cy.wait('@lifestyleapi')


    selector.elementsquestions.lifestylepart()
    selector.elements.lifestyle_regular_workout().click()   //lifestyle selection
    selector.elements.continue_btn().click()               //continue button
    cy.wait('@answerapi')
    cy.wait('@makeupapi')
    
    selector.elementsquestions.makeup()
    selector.elements.wear_makeup_occasionally().click()    //makeup wearing selection
    cy.wait('@answerapi')
    cy.wait('@smokeapi')

    selector.elementsquestions.smoke()
    selector.elements.smoke_occasionally().click()          //smoking selection
    cy.wait('@answerapi')
    cy.wait('@productpreferenceapi') 

    selector.elementsquestions.productpreference()
    selector.elements.product_preference_none().click()      //product preference selection
    cy.wait('@answerapi')


    selector.elements.staying_month_textbox().clear().type('Lahore')     //click on text box
    selector.genericwait()
    selector.elements.city_selection().click()         //city selection from dropdown
    selector.genericwait()
    selector.elements.continue_btn().click()     //continue bbutton
    cy.wait('@>20weatherapi')
    selector.elements.continue_btn().click()     //continue button
    cy.wait('@mp4videoapi')
 

    selector.elements.skipto_results_btn().click()      // skip to results button
    cy.wait('@resultpage')
    cy.wait('@resultonproductpage')

    
    selector.producttype.dayserum().should('exist')           //verifing the product type
    selector.producttype.nightserum().should('exist')          //verifing the product type
    selector.producttype.moisturiser().should('exist')         //verifing the product type
    //selector.producttype.nightcream().should('exist')           //verifing the product type
    selector.genericwait()


    selector.elements.add_day_night_set().click()               //add product set button
    cy.wait('@addsetbtnapi')
    
    selector.elements.product_btn().click()                    //product button
    cy.wait('@resultonproductpage')
     

    selector.productname.daydropofsoftness().should('exist')       //verifing the day serum 
    selector.productname.mm().should('exist')                   //verifing the day cream
    selector.productname.dropofyouth().should('exist')    //verifing the night serum
    selector.productname.milkyway().should('exist')              //verifing the night cream
    cy.wait(3000)

}


testcase45()
{
    selector.assessment_apis()              //inculuded assessment/result/answer's api's
    selector.elements.gender_male().click() //gender selection
    cy.wait('@answerapi')
    cy.wait('@agequestionapi')

    selector.elementsquestions.age()
    selector.elements.age_any().click()   //age selection
    cy.wait('@answerapi')
    cy.wait('@cheeksapi')

    selector.elementsquestions.cheeksinthemorning()
    selector.elements.cheeks_morning_oily().click()  //cheeks selection
    cy.wait('@answerapi')
    cy.wait('@tzoneapi')

    selector.elementsquestions.tzone()
    selector.elements.tzone_dry().click()   //tzone selection
    cy.wait('@answerapi')
    cy.wait('@skinconcernapi')

    selector.elementsquestions.top2skinconcerns()
    selector.elements.top2_skin_concerns_blackWhitehead().click()      //skin concerns selection  1
    selector.elements.top2_skin_concerns_redness().click()  //skin concerns selection  2
    cy.wait('@answerapi')
    cy.wait('@levelofrednessapi')
    

    selector.elementsquestions.levelofredness()
    selector.elements.levelofredness_mild().click()  //level of redness
    cy.wait('@answerapi')
    cy.wait('@skinshadeapi')


    selector.elementsquestions.skinshade()
    selector.elements.skishade_2nd().click()     //skin shade selection
    cy.wait('@answerapi')
    cy.wait('@reactionapi')

    selector.elementsquestions.skinreaction()
    selector.elements.skinReactions_yes().click()   //skin reaction selection Yes or No
    cy.wait('@answerapi')
    cy.wait('@ingredientapi')


    selector.elementsquestions.ingredients()
    selector.elements.ingredients_salicylicacid().click()    //ingredients selection
    selector.elements.continue_btn().click()     //continue button
    cy.wait('@answerapi')
    cy.wait('@stressapi')

    selector.elementsquestions.stress()
    selector.elements.little_stress().click()    // stress selection
    cy.wait('@answerapi')
    cy.wait('@sleepapi')


    selector.elementsquestions.sleep()
    selector.elements.sleep_5to6().click()      //sleep selection
    cy.wait('@answerapi')
    cy.wait('@waterapi')


    selector.elementsquestions.waterconsumption()
    selector.elements.water_consumption().click()    //water consumption selection
    cy.wait('@answerapi')
    cy.wait('@spenddayapi')

    selector.elementsquestions.dayspend()
    selector.elements.indoors_wtoutAC().click()     //environment selection
    cy.wait('@answerapi')
    cy.wait('@lifestyleapi')

    selector.elementsquestions.lifestylepart()
    selector.elements.lifestyle_regular_workout().click()   //lifestyle selection
    selector.elements.continue_btn().click()               //continue button
    cy.wait('@answerapi')
    cy.wait('@makeupapi')
    
    selector.elementsquestions.makeup()
    selector.elements.wear_makeup_occasionally().click()    //makeup wearing selection
    cy.wait('@answerapi')
    cy.wait('@smokeapi')

    selector.elementsquestions.smoke()
    selector.elements.smoke_occasionally().click()          //smoking selection
    cy.wait('@answerapi')
    cy.wait('@productpreferenceapi') 

    selector.elementsquestions.productpreference()
    selector.elements.product_preference_vegan().click()      //product preference selection
    selector.elements.continue_btn().click()     //continue button
    cy.wait('@answerapi')


    selector.elements.staying_month_textbox().clear().type('Lahore')     //click on text box
    selector.genericwait()
    selector.elements.city_selection().click()         //city selection from dropdown
    selector.genericwait()
    selector.elements.continue_btn().click()     //continue bbutton
    cy.wait('@>20weatherapi')
    selector.elements.continue_btn().click()     //continue button
    cy.wait('@mp4videoapi')


    selector.elements.skipto_results_btn().click()      // skip to results button
    cy.wait('@resultpage')
    cy.wait('@resultonproductpage')
  
    
    selector.producttype.dayserum().should('exist')           //verifing the product type
    selector.producttype.nightserum().should('exist')          //verifing the product type
    selector.producttype.moisturiser().should('exist')         //verifing the product type
    //selector.producttype.nightcream().should('exist')           //verifing the product type
    selector.genericwait()


    selector.elements.add_day_night_set().click()               //add product set button
    cy.wait('@addsetbtnapi')
    
    selector.elements.product_btn().click()                    //product button
    cy.wait('@resultonproductpage')
     

    selector.productname.daydropofsoftness().should('exist')       //verifing the day serum 
    selector.productname.mm().should('exist')                   //verifing the day cream
    selector.productname.nightdropoflight().should('exist')    //verifing the night serum
    selector.productname.milkyway().should('exist')              //verifing the night cream
    cy.wait(3000)   

}


testcase46()
{
    selector.assessment_apis()              //inculuded assessment/result/answer's api's 
    selector.elements.gender_male().click() //gender selection
    cy.wait('@answerapi')
    cy.wait('@agequestionapi')
     

    selector.elementsquestions.age()
    selector.elements.age_any().click()   //age selection
    cy.wait('@answerapi')
    cy.wait('@cheeksapi')

     
    selector.elementsquestions.cheeksinthemorning()
    selector.elements.cheeks_morning_oily().click()  //cheeks selection
    cy.wait('@answerapi')
    cy.wait('@tzoneapi')

     
    selector.elementsquestions.tzone()
    selector.elements.tzone_normal().click()   //tzone selection
    cy.wait('@answerapi')
    cy.wait('@skinconcernapi')

     
    selector.elementsquestions.top2skinconcerns()
    selector.elements.top2_skin_concerns_acne().click()  //skin concerns selection
     selector.elements.continue_btn().click()             //continue button
    cy.wait('@answerapi')
    cy.wait('@getacneapi')
     

    selector.elementsquestions.getacne()
    selector.elements.get_acne_always().click()  // select acny stay period
    cy.wait('@answerapi')
    cy.wait('@describeacneapi')


    selector.elementsquestions.describeacne()    //describe acne
    selector.elements.acnehardones().click()     //select acne type
    cy.wait('@answerapi')
    cy.wait('@skinshadeapi')

    selector.elementsquestions.skinshade()
    selector.elements.skishade_2nd().click()     //skin shade selection
    cy.wait('@answerapi')
    cy.wait('@reactionapi')
     

    selector.elementsquestions.skinreaction()
    selector.elements.skinReactions_yes().click()   //skin reaction selection
    cy.wait('@answerapi')
    cy.wait('@ingredientapi')
    

    selector.elementsquestions.ingredients()
    selector.elements.ingredients_retinol().click()    //ingredients selection
    selector.elements.continue_btn().click()           //continue button
    cy.wait('@answerapi')
    cy.wait('@stressapi')
    
    selector.elementsquestions.stress()
    selector.elements.little_stress().click()    // stress selection
    cy.wait('@answerapi')
    cy.wait('@sleepapi')
     

    selector.elementsquestions.sleep()
    selector.elements.sleep_5to6().click()   //sleep selection
    cy.wait('@answerapi')
    cy.wait('@waterapi')
     

    selector.elementsquestions.waterconsumption()
    selector.elements.water_consumption().click()    //water consumption selection
    cy.wait('@answerapi')
    cy.wait('@spenddayapi')
     

    selector.elementsquestions.dayspend()
    selector.elements.indoors_wtoutAC().click()     //environment selection
    cy.wait('@answerapi')
    cy.wait('@lifestyleapi')
     

    selector.elementsquestions.lifestylepart()
    selector.elements.lifestyle_regular_workout().click()   //lifestyle selection
    selector.elements.continue_btn().click()     //continue button
    cy.wait('@answerapi')
    cy.wait('@makeupapi')
     

    selector.elementsquestions.makeup()
    selector.elements.wear_makeup_occasionally().click()    //makeup wearing selection
    cy.wait('@answerapi')
    cy.wait('@smokeapi')
     

    selector.elementsquestions.smoke()
    selector.elements.smoke_occasionally().click()      //smoking selection
    cy.wait('@answerapi')
    cy.wait('@productpreferenceapi')
      

    selector.elementsquestions.productpreference()
    selector.elements.product_preference_none().click()      //product preference selection
    cy.wait('@answerapi')
     

    selector.elements.staying_month_textbox().clear().type('Lahore')     //click on text box
    selector.genericwait()
    selector.elements.city_selection().click()         //city selection from dropdown
    selector.genericwait()
    selector.elements.continue_btn().click()     //continue bbutton
    cy.wait('@>20weatherapi')
    selector.elements.continue_btn().click()     //continue button
    cy.wait('@mp4videoapi')

    selector.elements.skipto_results_btn().click()      // skip to results button
    cy.wait('@resultpage')
    cy.wait('@resultonproductpage')

    
    selector.producttype.dayserum().should('exist')           //verifing the product type
    selector.producttype.nightserum().should('exist')          //verifing the product type
    selector.producttype.moisturiser().should('exist')         //verifing the product type
    //selector.producttype.nightcream().should('exist')           //verifing the product type
    selector.genericwait()


    selector.elements.add_day_night_set().click()               //add product set button
    cy.wait('@addsetbtnapi')
     

    selector.elements.product_btn().click()                    //product button
    cy.wait('@resultonproductpage')
         

    selector.productname.daydropofsoftness().should('exist')        //verifing the day serum
    selector.productname.night_dropofbalance().should('exist')       //verifing the night serum
    selector.productname.mm().should('exist')                       //verifing the day cream
    selector.productname.milkyway().should('exist')              //verifing the night cream
    cy.wait(3000)

}


testcase48()
{
    selector.assessment_apis()              //inculuded assessment/result/answer's api's 
    selector.elements.gender_male().click() //gender selection
    cy.wait('@answerapi')
    cy.wait('@agequestionapi')
     

    selector.elementsquestions.age()
    selector.elements.age_any().click()   //age selection
    cy.wait('@answerapi')
    cy.wait('@cheeksapi')

     
    selector.elementsquestions.cheeksinthemorning()
    selector.elements.cheeks_morning_oily().click()  //cheeks selection
    cy.wait('@answerapi')
    cy.wait('@tzoneapi')

     
    selector.elementsquestions.tzone()
    selector.elements.tzone_normal().click()   //tzone selection
    cy.wait('@answerapi')
    cy.wait('@skinconcernapi')

     
    selector.elementsquestions.top2skinconcerns()
    selector.elements.top2_skin_concerns_acne().click()  //skin concerns selection
     selector.elements.continue_btn().click()             //continue button
    cy.wait('@answerapi')
    cy.wait('@getacneapi')
     

    selector.elementsquestions.getacne()
    selector.elements.get_acne_always().click()  // select acny stay period
    cy.wait('@answerapi')
    cy.wait('@describeacneapi')


    selector.elementsquestions.describeacne()    //describe acne
    selector.elements.acnehardones().click()     //select acne type
    cy.wait('@answerapi')
    cy.wait('@skinshadeapi')

    selector.elementsquestions.skinshade()
    selector.elements.skishade_2nd().click()     //skin shade selection
    cy.wait('@answerapi')
    cy.wait('@reactionapi')
     

    selector.elementsquestions.skinreaction()
    selector.elements.skinReactions_no().click()   //skin reaction selection
    cy.wait('@answerapi')
    cy.wait('@stressapi')
    
    
    selector.elementsquestions.stress()
    selector.elements.little_stress().click()    // stress selection
    cy.wait('@answerapi')
    cy.wait('@sleepapi')
     

    selector.elementsquestions.sleep()
    selector.elements.sleep_5to6().click()   //sleep selection
    cy.wait('@answerapi')
    cy.wait('@waterapi')
     

    selector.elementsquestions.waterconsumption()
    selector.elements.water_consumption().click()    //water consumption selection
    cy.wait('@answerapi')
    cy.wait('@spenddayapi')
     

    selector.elementsquestions.dayspend()
    selector.elements.indoors_wtoutAC().click()     //environment selection
    cy.wait('@answerapi')
    cy.wait('@lifestyleapi')
     

    selector.elementsquestions.lifestylepart()
    selector.elements.lifestyle_regular_workout().click()   //lifestyle selection
    selector.elements.continue_btn().click()     //continue button
    cy.wait('@answerapi')
    cy.wait('@makeupapi')
     

    selector.elementsquestions.makeup()
    selector.elements.wear_makeup_occasionally().click()    //makeup wearing selection
    cy.wait('@answerapi')
    cy.wait('@smokeapi')
     

    selector.elementsquestions.smoke()
    selector.elements.smoke_occasionally().click()      //smoking selection
    cy.wait('@answerapi')
    cy.wait('@productpreferenceapi')
      

    selector.elementsquestions.productpreference()
    selector.elements.product_preference_none().click()      //product preference selection
    cy.wait('@answerapi')
     

    selector.elements.staying_month_textbox().clear().type('Lahore')     //click on text box
    selector.genericwait()
    selector.elements.city_selection().click()         //city selection from dropdown
    selector.genericwait()
    selector.elements.continue_btn().click()     //continue bbutton
    cy.wait('@>20weatherapi')
    selector.elements.continue_btn().click()     //continue button
    cy.wait('@mp4videoapi')

    selector.elements.skipto_results_btn().click()      // skip to results button
    cy.wait('@resultpage')
    cy.wait('@resultonproductpage')

    
    selector.producttype.dayserum().should('exist')           //verifing the product type
    selector.producttype.nightserum().should('exist')          //verifing the product type
    selector.producttype.moisturiser().should('exist')         //verifing the product type
    //selector.producttype.nightcream().should('exist')           //verifing the product type
    selector.genericwait()


    selector.elements.add_day_night_set().click()               //add product set button
    cy.wait('@addsetbtnapi')
     
    selector.elements.product_btn().click()                    //product button
    cy.wait('@resultonproductpage')
    
    selector.productname.day_dropofbalance().should('exist')        //verifing the day serum
    selector.productname.dropofyouth().should('exist')       //verifing the night serum
    selector.productname.mm().should('exist')                       //verifing the day cream
    selector.productname.milkyway().should('exist')              //verifing the night cream
    cy.wait(3000)

}


testcase49()
{
    selector.assessment_apis()              //inculuded assessment/result/answer's api's 
    selector.elements.gender_male().click() //gender selection
    cy.wait('@answerapi')
    cy.wait('@agequestionapi')
     

    selector.elementsquestions.age()
    selector.elements.age_any().click()   //age selection
    cy.wait('@answerapi')
    cy.wait('@cheeksapi')

     
    selector.elementsquestions.cheeksinthemorning()
    selector.elements.cheeks_morning_oily().click()  //cheeks selection
    cy.wait('@answerapi')
    cy.wait('@tzoneapi')

     
    selector.elementsquestions.tzone()
    selector.elements.tzone_normal().click()   //tzone selection
    cy.wait('@answerapi')
    cy.wait('@skinconcernapi')

     
    selector.elementsquestions.top2skinconcerns()
    selector.elements.top2_skin_concerns_acne().click()  //skin concerns selection
     selector.elements.continue_btn().click()             //continue button
    cy.wait('@answerapi')
    cy.wait('@getacneapi')
     

    selector.elementsquestions.getacne()
    selector.elements.get_acne_always().click()  // select acny stay period
    cy.wait('@answerapi')
    cy.wait('@describeacneapi')


    selector.elementsquestions.describeacne()    //describe acne
    selector.elements.acnehardones().click()     //select acne type
    cy.wait('@answerapi')
    cy.wait('@skinshadeapi')

    selector.elementsquestions.skinshade()
    selector.elements.skishade_2nd().click()     //skin shade selection
    cy.wait('@answerapi')
    cy.wait('@reactionapi')
     

    selector.elementsquestions.skinreaction()
    selector.elements.skinReactions_no().click()   //skin reaction selection
    cy.wait('@answerapi')
    cy.wait('@stressapi')
    
    
    selector.elementsquestions.stress()
    selector.elements.little_stress().click()    // stress selection
    cy.wait('@answerapi')
    cy.wait('@sleepapi')
     

    selector.elementsquestions.sleep()
    selector.elements.sleep_5to6().click()   //sleep selection
    cy.wait('@answerapi')
    cy.wait('@waterapi')
     

    selector.elementsquestions.waterconsumption()
    selector.elements.water_consumption().click()    //water consumption selection
    cy.wait('@answerapi')
    cy.wait('@spenddayapi')
     

    selector.elementsquestions.dayspend()
    selector.elements.indoors_wtoutAC().click()     //environment selection
    cy.wait('@answerapi')
    cy.wait('@lifestyleapi')
     

    selector.elementsquestions.lifestylepart()
    selector.elements.lifestyle_regular_workout().click()   //lifestyle selection
    selector.elements.continue_btn().click()     //continue button
    cy.wait('@answerapi')
    cy.wait('@makeupapi')
     

    selector.elementsquestions.makeup()
    selector.elements.wear_makeup_occasionally().click()    //makeup wearing selection
    cy.wait('@answerapi')
    cy.wait('@smokeapi')
     

    selector.elementsquestions.smoke()
    selector.elements.smoke_occasionally().click()      //smoking selection
    cy.wait('@answerapi')
    cy.wait('@productpreferenceapi')
      

    selector.elementsquestions.productpreference()
    selector.elements.product_preference_vegan().click()      //product preference selection
    selector.elements.continue_btn().click()                 //continue button
    cy.wait('@answerapi')
     

    selector.elements.staying_month_textbox().clear().type('Lahore')     //click on text box
    selector.genericwait()
    selector.elements.city_selection().click()         //city selection from dropdown
    selector.genericwait()
    selector.elements.continue_btn().click()     //continue bbutton
    cy.wait('@>20weatherapi')
    selector.elements.continue_btn().click()     //continue button
    cy.wait('@mp4videoapi')

    selector.elements.skipto_results_btn().click()      // skip to results button
    cy.wait('@resultpage')
    cy.wait('@resultonproductpage')

    
    selector.producttype.dayserum().should('exist')           //verifing the product type
    selector.producttype.nightserum().should('exist')          //verifing the product type
    selector.producttype.moisturiser().should('exist')         //verifing the product type
    //selector.producttype.nightcream().should('exist')           //verifing the product type
    selector.genericwait()


    selector.elements.add_day_night_set().click()               //add product set button
    cy.wait('@addsetbtnapi')

    selector.elements.product_btn().click()                    //product button
    cy.wait('@resultonproductpage')
    
    selector.productname.day_dropofbalance().should('exist')        //verifing the day serum
    selector.productname.nightdropofsoftness().should('exist')       //verifing the night serum
    selector.productname.mm().should('exist')                       //verifing the day cream
    selector.productname.milkyway().should('exist')              //verifing the night cream
    cy.wait(3000)

}


testcase51()
{
    selector.assessment_apis()              //inculuded assessment/result/answer's api's 
    selector.elements.gender_male().click() //gender selection
    cy.wait('@answerapi')
    cy.wait('@agequestionapi')
     

    selector.elementsquestions.age()
    selector.elements.age_any().click()   //age selection
    cy.wait('@answerapi')
    cy.wait('@cheeksapi')

     
    selector.elementsquestions.cheeksinthemorning()
    selector.elements.cheeks_morning_oily().click()  //cheeks selection
    cy.wait('@answerapi')
    cy.wait('@tzoneapi')

     
    selector.elementsquestions.tzone()
    selector.elements.tzone_normal().click()   //tzone selection
    cy.wait('@answerapi')
    cy.wait('@skinconcernapi')

     
    selector.elementsquestions.top2skinconcerns()
    selector.elements.top2_skin_concerns_acne().click()  //skin concerns selection
     selector.elements.continue_btn().click()             //continue button
    cy.wait('@answerapi')
    cy.wait('@getacneapi')
     

    selector.elementsquestions.getacne()
    selector.elements.get_acne_always().click()  // select acny stay period
    cy.wait('@answerapi')
    cy.wait('@describeacneapi')


    selector.elementsquestions.describeacne()    //describe acne
    selector.elements.acnehardones().click()     //select acne type
    cy.wait('@answerapi')
    cy.wait('@skinshadeapi')

    selector.elementsquestions.skinshade()
    selector.elements.skishade_2nd().click()     //skin shade selection
    cy.wait('@answerapi')
    cy.wait('@reactionapi')
     

    selector.elementsquestions.skinreaction()
    selector.elements.skinReactions_yes().click()   //skin reaction selection
    cy.wait('@answerapi')
    cy.wait('@ingredientapi')
    

    selector.elementsquestions.ingredients()
    selector.elements.ingredients_salicylicacid().click()    //ingredients selection
    selector.elements.continue_btn().click()    //continue button
    cy.wait('@answerapi')
    cy.wait('@stressapi')
    
    selector.elementsquestions.stress()
    selector.elements.little_stress().click()    // stress selection
    cy.wait('@answerapi')
    cy.wait('@sleepapi')
     

    selector.elementsquestions.sleep()
    selector.elements.sleep_5to6().click()   //sleep selection
    cy.wait('@answerapi')
    cy.wait('@waterapi')
     

    selector.elementsquestions.waterconsumption()
    selector.elements.water_consumption().click()    //water consumption selection
    cy.wait('@answerapi')
    cy.wait('@spenddayapi')
     

    selector.elementsquestions.dayspend()
    selector.elements.indoors_wtoutAC().click()     //environment selection
    cy.wait('@answerapi')
    cy.wait('@lifestyleapi')
     

    selector.elementsquestions.lifestylepart()
    selector.elements.lifestyle_regular_workout().click()   //lifestyle selection
    selector.elements.continue_btn().click()     //continue button
    cy.wait('@answerapi')
    cy.wait('@makeupapi')
     

    selector.elementsquestions.makeup()
    selector.elements.wear_makeup_occasionally().click()    //makeup wearing selection
    cy.wait('@answerapi')
    cy.wait('@smokeapi')
     

    selector.elementsquestions.smoke()
    selector.elements.smoke_occasionally().click()      //smoking selection
    cy.wait('@answerapi')
    cy.wait('@productpreferenceapi')
      

    selector.elementsquestions.productpreference()
    selector.elements.product_preference_none().click()      //product preference selection
    cy.wait('@answerapi')
     

    selector.elements.staying_month_textbox().clear().type('Lahore')     //click on text box
    selector.genericwait()
    selector.elements.city_selection().click()         //city selection from dropdown
    selector.genericwait()
    selector.elements.continue_btn().click()     //continue bbutton
    cy.wait('@>20weatherapi')
    selector.elements.continue_btn().click()     //continue button
    cy.wait('@mp4videoapi')

    selector.elements.skipto_results_btn().click()      // skip to results button
    cy.wait('@resultpage')
    cy.wait('@resultonproductpage')

    
    selector.producttype.dayserum().should('exist')           //verifing the product type
    selector.producttype.nightserum().should('exist')          //verifing the product type
    selector.producttype.moisturiser().should('exist')         //verifing the product type
    //selector.producttype.nightcream().should('exist')           //verifing the product type
    selector.genericwait()


    selector.elements.add_day_night_set().click()               //add product set button
    cy.wait('@addsetbtnapi')


    selector.elements.product_btn().click()                    //product button
    cy.wait('@resultonproductpage')
    

    selector.productname.daydropofsoftness().should('exist')        //verifing the day serum
    selector.productname.dropofyouth().should('exist')       //verifing the night serum
    selector.productname.mm().should('exist')                       //verifing the day cream
    selector.productname.milkyway().should('exist')              //verifing the night cream
    cy.wait(3000)

}


testcase52()
{
    selector.assessment_apis()              //inculuded assessment/result/answer's api's 
    selector.elements.gender_male().click() //gender selection
    cy.wait('@answerapi')
    cy.wait('@agequestionapi')
     

    selector.elementsquestions.age()
    selector.elements.age_any().click()   //age selection
    cy.wait('@answerapi')
    cy.wait('@cheeksapi')

     
    selector.elementsquestions.cheeksinthemorning()
    selector.elements.cheeks_morning_oily().click()  //cheeks selection
    cy.wait('@answerapi')
    cy.wait('@tzoneapi')

     
    selector.elementsquestions.tzone()
    selector.elements.tzone_oily().click()   //tzone selection
    cy.wait('@answerapi')
    cy.wait('@skinconcernapi')

     
    selector.elementsquestions.top2skinconcerns()
    selector.elements.top2_skin_concerns_acne().click()          //skin concerns 1 selection
    selector.elements.top2_skin_concerns_pigmentation().click()  //skin concerns 2 selection
    cy.wait('@answerapi')
    cy.wait('@getacneapi')
     

    selector.elementsquestions.getacne()
    selector.elements.get_acne_always().click()  // select acny stay period
    cy.wait('@answerapi')
    cy.wait('@describeacneapi')


    selector.elementsquestions.describeacne()    //describe acne
    selector.elements.acnehardones().click()     //select acne type
    cy.wait('@answerapi')
    cy.wait('@skinshadeapi')

    selector.elementsquestions.skinshade()
    selector.elements.skishade_2nd().click()     //skin shade selection
    cy.wait('@answerapi')
    cy.wait('@reactionapi')
     

    selector.elementsquestions.skinreaction()
    selector.elements.skinReactions_yes().click()   //skin reaction selection
    cy.wait('@answerapi')
    cy.wait('@ingredientapi')
    

    selector.elementsquestions.ingredients()
    selector.elements.ingredients_retinol().click()    //ingredients selection
    selector.elements.continue_btn().click()           //continue button
    cy.wait('@answerapi')
    cy.wait('@stressapi')
    
    selector.elementsquestions.stress()
    selector.elements.little_stress().click()    // stress selection
    cy.wait('@answerapi')
    cy.wait('@sleepapi')
     

    selector.elementsquestions.sleep()
    selector.elements.sleep_5to6().click()   //sleep selection
    cy.wait('@answerapi')
    cy.wait('@waterapi')
     

    selector.elementsquestions.waterconsumption()
    selector.elements.water_consumption().click()    //water consumption selection
    cy.wait('@answerapi')
    cy.wait('@spenddayapi')
     

    selector.elementsquestions.dayspend()
    selector.elements.indoors_wtoutAC().click()     //environment selection
    cy.wait('@answerapi')
    cy.wait('@lifestyleapi')
     

    selector.elementsquestions.lifestylepart()
    selector.elements.lifestyle_regular_workout().click()   //lifestyle selection
    selector.elements.continue_btn().click()     //continue button
    cy.wait('@answerapi')
    cy.wait('@makeupapi')
     

    selector.elementsquestions.makeup()
    selector.elements.wear_makeup_occasionally().click()    //makeup wearing selection
    cy.wait('@answerapi')
    cy.wait('@smokeapi')
     

    selector.elementsquestions.smoke()
    selector.elements.smoke_occasionally().click()      //smoking selection
    cy.wait('@answerapi')
    cy.wait('@productpreferenceapi')
      

    selector.elementsquestions.productpreference()
    selector.elements.product_preference_none().click()      //product preference selection
    cy.wait('@answerapi')
     

    selector.elements.staying_month_textbox().clear().type('Lahore')     //click on text box
    selector.genericwait()
    selector.elements.city_selection().click()         //city selection from dropdown
    selector.genericwait()
    selector.elements.continue_btn().click()     //continue bbutton
    cy.wait('@>20weatherapi')
    selector.elements.continue_btn().click()     //continue button
    cy.wait('@mp4videoapi')

    selector.elements.skipto_results_btn().click()      // skip to results button
    cy.wait('@resultpage')
    cy.wait('@resultonproductpage')

    
    selector.producttype.dayserum().should('exist')           //verifing the product type
    selector.producttype.nightserum().should('exist')          //verifing the product type
    selector.producttype.moisturiser().should('exist')         //verifing the product type
    //selector.producttype.nightcream().should('exist')           //verifing the product type
    selector.genericwait()


    selector.elements.add_day_night_set().click()               //add product set button
    cy.wait('@addsetbtnapi')


    selector.elements.product_btn().click()                    //product button
    cy.wait('@resultonproductpage')
    
     
    selector.productname.daydropoflight().should('exist')        //verifing the day serum
    selector.productname.night_dropofbalance().should('exist')       //verifing the night serum
    selector.productname.mm().should('exist')                       //verifing the day cream
    selector.productname.milkyway().should('exist')              //verifing the night cream
    cy.wait(3000)

}


testcase54()
{
    selector.assessment_apis()              //inculuded assessment/result/answer's api's 
    selector.elements.gender_male().click() //gender selection
    cy.wait('@answerapi')
    cy.wait('@agequestionapi')
     

    selector.elementsquestions.age()
    selector.elements.age_any().click()   //age selection
    cy.wait('@answerapi')
    cy.wait('@cheeksapi')

     
    selector.elementsquestions.cheeksinthemorning()
    selector.elements.cheeks_morning_oily().click()  //cheeks selection
    cy.wait('@answerapi')
    cy.wait('@tzoneapi')

     
    selector.elementsquestions.tzone()
    selector.elements.tzone_oily().click()   //tzone selection
    cy.wait('@answerapi')
    cy.wait('@skinconcernapi')

     
    selector.elementsquestions.top2skinconcerns()
    selector.elements.top2_skin_concerns_acne().click()          //skin concerns 1 selection
    selector.elements.top2_skin_concerns_pigmentation().click()  //skin concerns 2 selection
    cy.wait('@answerapi')
    cy.wait('@getacneapi')
     

    selector.elementsquestions.getacne()
    selector.elements.get_acne_always().click()  // select acny stay period
    cy.wait('@answerapi')
    cy.wait('@describeacneapi')


    selector.elementsquestions.describeacne()    //describe acne
    selector.elements.acnehardones().click()     //select acne type
    cy.wait('@answerapi')
    cy.wait('@skinshadeapi')

    selector.elementsquestions.skinshade()
    selector.elements.skishade_2nd().click()     //skin shade selection
    cy.wait('@answerapi')
    cy.wait('@reactionapi')
     

    selector.elementsquestions.skinreaction()
    selector.elements.skinReactions_yes().click()   //skin reaction selection
    cy.wait('@answerapi')
    cy.wait('@ingredientapi')
    

    selector.elementsquestions.ingredients()
    selector.elements.ingredients_salicylicacid().click()    //ingredients selection
    selector.elements.continue_btn().click()           //continue button
    cy.wait('@answerapi')
    cy.wait('@stressapi')
    
    selector.elementsquestions.stress()
    selector.elements.little_stress().click()    // stress selection
    cy.wait('@answerapi')
    cy.wait('@sleepapi')
     

    selector.elementsquestions.sleep()
    selector.elements.sleep_5to6().click()   //sleep selection
    cy.wait('@answerapi')
    cy.wait('@waterapi')
     

    selector.elementsquestions.waterconsumption()
    selector.elements.water_consumption().click()    //water consumption selection
    cy.wait('@answerapi')
    cy.wait('@spenddayapi')
     

    selector.elementsquestions.dayspend()
    selector.elements.indoors_wtoutAC().click()     //environment selection
    cy.wait('@answerapi')
    cy.wait('@lifestyleapi')
     

    selector.elementsquestions.lifestylepart()
    selector.elements.lifestyle_regular_workout().click()   //lifestyle selection
    selector.elements.continue_btn().click()     //continue button
    cy.wait('@answerapi')
    cy.wait('@makeupapi')
     

    selector.elementsquestions.makeup()
    selector.elements.wear_makeup_occasionally().click()    //makeup wearing selection
    cy.wait('@answerapi')
    cy.wait('@smokeapi')
     

    selector.elementsquestions.smoke()
    selector.elements.smoke_occasionally().click()      //smoking selection
    cy.wait('@answerapi')
    cy.wait('@productpreferenceapi')
      

    selector.elementsquestions.productpreference()
    selector.elements.product_preference_none().click()      //product preference selection
    cy.wait('@answerapi')
     

    selector.elements.staying_month_textbox().clear().type('Lahore')     //click on text box
    selector.genericwait()
    selector.elements.city_selection().click()         //city selection from dropdown
    selector.genericwait()
    selector.elements.continue_btn().click()     //continue bbutton
    cy.wait('@>20weatherapi')
    selector.elements.continue_btn().click()     //continue button
    cy.wait('@mp4videoapi')

    selector.elements.skipto_results_btn().click()      // skip to results button
    cy.wait('@resultpage')
    cy.wait('@resultonproductpage')

    
    selector.producttype.dayserum().should('exist')           //verifing the product type
    selector.producttype.nightserum().should('exist')          //verifing the product type
    selector.producttype.moisturiser().should('exist')         //verifing the product type
    //selector.producttype.nightcream().should('exist')           //verifing the product type
    selector.genericwait()


    selector.elements.add_day_night_set().click()               //add product set button
    cy.wait('@addsetbtnapi')

    selector.elements.product_btn().click()                    //product button
    cy.wait('@resultonproductpage')
    
     
    selector.productname.daydropofsoftness().should('exist')        //verifing the day serum
    selector.productname.dropofyouth().should('exist')       //verifing the night serum
    selector.productname.mm().should('exist')                       //verifing the day cream
    selector.productname.milkyway().should('exist')              //verifing the night cream
    cy.wait(3000)

}


testcase55()
{
    selector.assessment_apis()              //inculuded assessment/result/answer's api's 
    selector.elements.gender_male().click() //gender selection
    cy.wait('@answerapi')
    cy.wait('@agequestionapi')
     

    selector.elementsquestions.age()
    selector.elements.age_any().click()   //age selection
    cy.wait('@answerapi')
    cy.wait('@cheeksapi')

     
    selector.elementsquestions.cheeksinthemorning()
    selector.elements.cheeks_morning_oily().click()  //cheeks selection
    cy.wait('@answerapi')
    cy.wait('@tzoneapi')

     
    selector.elementsquestions.tzone()
    selector.elements.tzone_oily().click()   //tzone selection
    cy.wait('@answerapi')
    cy.wait('@skinconcernapi')

     
    selector.elementsquestions.top2skinconcerns()
    selector.elements.top2_skin_concerns_acne().click()          //skin concerns 1 selection
    selector.elements.top2_skin_concerns_pigmentation().click()  //skin concerns 2 selection
    cy.wait('@answerapi')
    cy.wait('@getacneapi')
     

    selector.elementsquestions.getacne()
    selector.elements.get_acne_always().click()  // select acny stay period
    cy.wait('@answerapi')
    cy.wait('@describeacneapi')


    selector.elementsquestions.describeacne()    //describe acne
    selector.elements.acnehardones().click()     //select acne type
    cy.wait('@answerapi')
    cy.wait('@skinshadeapi')

    selector.elementsquestions.skinshade()
    selector.elements.skishade_2nd().click()     //skin shade selection
    cy.wait('@answerapi')
    cy.wait('@reactionapi')
     

    selector.elementsquestions.skinreaction()
    selector.elements.skinReactions_yes().click()   //skin reaction selection
    cy.wait('@answerapi')
    cy.wait('@ingredientapi')
    

    selector.elementsquestions.ingredients()
    selector.elements.ingredients_salicylicacid().click()    //ingredients selection
    selector.elements.continue_btn().click()           //continue button
    cy.wait('@answerapi')
    cy.wait('@stressapi')
    
    selector.elementsquestions.stress()
    selector.elements.little_stress().click()    // stress selection
    cy.wait('@answerapi')
    cy.wait('@sleepapi')
     

    selector.elementsquestions.sleep()
    selector.elements.sleep_5to6().click()   //sleep selection
    cy.wait('@answerapi')
    cy.wait('@waterapi')
     

    selector.elementsquestions.waterconsumption()
    selector.elements.water_consumption().click()    //water consumption selection
    cy.wait('@answerapi')
    cy.wait('@spenddayapi')
     

    selector.elementsquestions.dayspend()
    selector.elements.indoors_wtoutAC().click()     //environment selection
    cy.wait('@answerapi')
    cy.wait('@lifestyleapi')
     

    selector.elementsquestions.lifestylepart()
    selector.elements.lifestyle_regular_workout().click()   //lifestyle selection
    selector.elements.continue_btn().click()     //continue button
    cy.wait('@answerapi')
    cy.wait('@makeupapi')
     

    selector.elementsquestions.makeup()
    selector.elements.wear_makeup_occasionally().click()    //makeup wearing selection
    cy.wait('@answerapi')
    cy.wait('@smokeapi')
     

    selector.elementsquestions.smoke()
    selector.elements.smoke_occasionally().click()      //smoking selection
    cy.wait('@answerapi')
    cy.wait('@productpreferenceapi')
      

    selector.elementsquestions.productpreference()
    selector.elements.product_preference_vegan().click()      //product preference selection
    selector.elements.continue_btn().click()                  //continue bbutton
    cy.wait('@answerapi')
     

    selector.elements.staying_month_textbox().clear().type('Lahore')     //click on text box
    selector.genericwait()
    selector.elements.city_selection().click()         //city selection from dropdown
    selector.genericwait()
    selector.elements.continue_btn().click()     //continue bbutton
    cy.wait('@>20weatherapi')
    selector.elements.continue_btn().click()     //continue button
    cy.wait('@mp4videoapi')

    selector.elements.skipto_results_btn().click()      // skip to results button
    cy.wait('@resultpage')
    cy.wait('@resultonproductpage')

    
    selector.producttype.dayserum().should('exist')           //verifing the product type
    selector.producttype.nightserum().should('exist')          //verifing the product type
    selector.producttype.moisturiser().should('exist')         //verifing the product type
    //selector.producttype.nightcream().should('exist')           //verifing the product type
    selector.genericwait()


    selector.elements.add_day_night_set().click()               //add product set button
    cy.wait('@addsetbtnapi')  

    selector.elements.product_btn().click()                    //product button
    cy.wait('@resultonproductpage')
    
     
    selector.productname.daydropofsoftness().should('exist')        //verifing the day serum
    selector.productname.nightdropoflight().should('exist')       //verifing the night serum
    selector.productname.mm().should('exist')                       //verifing the day cream
    selector.productname.milkyway().should('exist')              //verifing the night cream
    cy.wait(3000)

}


testcase56()
{
    selector.assessment_apis()              //inculuded assessment/result/answer's api's 
    selector.elements.gender_male().click() //gender selection
    cy.wait('@answerapi')
    cy.wait('@agequestionapi')
     

    selector.elementsquestions.age()
    selector.elements.age_any().click()   //age selection
    cy.wait('@answerapi')
    cy.wait('@cheeksapi')

     
    selector.elementsquestions.cheeksinthemorning()
    selector.elements.cheeks_morning_oily().click()  //cheeks selection
    cy.wait('@answerapi')
    cy.wait('@tzoneapi')

     
    selector.elementsquestions.tzone()
    selector.elements.tzone_oily().click()   //tzone selection
    cy.wait('@answerapi')
    cy.wait('@skinconcernapi')

     
    selector.elementsquestions.top2skinconcerns()
    selector.elements.top2_skin_concerns_acne().click()          //skin concerns 1 selection
    selector.elements.top2_skin_concerns_pigmentation().click()  //skin concerns 2 selection
    cy.wait('@answerapi')
    cy.wait('@getacneapi')
     

    selector.elementsquestions.getacne()
    selector.elements.get_acne_always().click()  // select acny stay period
    cy.wait('@answerapi')
    cy.wait('@describeacneapi')


    selector.elementsquestions.describeacne()    //describe acne
    selector.elements.acnehardones().click()     //select acne type
    cy.wait('@answerapi')
    cy.wait('@skinshadeapi')

    selector.elementsquestions.skinshade()
    selector.elements.skishade_2nd().click()     //skin shade selection
    cy.wait('@answerapi')
    cy.wait('@reactionapi')
     

    selector.elementsquestions.skinreaction()
    selector.elements.skinReactions_no().click()   //skin reaction selection
    cy.wait('@answerapi')
    cy.wait('@stressapi')
    
    
    selector.elementsquestions.stress()
    selector.elements.little_stress().click()    // stress selection
    cy.wait('@answerapi')
    cy.wait('@sleepapi')
     

    selector.elementsquestions.sleep()
    selector.elements.sleep_5to6().click()   //sleep selection
    cy.wait('@answerapi')
    cy.wait('@waterapi')
     

    selector.elementsquestions.waterconsumption()
    selector.elements.water_consumption().click()    //water consumption selection
    cy.wait('@answerapi')
    cy.wait('@spenddayapi')
     

    selector.elementsquestions.dayspend()
    selector.elements.indoors_wtoutAC().click()     //environment selection
    cy.wait('@answerapi')
    cy.wait('@lifestyleapi')
     

    selector.elementsquestions.lifestylepart()
    selector.elements.lifestyle_regular_workout().click()   //lifestyle selection
    selector.elements.continue_btn().click()     //continue button
    cy.wait('@answerapi')
    cy.wait('@makeupapi')
     

    selector.elementsquestions.makeup()
    selector.elements.wear_makeup_occasionally().click()    //makeup wearing selection
    cy.wait('@answerapi')
    cy.wait('@smokeapi')
     

    selector.elementsquestions.smoke()
    selector.elements.smoke_occasionally().click()      //smoking selection
    cy.wait('@answerapi')
    cy.wait('@productpreferenceapi')
      

    selector.elementsquestions.productpreference()
    selector.elements.product_preference_none().click()      //product preference selection
    cy.wait('@answerapi')
     

    selector.elements.staying_month_textbox().clear().type('Lahore')     //click on text box
    selector.genericwait()
    selector.elements.city_selection().click()         //city selection from dropdown
    selector.genericwait()
    selector.elements.continue_btn().click()     //continue bbutton
    cy.wait('@>20weatherapi')
    selector.elements.continue_btn().click()     //continue button
    cy.wait('@mp4videoapi')

    selector.elements.skipto_results_btn().click()      // skip to results button
    cy.wait('@resultpage')
    cy.wait('@resultonproductpage')

    
    selector.producttype.dayserum().should('exist')           //verifing the product type
    selector.producttype.nightserum().should('exist')          //verifing the product type
    selector.producttype.moisturiser().should('exist')         //verifing the product type
    //selector.producttype.nightcream().should('exist')           //verifing the product type
    selector.genericwait()


    selector.elements.add_day_night_set().click()               //add product set button
    cy.wait('@addsetbtnapi')

    selector.elements.product_btn().click()                    //product button
    cy.wait('@resultonproductpage')
    
     
    selector.productname.day_dropofbalance().should('exist')        //verifing the day serum
    selector.productname.dropofyouth().should('exist')       //verifing the night serum
    selector.productname.mm().should('exist')                       //verifing the day cream
    selector.productname.milkyway().should('exist')              //verifing the night cream
    cy.wait(3000)

}


testcase57()
{
    selector.assessment_apis()              //inculuded assessment/result/answer's api's 
    selector.elements.gender_male().click() //gender selection
    cy.wait('@answerapi')
    cy.wait('@agequestionapi')
     

    selector.elementsquestions.age()
    selector.elements.age_any().click()   //age selection
    cy.wait('@answerapi')
    cy.wait('@cheeksapi')

     
    selector.elementsquestions.cheeksinthemorning()
    selector.elements.cheeks_morning_oily().click()  //cheeks selection
    cy.wait('@answerapi')
    cy.wait('@tzoneapi')

     
    selector.elementsquestions.tzone()
    selector.elements.tzone_oily().click()   //tzone selection
    cy.wait('@answerapi')
    cy.wait('@skinconcernapi')

     
    selector.elementsquestions.top2skinconcerns()
    selector.elements.top2_skin_concerns_acne().click()          //skin concerns 1 selection
    selector.elements.top2_skin_concerns_pigmentation().click()  //skin concerns 2 selection
    cy.wait('@answerapi')
    cy.wait('@getacneapi')
     

    selector.elementsquestions.getacne()
    selector.elements.get_acne_always().click()  // select acny stay period
    cy.wait('@answerapi')
    cy.wait('@describeacneapi')


    selector.elementsquestions.describeacne()    //describe acne
    selector.elements.acnehardones().click()     //select acne type
    cy.wait('@answerapi')
    cy.wait('@skinshadeapi')

    selector.elementsquestions.skinshade()
    selector.elements.skishade_2nd().click()     //skin shade selection
    cy.wait('@answerapi')
    cy.wait('@reactionapi')
     

    selector.elementsquestions.skinreaction()
    selector.elements.skinReactions_no().click()   //skin reaction selection
    cy.wait('@answerapi')
    cy.wait('@stressapi')
    
    selector.elementsquestions.stress()
    selector.elements.little_stress().click()    // stress selection
    cy.wait('@answerapi')
    cy.wait('@sleepapi')
     

    selector.elementsquestions.sleep()
    selector.elements.sleep_5to6().click()   //sleep selection
    cy.wait('@answerapi')
    cy.wait('@waterapi')
     

    selector.elementsquestions.waterconsumption()
    selector.elements.water_consumption().click()    //water consumption selection
    cy.wait('@answerapi')
    cy.wait('@spenddayapi')
     

    selector.elementsquestions.dayspend()
    selector.elements.indoors_wtoutAC().click()     //environment selection
    cy.wait('@answerapi')
    cy.wait('@lifestyleapi')
     

    selector.elementsquestions.lifestylepart()
    selector.elements.lifestyle_regular_workout().click()   //lifestyle selection
    selector.elements.continue_btn().click()     //continue button
    cy.wait('@answerapi')
    cy.wait('@makeupapi')
     

    selector.elementsquestions.makeup()
    selector.elements.wear_makeup_occasionally().click()    //makeup wearing selection
    cy.wait('@answerapi')
    cy.wait('@smokeapi')
     

    selector.elementsquestions.smoke()
    selector.elements.smoke_occasionally().click()      //smoking selection
    cy.wait('@answerapi')
    cy.wait('@productpreferenceapi')
      

    selector.elementsquestions.productpreference()
    selector.elements.product_preference_vegan().click()      //product preference selection
    selector.elements.continue_btn().click()     //continue bbutton
    cy.wait('@answerapi')
     

    selector.elements.staying_month_textbox().clear().type('Lahore')     //click on text box
    selector.genericwait()
    selector.elements.city_selection().click()         //city selection from dropdown
    selector.genericwait()
    selector.elements.continue_btn().click()     //continue bbutton
    cy.wait('@>20weatherapi')
    selector.elements.continue_btn().click()     //continue button
    cy.wait('@mp4videoapi')

    selector.elements.skipto_results_btn().click()      // skip to results button
    cy.wait('@resultpage')
    cy.wait('@resultonproductpage')

    
    selector.producttype.dayserum().should('exist')           //verifing the product type
    selector.producttype.nightserum().should('exist')          //verifing the product type
    selector.producttype.moisturiser().should('exist')         //verifing the product type
    //selector.producttype.nightcream().should('exist')           //verifing the product type
    selector.genericwait()


    selector.elements.add_day_night_set().click()               //add product set button
    cy.wait('@addsetbtnapi')

    selector.elements.product_btn().click()                    //product button
    cy.wait('@resultonproductpage')
    
     
    selector.productname.day_dropofbalance().should('exist')        //verifing the day serum
    selector.productname.nightdropoflight().should('exist')       //verifing the night serum
    selector.productname.mm().should('exist')                       //verifing the day cream
    selector.productname.milkyway().should('exist')              //verifing the night cream
    cy.wait(3000)

}


testcase60()
{
    selector.assessment_apis()              //inculuded assessment/result/answer's api's 
    selector.elements.gender_male().click() //gender selection
    cy.wait('@answerapi')
    cy.wait('@agequestionapi')
     

    selector.elementsquestions.age()
    selector.elements.age_any().click()   //age selection
    cy.wait('@answerapi')
    cy.wait('@cheeksapi')

     
    selector.elementsquestions.cheeksinthemorning()
    selector.elements.cheeks_morning_oily().click()  //cheeks selection
    cy.wait('@answerapi')
    cy.wait('@tzoneapi')

     
    selector.elementsquestions.tzone()
    selector.elements.tzone_veryoily().click()   //tzone selection
    cy.wait('@answerapi')
    cy.wait('@skinconcernapi')

     
    selector.elementsquestions.top2skinconcerns()
    selector.elements.top2_skin_concerns_acne().click()          //skin concerns 1 selection
    selector.elements.top2_skin_concerns_blackWhitehead().click()  //skin concerns 2 selection
    cy.wait('@answerapi')
    cy.wait('@getacneapi')
     

    selector.elementsquestions.getacne()
    selector.elements.get_acne_always().click()  // select acny stay period
    cy.wait('@answerapi')
    cy.wait('@describeacneapi')


    selector.elementsquestions.describeacne()    //describe acne
    selector.elements.acnehardones().click()     //select acne type
    cy.wait('@answerapi')
    cy.wait('@skinshadeapi')

    selector.elementsquestions.skinshade()
    selector.elements.skishade_2nd().click()     //skin shade selection
    cy.wait('@answerapi')
    cy.wait('@reactionapi')
     

    selector.elementsquestions.skinreaction()
    selector.elements.skinReactions_yes().click()   //skin reaction selection
    cy.wait('@answerapi')
    cy.wait('@ingredientapi')
    

    selector.elementsquestions.ingredients()
    selector.elements.ingredients_retinol().click()    //ingredients selection
    selector.elements.continue_btn().click()           //continue button
    cy.wait('@answerapi')
    cy.wait('@stressapi')
    
    selector.elementsquestions.stress()
    selector.elements.little_stress().click()    // stress selection
    cy.wait('@answerapi')
    cy.wait('@sleepapi')
     

    selector.elementsquestions.sleep()
    selector.elements.sleep_5to6().click()   //sleep selection
    cy.wait('@answerapi')
    cy.wait('@waterapi')
     

    selector.elementsquestions.waterconsumption()
    selector.elements.water_consumption().click()    //water consumption selection
    cy.wait('@answerapi')
    cy.wait('@spenddayapi')
     

    selector.elementsquestions.dayspend()
    selector.elements.indoors_wtoutAC().click()     //environment selection
    cy.wait('@answerapi')
    cy.wait('@lifestyleapi')
     

    selector.elementsquestions.lifestylepart()
    selector.elements.lifestyle_regular_workout().click()   //lifestyle selection
    selector.elements.continue_btn().click()     //continue button
    cy.wait('@answerapi')
    cy.wait('@makeupapi')
     

    selector.elementsquestions.makeup()
    selector.elements.wear_makeup_occasionally().click()    //makeup wearing selection
    cy.wait('@answerapi')
    cy.wait('@smokeapi')
     

    selector.elementsquestions.smoke()
    selector.elements.smoke_occasionally().click()      //smoking selection
    cy.wait('@answerapi')
    cy.wait('@productpreferenceapi')
      

    selector.elementsquestions.productpreference()
    selector.elements.product_preference_none().click()      //product preference selection
    cy.wait('@answerapi')
     

    selector.elements.staying_month_textbox().clear().type('Lahore')     //click on text box
    selector.genericwait()
    selector.elements.city_selection().click()         //city selection from dropdown
    selector.genericwait()
    selector.elements.continue_btn().click()     //continue bbutton
    cy.wait('@>20weatherapi')
    selector.elements.continue_btn().click()     //continue button
    cy.wait('@mp4videoapi')

    selector.elements.skipto_results_btn().click()      // skip to results button
    cy.wait('@resultpage')
    cy.wait('@resultonproductpage')

    
    selector.producttype.dayserum().should('exist')           //verifing the product type
    selector.producttype.nightserum().should('exist')          //verifing the product type
    selector.producttype.moisturiser().should('exist')         //verifing the product type
    //selector.producttype.nightcream().should('exist')           //verifing the product type
    selector.genericwait()


    selector.elements.add_day_night_set().click()               //add product set button
    cy.wait('@addsetbtnapi')


    selector.elements.product_btn().click()                    //product button
    cy.wait('@resultonproductpage')
    
     
    selector.productname.day_dropofbalance().should('exist')        //verifing the day serum
    selector.productname.nightdropofperfection().should('exist')       //verifing the night serum
    selector.productname.mm().should('exist')                       //verifing the day cream
    selector.productname.milkyway().should('exist')              //verifing the night cream
    cy.wait(3000)

}


testcase61()
{
    selector.assessment_apis()              //inculuded assessment/result/answer's api's 
    selector.elements.gender_male().click() //gender selection
    cy.wait('@answerapi')
    cy.wait('@agequestionapi')
     

    selector.elementsquestions.age()
    selector.elements.age_any().click()   //age selection
    cy.wait('@answerapi')
    cy.wait('@cheeksapi')

     
    selector.elementsquestions.cheeksinthemorning()
    selector.elements.cheeks_morning_oily().click()  //cheeks selection
    cy.wait('@answerapi')
    cy.wait('@tzoneapi')

     
    selector.elementsquestions.tzone()
    selector.elements.tzone_veryoily().click()   //tzone selection
    cy.wait('@answerapi')
    cy.wait('@skinconcernapi')

     
    selector.elementsquestions.top2skinconcerns()
    selector.elements.top2_skin_concerns_acne().click()          //skin concerns 1 selection
    selector.elements.top2_skin_concerns_blackWhitehead().click()  //skin concerns 2 selection
    cy.wait('@answerapi')
    cy.wait('@getacneapi')
     

    selector.elementsquestions.getacne()
    selector.elements.get_acne_always().click()  // select acny stay period
    cy.wait('@answerapi')
    cy.wait('@describeacneapi')


    selector.elementsquestions.describeacne()    //describe acne
    selector.elements.acnehardones().click()     //select acne type
    cy.wait('@answerapi')
    cy.wait('@skinshadeapi')

    selector.elementsquestions.skinshade()
    selector.elements.skishade_2nd().click()     //skin shade selection
    cy.wait('@answerapi')
    cy.wait('@reactionapi')
     

    selector.elementsquestions.skinreaction()
    selector.elements.skinReactions_no().click()   //skin reaction selection
    cy.wait('@answerapi')
    cy.wait('@stressapi')
    
    
    selector.elementsquestions.stress()
    selector.elements.little_stress().click()    // stress selection
    cy.wait('@answerapi')
    cy.wait('@sleepapi')
     

    selector.elementsquestions.sleep()
    selector.elements.sleep_5to6().click()   //sleep selection
    cy.wait('@answerapi')
    cy.wait('@waterapi')
     

    selector.elementsquestions.waterconsumption()
    selector.elements.water_consumption().click()    //water consumption selection
    cy.wait('@answerapi')
    cy.wait('@spenddayapi')
     

    selector.elementsquestions.dayspend()
    selector.elements.indoors_wtoutAC().click()     //environment selection
    cy.wait('@answerapi')
    cy.wait('@lifestyleapi')
     

    selector.elementsquestions.lifestylepart()
    selector.elements.lifestyle_regular_workout().click()   //lifestyle selection
    selector.elements.continue_btn().click()     //continue button
    cy.wait('@answerapi')
    cy.wait('@makeupapi')
     

    selector.elementsquestions.makeup()
    selector.elements.wear_makeup_occasionally().click()    //makeup wearing selection
    cy.wait('@answerapi')
    cy.wait('@smokeapi')
     

    selector.elementsquestions.smoke()
    selector.elements.smoke_occasionally().click()      //smoking selection
    cy.wait('@answerapi')
    cy.wait('@productpreferenceapi')
      

    selector.elementsquestions.productpreference()
    selector.elements.product_preference_none().click()      //product preference selection
    cy.wait('@answerapi')
     

    selector.elements.staying_month_textbox().clear().type('Lahore')     //click on text box
    selector.genericwait()
    selector.elements.city_selection().click()         //city selection from dropdown
    selector.genericwait()
    selector.elements.continue_btn().click()     //continue bbutton
    cy.wait('@>20weatherapi')
    selector.elements.continue_btn().click()     //continue button
    cy.wait('@mp4videoapi')

    selector.elements.skipto_results_btn().click()      // skip to results button
    cy.wait('@resultpage')
    cy.wait('@resultonproductpage')

    
    selector.producttype.dayserum().should('exist')           //verifing the product type
    selector.producttype.nightserum().should('exist')          //verifing the product type
    selector.producttype.moisturiser().should('exist')         //verifing the product type
    //selector.producttype.nightcream().should('exist')           //verifing the product type
    selector.genericwait()


    selector.elements.add_day_night_set().click()               //add product set button
    cy.wait('@addsetbtnapi')


    selector.elements.product_btn().click()                    //product button
    cy.wait('@resultonproductpage')
    
     
    selector.productname.day_dropofbalance().should('exist')        //verifing the day serum
    selector.productname.dropofyouth().should('exist')       //verifing the night serum
    selector.productname.mm().should('exist')                       //verifing the day cream
    selector.productname.milkyway().should('exist')              //verifing the night cream
    cy.wait(3000)

}


testcase63()
{
    selector.assessment_apis()              //inculuded assessment/result/answer's api's 
    selector.elements.gender_male().click() //gender selection
    cy.wait('@answerapi')
    cy.wait('@agequestionapi')
     

    selector.elementsquestions.age()
    selector.elements.age_any().click()   //age selection
    cy.wait('@answerapi')
    cy.wait('@cheeksapi')

     
    selector.elementsquestions.cheeksinthemorning()
    selector.elements.cheeks_morning_veryoily().click()  //cheeks selection
    cy.wait('@answerapi')
    cy.wait('@tzoneapi')

     
    selector.elementsquestions.tzone()
    selector.elements.tzone_verydry().click()   //tzone selection
    cy.wait('@answerapi')
    cy.wait('@skinconcernapi')

     
    selector.elementsquestions.top2skinconcerns()
    selector.elements.top2_skin_concerns_acne().click()          //skin concerns 1 selection
    selector.elements.top2_skin_concerns_blackWhitehead().click()  //skin concerns 2 selection
    cy.wait('@answerapi')
    cy.wait('@getacneapi')
     

    selector.elementsquestions.getacne()
    selector.elements.get_acne_always().click()  // select acny stay period
    cy.wait('@answerapi')
    cy.wait('@describeacneapi')


    selector.elementsquestions.describeacne()    //describe acne
    selector.elements.acnehardones().click()     //select acne type
    cy.wait('@answerapi')
    cy.wait('@skinshadeapi')

    selector.elementsquestions.skinshade()
    selector.elements.skishade_2nd().click()     //skin shade selection
    cy.wait('@answerapi')
    cy.wait('@reactionapi')
     

    selector.elementsquestions.skinreaction()
    selector.elements.skinReactions_yes().click()   //skin reaction selection
    cy.wait('@answerapi')
    cy.wait('@ingredientapi')
    

    selector.elementsquestions.ingredients()
    selector.elements.ingredients_salicylicacid().click()    //ingredients selection
    selector.elements.continue_btn().click()           //continue button
    cy.wait('@answerapi')
    cy.wait('@stressapi')
    
    selector.elementsquestions.stress()
    selector.elements.little_stress().click()    // stress selection
    cy.wait('@answerapi')
    cy.wait('@sleepapi')
     

    selector.elementsquestions.sleep()
    selector.elements.sleep_5to6().click()   //sleep selection
    cy.wait('@answerapi')
    cy.wait('@waterapi')
     

    selector.elementsquestions.waterconsumption()
    selector.elements.water_consumption().click()    //water consumption selection
    cy.wait('@answerapi')
    cy.wait('@spenddayapi')
     

    selector.elementsquestions.dayspend()
    selector.elements.indoors_wtoutAC().click()     //environment selection
    cy.wait('@answerapi')
    cy.wait('@lifestyleapi')
     

    selector.elementsquestions.lifestylepart()
    selector.elements.lifestyle_regular_workout().click()   //lifestyle selection
    selector.elements.continue_btn().click()     //continue button
    cy.wait('@answerapi')
    cy.wait('@makeupapi')
     

    selector.elementsquestions.makeup()
    selector.elements.wear_makeup_occasionally().click()    //makeup wearing selection
    cy.wait('@answerapi')
    cy.wait('@smokeapi')
     

    selector.elementsquestions.smoke()
    selector.elements.smoke_occasionally().click()      //smoking selection
    cy.wait('@answerapi')
    cy.wait('@productpreferenceapi')
      

    selector.elementsquestions.productpreference()
    selector.elements.product_preference_none().click()      //product preference selection
    cy.wait('@answerapi')
     

    selector.elements.staying_month_textbox().clear().type('Zurich')     //click on text box
    selector.genericwait()
    selector.elements.city_selection().click()         //city selection from dropdown
    selector.genericwait()
    selector.elements.continue_btn().click()     //continue bbutton
    cy.wait('@<20weatherapi')
    selector.elements.continue_btn().click()     //continue button
    cy.wait('@mp4videoapi')

    selector.elements.skipto_results_btn().click()      // skip to results button
    cy.wait('@resultpage')
    cy.wait('@resultonproductpage')

    
    selector.producttype.dayserum().should('exist')           //verifing the product type
    selector.producttype.nightserum().should('exist')          //verifing the product type
    selector.producttype.moisturiser().should('exist')         //verifing the product type
    //selector.producttype.nightcream().should('exist')           //verifing the product type
    selector.genericwait()


    selector.elements.add_day_night_set().click()               //add product set button
    cy.wait('@addsetbtnapi')


    selector.elements.product_btn().click()                    //product button
    cy.wait('@resultonproductpage')
    
     
    selector.productname.daydropofsoftness().should('exist')        //verifing the day serum
    selector.productname.dropofyouth().should('exist')       //verifing the night serum
    selector.productname.dewdatemoisturiser().should('exist')                       //verifing the day cream
    selector.productname.milkyway().should('exist')              //verifing the night cream
    cy.wait(3000)

}


testcase64()
{
    selector.assessment_apis()              //inculuded assessment/result/answer's api's 
    selector.elements.gender_male().click() //gender selection
    cy.wait('@answerapi')
    cy.wait('@agequestionapi')
     

    selector.elementsquestions.age()
    selector.elements.age_any().click()   //age selection
    cy.wait('@answerapi')
    cy.wait('@cheeksapi')

     
    selector.elementsquestions.cheeksinthemorning()
    selector.elements.cheeks_morning_veryoily().click()  //cheeks selection
    cy.wait('@answerapi')
    cy.wait('@tzoneapi')

     
    selector.elementsquestions.tzone()
    selector.elements.tzone_verydry().click()   //tzone selection
    cy.wait('@answerapi')
    cy.wait('@skinconcernapi')

     
    selector.elementsquestions.top2skinconcerns()
    selector.elements.top2_skin_concerns_acne().click()          //skin concerns 1 selection
    selector.elements.top2_skin_concerns_blackWhitehead().click()  //skin concerns 2 selection
    cy.wait('@answerapi')
    cy.wait('@getacneapi')
     

    selector.elementsquestions.getacne()
    selector.elements.get_acne_always().click()  // select acny stay period
    cy.wait('@answerapi')
    cy.wait('@describeacneapi')


    selector.elementsquestions.describeacne()    //describe acne
    selector.elements.acnehardones().click()     //select acne type
    cy.wait('@answerapi')
    cy.wait('@skinshadeapi')

    selector.elementsquestions.skinshade()
    selector.elements.skishade_2nd().click()     //skin shade selection
    cy.wait('@answerapi')
    cy.wait('@reactionapi')
     

    selector.elementsquestions.skinreaction()
    selector.elements.skinReactions_yes().click()   //skin reaction selection
    cy.wait('@answerapi')
    cy.wait('@ingredientapi')
    

    selector.elementsquestions.ingredients()
    selector.elements.ingredients_salicylicacid().click()    //ingredients selection
    selector.elements.continue_btn().click()           //continue button
    cy.wait('@answerapi')
    cy.wait('@stressapi')
    
    selector.elementsquestions.stress()
    selector.elements.little_stress().click()    // stress selection
    cy.wait('@answerapi')
    cy.wait('@sleepapi')
     

    selector.elementsquestions.sleep()
    selector.elements.sleep_5to6().click()   //sleep selection
    cy.wait('@answerapi')
    cy.wait('@waterapi')
     

    selector.elementsquestions.waterconsumption()
    selector.elements.water_consumption().click()    //water consumption selection
    cy.wait('@answerapi')
    cy.wait('@spenddayapi')
     

    selector.elementsquestions.dayspend()
    selector.elements.indoors_wtoutAC().click()     //environment selection
    cy.wait('@answerapi')
    cy.wait('@lifestyleapi')
     

    selector.elementsquestions.lifestylepart()
    selector.elements.lifestyle_regular_workout().click()   //lifestyle selection
    selector.elements.continue_btn().click()     //continue button
    cy.wait('@answerapi')
    cy.wait('@makeupapi')
     

    selector.elementsquestions.makeup()
    selector.elements.wear_makeup_occasionally().click()    //makeup wearing selection
    cy.wait('@answerapi')
    cy.wait('@smokeapi')
     

    selector.elementsquestions.smoke()
    selector.elements.smoke_occasionally().click()      //smoking selection
    cy.wait('@answerapi')
    cy.wait('@productpreferenceapi')
      

    selector.elementsquestions.productpreference()
    selector.elements.product_preference_vegan().click()      //product preference selection
    selector.elements.continue_btn().click()     //continue bbutton
    cy.wait('@answerapi')
     

    selector.elements.staying_month_textbox().clear().type('Zurich')     //click on text box
    selector.genericwait()
    selector.elements.city_selection().click()         //city selection from dropdown
    selector.genericwait()
    selector.elements.continue_btn().click()     //continue bbutton
    cy.wait('@<20weatherapi')
    selector.elements.continue_btn().click()     //continue button
    cy.wait('@mp4videoapi')

    selector.elements.skipto_results_btn().click()      // skip to results button
    cy.wait('@resultpage')
    cy.wait('@resultonproductpage')

    
    selector.producttype.dayserum().should('exist')           //verifing the product type
    selector.producttype.nightserum().should('exist')          //verifing the product type
    selector.producttype.moisturiser().should('exist')         //verifing the product type
    //selector.producttype.nightcream().should('exist')           //verifing the product type
    selector.genericwait()


    selector.elements.add_day_night_set().click()               //add product set button
    cy.wait('@addsetbtnapi')


    selector.elements.product_btn().click()                    //product button
    cy.wait('@resultonproductpage')
      

    selector.productname.daydropofsoftness().should('exist')        //verifing the day serum
    selector.productname.nightdropoflight().should('exist')       //verifing the night serum
    selector.productname.dewdatemoisturiser().should('exist')      //verifing the day cream
    selector.productname.milkyway().should('exist')              //verifing the night cream
    cy.wait(3000)

}


testcase65()
{
    selector.assessment_apis()              //inculuded assessment/result/answer's api's 
    selector.elements.gender_male().click() //gender selection
    cy.wait('@answerapi')
    cy.wait('@agequestionapi')
     

    selector.elementsquestions.age()
    selector.elements.age_any().click()   //age selection
    cy.wait('@answerapi')
    cy.wait('@cheeksapi')

     
    selector.elementsquestions.cheeksinthemorning()
    selector.elements.cheeks_morning_veryoily().click()  //cheeks selection
    cy.wait('@answerapi')
    cy.wait('@tzoneapi')

     
    selector.elementsquestions.tzone()
    selector.elements.tzone_verydry().click()   //tzone selection
    cy.wait('@answerapi')
    cy.wait('@skinconcernapi')

     
    selector.elementsquestions.top2skinconcerns()
    selector.elements.top2_skin_concerns_pigmentation().click()          //skin concerns 1 selection
    selector.elements.continue_btn().click()           //continue button
    cy.wait('@answerapi')
    cy.wait('@skinshadeapi')


    selector.elementsquestions.skinshade()
    selector.elements.skishade_2nd().click()     //skin shade selection
    cy.wait('@answerapi')
    cy.wait('@reactionapi')
     

    selector.elementsquestions.skinreaction()
    selector.elements.skinReactions_yes().click()   //skin reaction selection
    cy.wait('@answerapi')
    cy.wait('@ingredientapi')
    

    selector.elementsquestions.ingredients()
    selector.elements.ingredients_retinol().click()    //ingredients selection
    selector.elements.continue_btn().click()           //continue button
    cy.wait('@answerapi')
    cy.wait('@stressapi')
    
    selector.elementsquestions.stress()
    selector.elements.little_stress().click()    // stress selection
    cy.wait('@answerapi')
    cy.wait('@sleepapi')
     

    selector.elementsquestions.sleep()
    selector.elements.sleep_5to6().click()   //sleep selection
    cy.wait('@answerapi')
    cy.wait('@waterapi')
     

    selector.elementsquestions.waterconsumption()
    selector.elements.water_consumption().click()    //water consumption selection
    cy.wait('@answerapi')
    cy.wait('@spenddayapi')
     

    selector.elementsquestions.dayspend()
    selector.elements.indoors_wtoutAC().click()     //environment selection
    cy.wait('@answerapi')
    cy.wait('@lifestyleapi')
     

    selector.elementsquestions.lifestylepart()
    selector.elements.lifestyle_regular_workout().click()   //lifestyle selection
    selector.elements.continue_btn().click()     //continue button
    cy.wait('@answerapi')
    cy.wait('@makeupapi')
     

    selector.elementsquestions.makeup()
    selector.elements.wear_makeup_occasionally().click()    //makeup wearing selection
    cy.wait('@answerapi')
    cy.wait('@smokeapi')
     

    selector.elementsquestions.smoke()
    selector.elements.smoke_occasionally().click()      //smoking selection
    cy.wait('@answerapi')
    cy.wait('@productpreferenceapi')
      

    selector.elementsquestions.productpreference()
    selector.elements.product_preference_vegan().click()      //product preference selection
    selector.elements.continue_btn().click()     //continue bbutton
    cy.wait('@answerapi')
     

    selector.elements.staying_month_textbox().clear().type('Zurich')     //click on text box
    selector.genericwait()
    selector.elements.city_selection().click()         //city selection from dropdown
    selector.genericwait()
    selector.elements.continue_btn().click()     //continue bbutton
    cy.wait('@<20weatherapi')
    selector.elements.continue_btn().click()     //continue button
    cy.wait('@mp4videoapi')

    selector.elements.skipto_results_btn().click()      // skip to results button
    cy.wait('@resultpage')
    cy.wait('@resultonproductpage')

    
    selector.producttype.dayserum().should('exist')           //verifing the product type
    selector.producttype.nightserum().should('exist')          //verifing the product type
    selector.producttype.moisturiser().should('exist')         //verifing the product type
    //selector.producttype.nightcream().should('exist')           //verifing the product type
    selector.genericwait()


    selector.elements.add_day_night_set().click()               //add product set button
    cy.wait('@addsetbtnapi')
    

    selector.elements.product_btn().click()                    //product button
    cy.wait('@resultonproductpage')
    
     
    selector.productname.daydropoflight().should('exist')        //verifing the day serum
    selector.productname.nightdropofsoftness().should('exist')       //verifing the night serum
    selector.productname.dewdatemoisturiser().should('exist')     //verifing the day cream
    selector.productname.milkyway().should('exist')              //verifing the night cream
    cy.wait(3000)

}


testcase66()
{
    selector.assessment_apis()              //inculuded assessment/result/answer's api's 
    selector.elements.gender_male().click() //gender selection
    cy.wait('@answerapi')
    cy.wait('@agequestionapi')
     

    selector.elementsquestions.age()
    selector.elements.age_any().click()   //age selection
    cy.wait('@answerapi')
    cy.wait('@cheeksapi')

     
    selector.elementsquestions.cheeksinthemorning()
    selector.elements.cheeks_morning_veryoily().click()  //cheeks selection
    cy.wait('@answerapi')
    cy.wait('@tzoneapi')

     
    selector.elementsquestions.tzone()
    selector.elements.tzone_verydry().click()   //tzone selection
    cy.wait('@answerapi')
    cy.wait('@skinconcernapi')

     
    selector.elementsquestions.top2skinconcerns()
    selector.elements.top2_skin_concerns_pigmentation().click()          //skin concerns 1 selection
    selector.elements.continue_btn().click()           //continue button
    cy.wait('@answerapi')
    cy.wait('@skinshadeapi')
    

    selector.elementsquestions.skinshade()
    selector.elements.skishade_2nd().click()     //skin shade selection
    cy.wait('@answerapi')
    cy.wait('@reactionapi')
     

    selector.elementsquestions.skinreaction()
    selector.elements.skinReactions_no().click()   //skin reaction selection
    cy.wait('@answerapi')
    cy.wait('@stressapi')
    
    selector.elementsquestions.stress()
    selector.elements.little_stress().click()    // stress selection
    cy.wait('@answerapi')
    cy.wait('@sleepapi')
     

    selector.elementsquestions.sleep()
    selector.elements.sleep_5to6().click()   //sleep selection
    cy.wait('@answerapi')
    cy.wait('@waterapi')
     

    selector.elementsquestions.waterconsumption()
    selector.elements.water_consumption().click()    //water consumption selection
    cy.wait('@answerapi')
    cy.wait('@spenddayapi')
     

    selector.elementsquestions.dayspend()
    selector.elements.indoors_wtoutAC().click()     //environment selection
    cy.wait('@answerapi')
    cy.wait('@lifestyleapi')
     

    selector.elementsquestions.lifestylepart()
    selector.elements.lifestyle_regular_workout().click()   //lifestyle selection
    selector.elements.continue_btn().click()     //continue button
    cy.wait('@answerapi')
    cy.wait('@makeupapi')
     

    selector.elementsquestions.makeup()
    selector.elements.wear_makeup_occasionally().click()    //makeup wearing selection
    cy.wait('@answerapi')
    cy.wait('@smokeapi')
     

    selector.elementsquestions.smoke()
    selector.elements.smoke_occasionally().click()      //smoking selection
    cy.wait('@answerapi')
    cy.wait('@productpreferenceapi')
      

    selector.elementsquestions.productpreference()
    selector.elements.product_preference_none().click()      //product preference selection
    cy.wait('@answerapi')
     

    selector.elements.staying_month_textbox().clear().type('Zurich')     //click on text box
    selector.genericwait()
    selector.elements.city_selection().click()         //city selection from dropdown
    selector.genericwait()
    selector.elements.continue_btn().click()     //continue bbutton
    cy.wait('@<20weatherapi')
    selector.elements.continue_btn().click()     //continue button
    cy.wait('@mp4videoapi')

    selector.elements.skipto_results_btn().click()      // skip to results button
    cy.wait('@resultpage')
    cy.wait('@resultonproductpage')

    
    selector.producttype.dayserum().should('exist')           //verifing the product type
    selector.producttype.nightserum().should('exist')          //verifing the product type
    selector.producttype.moisturiser().should('exist')         //verifing the product type
    //selector.producttype.nightcream().should('exist')           //verifing the product type
    selector.genericwait()


    selector.elements.add_day_night_set().click()               //add product set button
    cy.wait('@addsetbtnapi')

    selector.elements.product_btn().click()                    //product button
    cy.wait('@resultonproductpage')
    
     
    selector.productname.daydropoflight().should('exist')        //verifing the day serum
    selector.productname.dropofyouth().should('exist')       //verifing the night serum
    selector.productname.dewdatemoisturiser().should('exist')     //verifing the day cream
    selector.productname.milkyway().should('exist')              //verifing the night cream
    cy.wait(3000)

}



testcase67()
{
    selector.assessment_apis()              //inculuded assessment/result/answer's api's 
    selector.elements.gender_male().click() //gender selection
    cy.wait('@answerapi')
    cy.wait('@agequestionapi')
     

    selector.elementsquestions.age()
    selector.elements.age_any().click()   //age selection
    cy.wait('@answerapi')
    cy.wait('@cheeksapi')

     
    selector.elementsquestions.cheeksinthemorning()
    selector.elements.cheeks_morning_veryoily().click()  //cheeks selection
    cy.wait('@answerapi')
    cy.wait('@tzoneapi')

     
    selector.elementsquestions.tzone()
    selector.elements.tzone_verydry().click()   //tzone selection
    cy.wait('@answerapi')
    cy.wait('@skinconcernapi')

     
    selector.elementsquestions.top2skinconcerns()
    selector.elements.top2_skin_concerns_pigmentation().click()          //skin concerns 1 selection
    selector.elements.continue_btn().click()           //continue button
    cy.wait('@answerapi')
    cy.wait('@skinshadeapi')
     

    selector.elementsquestions.skinshade()
    selector.elements.skishade_2nd().click()     //skin shade selection
    cy.wait('@answerapi')
    cy.wait('@reactionapi')
     

    selector.elementsquestions.skinreaction()
    selector.elements.skinReactions_no().click()   //skin reaction selection
    cy.wait('@answerapi')
    cy.wait('@stressapi')
    
    
    selector.elementsquestions.stress()
    selector.elements.little_stress().click()    // stress selection
    cy.wait('@answerapi')
    cy.wait('@sleepapi')
     

    selector.elementsquestions.sleep()
    selector.elements.sleep_5to6().click()   //sleep selection
    cy.wait('@answerapi')
    cy.wait('@waterapi')
     

    selector.elementsquestions.waterconsumption()
    selector.elements.water_consumption().click()    //water consumption selection
    cy.wait('@answerapi')
    cy.wait('@spenddayapi')
     

    selector.elementsquestions.dayspend()
    selector.elements.indoors_wtoutAC().click()     //environment selection
    cy.wait('@answerapi')
    cy.wait('@lifestyleapi')
     

    selector.elementsquestions.lifestylepart()
    selector.elements.lifestyle_regular_workout().click()   //lifestyle selection
    selector.elements.continue_btn().click()     //continue button
    cy.wait('@answerapi')
    cy.wait('@makeupapi')
     

    selector.elementsquestions.makeup()
    selector.elements.wear_makeup_occasionally().click()    //makeup wearing selection
    cy.wait('@answerapi')
    cy.wait('@smokeapi')
     

    selector.elementsquestions.smoke()
    selector.elements.smoke_occasionally().click()      //smoking selection
    cy.wait('@answerapi')
    cy.wait('@productpreferenceapi')
      

    selector.elementsquestions.productpreference()
    selector.elements.product_preference_vegan().click()      //product preference selection
    selector.elements.continue_btn().click()                 //continue bbutton
    cy.wait('@answerapi')
     

    selector.elements.staying_month_textbox().clear().type('Lahore')     //click on text box
    selector.genericwait()
    selector.elements.city_selection().click()         //city selection from dropdown
    selector.genericwait()
    selector.elements.continue_btn().click()     //continue bbutton
    cy.wait('@>20weatherapi')
    selector.elements.continue_btn().click()     //continue button
    cy.wait('@mp4videoapi')

    selector.elements.skipto_results_btn().click()      // skip to results button
    cy.wait('@resultpage')
    cy.wait('@resultonproductpage')

    
    selector.producttype.dayserum().should('exist')           //verifing the product type
    selector.producttype.nightserum().should('exist')          //verifing the product type
    selector.producttype.moisturiser().should('exist')         //verifing the product type
    //selector.producttype.nightcream().should('exist')           //verifing the product type
    selector.genericwait()


    selector.elements.add_day_night_set().click()               //add product set button
    cy.wait('@addsetbtnapi')

    selector.elements.product_btn().click()                    //product button
    cy.wait('@resultonproductpage')
    

    selector.productname.daydropoflight().should('exist')        //verifing the day serum
    selector.productname.nightdropofsoftness().should('exist')       //verifing the night serum
    selector.productname.mm().should('exist')     //verifing the day cream
    selector.productname.milkyway().should('exist')              //verifing the night cream
    cy.wait(3000)

}


testcase68()
{
    selector.assessment_apis()              //inculuded assessment/result/answer's api's 
    selector.elements.gender_male().click() //gender selection
    cy.wait('@answerapi')
    cy.wait('@agequestionapi')
     

    selector.elementsquestions.age()
    selector.elements.age_any().click()   //age selection
    cy.wait('@answerapi')
    cy.wait('@cheeksapi')

     
    selector.elementsquestions.cheeksinthemorning()
    selector.elements.cheeks_morning_veryoily().click()  //cheeks selection
    cy.wait('@answerapi')
    cy.wait('@tzoneapi')

     
    selector.elementsquestions.tzone()
    selector.elements.tzone_dry().click()   //tzone selection
    cy.wait('@answerapi')
    cy.wait('@skinconcernapi')

     
    selector.elementsquestions.top2skinconcerns()
    selector.elements.top2_skin_concerns_pigmentation().click()          //skin concerns 1 selection
    selector.elements.top2_skin_concerns_blackWhitehead().click()          //skin concerns 2 selection
    cy.wait('@answerapi')
    cy.wait('@skinshadeapi')
     


    selector.elementsquestions.skinshade()
    selector.elements.skishade_2nd().click()     //skin shade selection
    cy.wait('@answerapi')
    cy.wait('@reactionapi')
     

    selector.elementsquestions.skinreaction()
    selector.elements.skinReactions_no().click()   //skin reaction selection
    cy.wait('@answerapi')
    cy.wait('@stressapi')
    
    
    selector.elementsquestions.stress()
    selector.elements.little_stress().click()    // stress selection
    cy.wait('@answerapi')
    cy.wait('@sleepapi')
     

    selector.elementsquestions.sleep()
    selector.elements.sleep_5to6().click()   //sleep selection
    cy.wait('@answerapi')
    cy.wait('@waterapi')
     

    selector.elementsquestions.waterconsumption()
    selector.elements.water_consumption().click()    //water consumption selection
    cy.wait('@answerapi')
    cy.wait('@spenddayapi')
     

    selector.elementsquestions.dayspend()
    selector.elements.indoors_wtoutAC().click()     //environment selection
    cy.wait('@answerapi')
    cy.wait('@lifestyleapi')
     

    selector.elementsquestions.lifestylepart()
    selector.elements.lifestyle_regular_workout().click()   //lifestyle selection
    selector.elements.continue_btn().click()     //continue button
    cy.wait('@answerapi')
    cy.wait('@makeupapi')
     

    selector.elementsquestions.makeup()
    selector.elements.wear_makeup_occasionally().click()    //makeup wearing selection
    cy.wait('@answerapi')
    cy.wait('@smokeapi')
     

    selector.elementsquestions.smoke()
    selector.elements.smoke_occasionally().click()      //smoking selection
    cy.wait('@answerapi')
    cy.wait('@productpreferenceapi')
      

    selector.elementsquestions.productpreference()
    selector.elements.product_preference_vegan().click()      //product preference selection
    selector.elements.continue_btn().click()                 //continue bbutton
    cy.wait('@answerapi')
     

    selector.elements.staying_month_textbox().clear().type('Lahore')     //click on text box
    selector.genericwait()
    selector.elements.city_selection().click()         //city selection from dropdown
    selector.genericwait()
    selector.elements.continue_btn().click()     //continue bbutton
    cy.wait('@>20weatherapi')
    selector.elements.continue_btn().click()     //continue button
    cy.wait('@mp4videoapi')

    selector.elements.skipto_results_btn().click()      // skip to results button
    cy.wait('@resultpage')
    cy.wait('@resultonproductpage')

    
    selector.producttype.dayserum().should('exist')           //verifing the product type
    selector.producttype.nightserum().should('exist')          //verifing the product type
    selector.producttype.moisturiser().should('exist')         //verifing the product type
    //selector.producttype.nightcream().should('exist')           //verifing the product type
    selector.genericwait()


    selector.elements.add_day_night_set().click()               //add product set button
    cy.wait('@addsetbtnapi')


    selector.elements.product_btn().click()                    //product button
    cy.wait('@resultonproductpage')
    
     
    selector.productname.daydropoflight().should('exist')        //verifing the day serum
    selector.productname.nightdropofperfection().should('exist')       //verifing the night serum
    selector.productname.mm().should('exist')     //verifing the day cream
    selector.productname.milkyway().should('exist')              //verifing the night cream
    cy.wait(3000)

}


testcase69()
{
    selector.assessment_apis()              //inculuded assessment/result/answer's api's 
    selector.elements.gender_male().click() //gender selection
    cy.wait('@answerapi')
    cy.wait('@agequestionapi')
     

    selector.elementsquestions.age()
    selector.elements.age_any().click()   //age selection
    cy.wait('@answerapi')
    cy.wait('@cheeksapi')

     
    selector.elementsquestions.cheeksinthemorning()
    selector.elements.cheeks_morning_veryoily().click()  //cheeks selection
    cy.wait('@answerapi')
    cy.wait('@tzoneapi')

     
    selector.elementsquestions.tzone()
    selector.elements.tzone_normal().click()   //tzone selection
    cy.wait('@answerapi')
    cy.wait('@skinconcernapi')

     
    selector.elementsquestions.top2skinconcerns()
    selector.elements.top2_skin_concerns_pigmentation().click()          //skin concerns 1 selection
    selector.elements.top2_skin_concerns_blackWhitehead().click()          //skin concerns 2 selection
    cy.wait('@answerapi')
    cy.wait('@skinshadeapi')
     

    selector.elementsquestions.skinshade()
    selector.elements.skishade_2nd().click()     //skin shade selection
    cy.wait('@answerapi')
    cy.wait('@reactionapi')
     

    selector.elementsquestions.skinreaction()
    selector.elements.skinReactions_yes().click()   //skin reaction selection
    cy.wait('@answerapi')
    cy.wait('@ingredientapi')
    

    selector.elementsquestions.ingredients()
    selector.elements.ingredients_salicylicacid().click()    //ingredients selection
    selector.elements.continue_btn().click()           //continue button
    cy.wait('@answerapi')
    cy.wait('@stressapi')
    

    selector.elementsquestions.stress()
    selector.elements.little_stress().click()    // stress selection
    cy.wait('@answerapi')
    cy.wait('@sleepapi')
     

    selector.elementsquestions.sleep()
    selector.elements.sleep_5to6().click()   //sleep selection
    cy.wait('@answerapi')
    cy.wait('@waterapi')
     

    selector.elementsquestions.waterconsumption()
    selector.elements.water_consumption().click()    //water consumption selection
    cy.wait('@answerapi')
    cy.wait('@spenddayapi')
     

    selector.elementsquestions.dayspend()
    selector.elements.indoors_wtoutAC().click()     //environment selection
    cy.wait('@answerapi')
    cy.wait('@lifestyleapi')
     

    selector.elementsquestions.lifestylepart()
    selector.elements.lifestyle_regular_workout().click()   //lifestyle selection
    selector.elements.continue_btn().click()     //continue button
    cy.wait('@answerapi')
    cy.wait('@makeupapi')
     

    selector.elementsquestions.makeup()
    selector.elements.wear_makeup_occasionally().click()    //makeup wearing selection
    cy.wait('@answerapi')
    cy.wait('@smokeapi')
     

    selector.elementsquestions.smoke()
    selector.elements.smoke_occasionally().click()      //smoking selection
    cy.wait('@answerapi')
    cy.wait('@productpreferenceapi')
      

    selector.elementsquestions.productpreference()
    selector.elements.product_preference_none().click()      //product preference selection
    cy.wait('@answerapi')
     

    selector.elements.staying_month_textbox().clear().type('Lahore')     //click on text box
    selector.genericwait()
    selector.elements.city_selection().click()         //city selection from dropdown
    selector.genericwait()
    selector.elements.continue_btn().click()     //continue bbutton
    cy.wait('@>20weatherapi')
    selector.elements.continue_btn().click()     //continue button
    cy.wait('@mp4videoapi')

    selector.elements.skipto_results_btn().click()      // skip to results button
    cy.wait('@resultpage')
    cy.wait('@resultonproductpage')

    
    selector.producttype.dayserum().should('exist')           //verifing the product type
    selector.producttype.nightserum().should('exist')          //verifing the product type
    selector.producttype.moisturiser().should('exist')         //verifing the product type
    //selector.producttype.nightcream().should('exist')           //verifing the product type
    selector.genericwait()


    selector.elements.add_day_night_set().click()               //add product set button
    cy.wait('@addsetbtnapi')


    selector.elements.product_btn().click()                    //product button
    cy.wait('@resultonproductpage')
      

    selector.productname.daydropoflight().should('exist')        //verifing the day serum
    selector.productname.dropofyouth().should('exist')       //verifing the night serum
    selector.productname.mm().should('exist')                     //verifing the day cream
    selector.productname.milkyway().should('exist')              //verifing the night cream
    cy.wait(3000)

}


testcase70()
{
    selector.assessment_apis()              //inculuded assessment/result/answer's api's 
    selector.elements.gender_male().click() //gender selection
    cy.wait('@answerapi')
    cy.wait('@agequestionapi')
     

    selector.elementsquestions.age()
    selector.elements.age_any().click()   //age selection
    cy.wait('@answerapi')
    cy.wait('@cheeksapi')

     
    selector.elementsquestions.cheeksinthemorning()
    selector.elements.cheeks_morning_veryoily().click()  //cheeks selection
    cy.wait('@answerapi')
    cy.wait('@tzoneapi')

     
    selector.elementsquestions.tzone()
    selector.elements.tzone_normal().click()   //tzone selection
    cy.wait('@answerapi')
    cy.wait('@skinconcernapi')

     
    selector.elementsquestions.top2skinconcerns()
    selector.elements.top2_skin_concerns_pigmentation().click()          //skin concerns 1 selection
    selector.elements.top2_skin_concerns_blackWhitehead().click()          //skin concerns 2 selection
    cy.wait('@answerapi')
    cy.wait('@skinshadeapi')
     

    selector.elementsquestions.skinshade()
    selector.elements.skishade_2nd().click()     //skin shade selection
    cy.wait('@answerapi')
    cy.wait('@reactionapi')
     

    selector.elementsquestions.skinreaction()
    selector.elements.skinReactions_yes().click()   //skin reaction selection
    cy.wait('@answerapi')
    cy.wait('@ingredientapi')
    

    selector.elementsquestions.ingredients()
    selector.elements.ingredients_salicylicacid().click()    //ingredients selection
    selector.elements.continue_btn().click()           //continue button
    cy.wait('@answerapi')
    cy.wait('@stressapi')
    

    selector.elementsquestions.stress()
    selector.elements.little_stress().click()    // stress selection
    cy.wait('@answerapi')
    cy.wait('@sleepapi')
     

    selector.elementsquestions.sleep()
    selector.elements.sleep_5to6().click()   //sleep selection
    cy.wait('@answerapi')
    cy.wait('@waterapi')
     

    selector.elementsquestions.waterconsumption()
    selector.elements.water_consumption().click()    //water consumption selection
    cy.wait('@answerapi')
    cy.wait('@spenddayapi')
     

    selector.elementsquestions.dayspend()
    selector.elements.indoors_wtoutAC().click()     //environment selection
    cy.wait('@answerapi')
    cy.wait('@lifestyleapi')
     

    selector.elementsquestions.lifestylepart()
    selector.elements.lifestyle_regular_workout().click()   //lifestyle selection
    selector.elements.continue_btn().click()     //continue button
    cy.wait('@answerapi')
    cy.wait('@makeupapi')
     

    selector.elementsquestions.makeup()
    selector.elements.wear_makeup_occasionally().click()    //makeup wearing selection
    cy.wait('@answerapi')
    cy.wait('@smokeapi')
     

    selector.elementsquestions.smoke()
    selector.elements.smoke_occasionally().click()      //smoking selection
    cy.wait('@answerapi')
    cy.wait('@productpreferenceapi')
      

    selector.elementsquestions.productpreference()
    selector.elements.product_preference_vegan().click()      //product preference selection
    selector.elements.continue_btn().click()                //continue bbutton
    cy.wait('@answerapi')
     

    selector.elements.staying_month_textbox().clear().type('Lahore')     //click on text box
    selector.genericwait()
    selector.elements.city_selection().click()         //city selection from dropdown
    selector.genericwait()
    selector.elements.continue_btn().click()     //continue bbutton
    cy.wait('@>20weatherapi')
    selector.elements.continue_btn().click()     //continue button
    cy.wait('@mp4videoapi')

    selector.elements.skipto_results_btn().click()      // skip to results button
    cy.wait('@resultpage')
    cy.wait('@resultonproductpage')

    
    selector.producttype.dayserum().should('exist')           //verifing the product type
    selector.producttype.nightserum().should('exist')          //verifing the product type
    selector.producttype.moisturiser().should('exist')         //verifing the product type
    //selector.producttype.nightcream().should('exist')           //verifing the product type
    selector.genericwait()


    selector.elements.add_day_night_set().click()               //add product set button
    cy.wait('@addsetbtnapi')


    selector.elements.product_btn().click()                    //product button
    cy.wait('@resultonproductpage')
    
     
    selector.productname.daydropoflight().should('exist')        //verifing the day serum
    selector.productname.nightdropofsoftness().should('exist')       //verifing the night serum
    selector.productname.mm().should('exist')                     //verifing the day cream
    selector.productname.milkyway().should('exist')              //verifing the night cream
    cy.wait(3000)

}


testcase71()
{
    selector.assessment_apis()              //inculuded assessment/result/answer's api's 
    selector.elements.gender_male().click() //gender selection
    cy.wait('@answerapi')
    cy.wait('@agequestionapi')
     

    selector.elementsquestions.age()
    selector.elements.age_any().click()   //age selection
    cy.wait('@answerapi')
    cy.wait('@cheeksapi')

     
    selector.elementsquestions.cheeksinthemorning()
    selector.elements.cheeks_morning_veryoily().click()  //cheeks selection
    cy.wait('@answerapi')
    cy.wait('@tzoneapi')

     
    selector.elementsquestions.tzone()
    selector.elements.tzone_oily().click()   //tzone selection
    cy.wait('@answerapi')
    cy.wait('@skinconcernapi')

     
    selector.elementsquestions.top2skinconcerns()
    selector.elements.top2_skin_concerns_blackWhitehead().click()          //skin concerns 1 selection
    selector.elements.continue_btn().click()           //continue button
    cy.wait('@answerapi')
    cy.wait('@skinshadeapi')


    selector.elementsquestions.skinshade()
    selector.elements.skishade_2nd().click()     //skin shade selection
    cy.wait('@answerapi')
    cy.wait('@reactionapi')
     

    selector.elementsquestions.skinreaction()
    selector.elements.skinReactions_no().click()   //skin reaction selection
    cy.wait('@answerapi')
    cy.wait('@stressapi')
    

    selector.elementsquestions.stress()
    selector.elements.little_stress().click()    // stress selection
    cy.wait('@answerapi')
    cy.wait('@sleepapi')
     

    selector.elementsquestions.sleep()
    selector.elements.sleep_5to6().click()   //sleep selection
    cy.wait('@answerapi')
    cy.wait('@waterapi')
     

    selector.elementsquestions.waterconsumption()
    selector.elements.water_consumption().click()    //water consumption selection
    cy.wait('@answerapi')
    cy.wait('@spenddayapi')
     

    selector.elementsquestions.dayspend()
    selector.elements.indoors_wtoutAC().click()     //environment selection
    cy.wait('@answerapi')
    cy.wait('@lifestyleapi')
     

    selector.elementsquestions.lifestylepart()
    selector.elements.lifestyle_regular_workout().click()   //lifestyle selection
    selector.elements.continue_btn().click()     //continue button
    cy.wait('@answerapi')
    cy.wait('@makeupapi')
     

    selector.elementsquestions.makeup()
    selector.elements.wear_makeup_occasionally().click()    //makeup wearing selection
    cy.wait('@answerapi')
    cy.wait('@smokeapi')
     

    selector.elementsquestions.smoke()
    selector.elements.smoke_occasionally().click()      //smoking selection
    cy.wait('@answerapi')
    cy.wait('@productpreferenceapi')
      

    selector.elementsquestions.productpreference()
    selector.elements.product_preference_none().click()      //product preference selection
    cy.wait('@answerapi')
     

    selector.elements.staying_month_textbox().clear().type('Lahore')     //click on text box
    selector.genericwait()
    selector.elements.city_selection().click()         //city selection from dropdown
    selector.genericwait()
    selector.elements.continue_btn().click()     //continue bbutton
    cy.wait('@>20weatherapi')
    selector.elements.continue_btn().click()     //continue button
    cy.wait('@mp4videoapi')

    selector.elements.skipto_results_btn().click()      // skip to results button
    cy.wait('@resultpage')
    cy.wait('@resultonproductpage')

    
    selector.producttype.dayserum().should('exist')           //verifing the product type
    selector.producttype.nightserum().should('exist')          //verifing the product type
    selector.producttype.moisturiser().should('exist')         //verifing the product type
    //selector.producttype.nightcream().should('exist')           //verifing the product type
    selector.genericwait()


    selector.elements.add_day_night_set().click()               //add product set button
    cy.wait('@addsetbtnapi')

    selector.elements.product_btn().click()                    //product button
    cy.wait('@resultonproductpage')
    
     
    selector.productname.daydropoflight().should('exist')        //verifing the day serum
    selector.productname.nightdropofperfection().should('exist')       //verifing the night serum
    selector.productname.mm().should('exist')                     //verifing the day cream
    selector.productname.milkyway().should('exist')              //verifing the night cream
    cy.wait(3000)

}


testcase72()
{
    selector.assessment_apis()              //inculuded assessment/result/answer's api's 
    selector.elements.gender_male().click() //gender selection
    cy.wait('@answerapi')
    cy.wait('@agequestionapi')
     

    selector.elementsquestions.age()
    selector.elements.age_any().click()   //age selection
    cy.wait('@answerapi')
    cy.wait('@cheeksapi')

     
    selector.elementsquestions.cheeksinthemorning()
    selector.elements.cheeks_morning_veryoily().click()  //cheeks selection
    cy.wait('@answerapi')
    cy.wait('@tzoneapi')

     
    selector.elementsquestions.tzone()
    selector.elements.tzone_veryoily().click()   //tzone selection
    cy.wait('@answerapi')
    cy.wait('@skinconcernapi')

     
    selector.elementsquestions.top2skinconcerns()
    selector.elements.top2_skin_concerns_blackWhitehead().click()          //skin concerns 1 selection
    selector.elements.continue_btn().click()           //continue button
    cy.wait('@answerapi')
    cy.wait('@skinshadeapi')
     

    selector.elementsquestions.skinshade()
    selector.elements.skishade_2nd().click()     //skin shade selection
    cy.wait('@answerapi')
    cy.wait('@reactionapi')
     

    selector.elementsquestions.skinreaction()
    selector.elements.skinReactions_yes().click()   //skin reaction selection
    cy.wait('@answerapi')
    cy.wait('@ingredientapi')
    

    selector.elementsquestions.ingredients()
    selector.elements.ingredients_salicylicacid().click()    //ingredients selection
    selector.elements.continue_btn().click()           //continue button
    cy.wait('@answerapi')
    cy.wait('@stressapi')
    

    selector.elementsquestions.stress()
    selector.elements.little_stress().click()    // stress selection
    cy.wait('@answerapi')
    cy.wait('@sleepapi')
     

    selector.elementsquestions.sleep()
    selector.elements.sleep_5to6().click()   //sleep selection
    cy.wait('@answerapi')
    cy.wait('@waterapi')
     

    selector.elementsquestions.waterconsumption()
    selector.elements.water_consumption().click()    //water consumption selection
    cy.wait('@answerapi')
    cy.wait('@spenddayapi')
     

    selector.elementsquestions.dayspend()
    selector.elements.indoors_wtoutAC().click()     //environment selection
    cy.wait('@answerapi')
    cy.wait('@lifestyleapi')
     

    selector.elementsquestions.lifestylepart()
    selector.elements.lifestyle_regular_workout().click()   //lifestyle selection
    selector.elements.continue_btn().click()     //continue button
    cy.wait('@answerapi')
    cy.wait('@makeupapi')
     

    selector.elementsquestions.makeup()
    selector.elements.wear_makeup_occasionally().click()    //makeup wearing selection
    cy.wait('@answerapi')
    cy.wait('@smokeapi')
     

    selector.elementsquestions.smoke()
    selector.elements.smoke_occasionally().click()      //smoking selection
    cy.wait('@answerapi')
    cy.wait('@productpreferenceapi')
      

    selector.elementsquestions.productpreference()
    selector.elements.product_preference_none().click()      //product preference selection
    cy.wait('@answerapi')
     

    selector.elements.staying_month_textbox().clear().type('Lahore')     //click on text box
    selector.genericwait()
    selector.elements.city_selection().click()         //city selection from dropdown
    selector.genericwait()
    selector.elements.continue_btn().click()     //continue bbutton
    cy.wait('@>20weatherapi')
    selector.elements.continue_btn().click()     //continue button
    cy.wait('@mp4videoapi')

    selector.elements.skipto_results_btn().click()      // skip to results button
    cy.wait('@resultpage')
    cy.wait('@resultonproductpage')

    
    selector.producttype.dayserum().should('exist')           //verifing the product type
    selector.producttype.nightserum().should('exist')          //verifing the product type
    selector.producttype.moisturiser().should('exist')         //verifing the product type
    //selector.producttype.nightcream().should('exist')           //verifing the product type
    selector.genericwait()


    selector.elements.add_day_night_set().click()               //add product set button
    cy.wait('@addsetbtnapi')


    selector.elements.product_btn().click()                    //product button
    cy.wait('@resultonproductpage')
    
     
    selector.productname.daydropoflight().should('exist')        //verifing the day serum
    selector.productname.dropofyouth().should('exist')       //verifing the night serum
    selector.productname.mm().should('exist')                     //verifing the day cream
    selector.productname.milkyway().should('exist')              //verifing the night cream
    cy.wait(3000)

}


testcase73()
{
    selector.assessment_apis()              //inculuded assessment/result/answer's api's 
    selector.elements.gender_male().click() //gender selection
    cy.wait('@answerapi')
    cy.wait('@agequestionapi')
     

    selector.elementsquestions.age()
    selector.elements.age_any().click()   //age selection
    cy.wait('@answerapi')
    cy.wait('@cheeksapi')

     
    selector.elementsquestions.cheeksinthemorning()
    selector.elements.cheeks_morning_veryoily().click()  //cheeks selection
    cy.wait('@answerapi')
    cy.wait('@tzoneapi')

     
    selector.elementsquestions.tzone()
    selector.elements.tzone_veryoily().click()   //tzone selection
    cy.wait('@answerapi')
    cy.wait('@skinconcernapi')

     
    selector.elementsquestions.top2skinconcerns()
    selector.elements.top2_skin_concerns_blackWhitehead().click()          //skin concerns 1 selection
    selector.elements.continue_btn().click()           //continue button
    cy.wait('@answerapi')
    cy.wait('@skinshadeapi')
     

    selector.elementsquestions.skinshade()
    selector.elements.skishade_2nd().click()     //skin shade selection
    cy.wait('@answerapi')
    cy.wait('@reactionapi')
     

    selector.elementsquestions.skinreaction()
    selector.elements.skinReactions_yes().click()   //skin reaction selection
    cy.wait('@answerapi')
    cy.wait('@ingredientapi')
    

    selector.elementsquestions.ingredients()
    selector.elements.ingredients_salicylicacid().click()    //ingredients selection
    selector.elements.continue_btn().click()           //continue button
    cy.wait('@answerapi')
    cy.wait('@stressapi')
    

    selector.elementsquestions.stress()
    selector.elements.little_stress().click()    // stress selection
    cy.wait('@answerapi')
    cy.wait('@sleepapi')
     

    selector.elementsquestions.sleep()
    selector.elements.sleep_5to6().click()   //sleep selection
    cy.wait('@answerapi')
    cy.wait('@waterapi')
     

    selector.elementsquestions.waterconsumption()
    selector.elements.water_consumption().click()    //water consumption selection
    cy.wait('@answerapi')
    cy.wait('@spenddayapi')
     

    selector.elementsquestions.dayspend()
    selector.elements.indoors_wtoutAC().click()     //environment selection
    cy.wait('@answerapi')
    cy.wait('@lifestyleapi')
     

    selector.elementsquestions.lifestylepart()
    selector.elements.lifestyle_regular_workout().click()   //lifestyle selection
    selector.elements.continue_btn().click()     //continue button
    cy.wait('@answerapi')
    cy.wait('@makeupapi')
     

    selector.elementsquestions.makeup()
    selector.elements.wear_makeup_occasionally().click()    //makeup wearing selection
    cy.wait('@answerapi')
    cy.wait('@smokeapi')
     

    selector.elementsquestions.smoke()
    selector.elements.smoke_occasionally().click()      //smoking selection
    cy.wait('@answerapi')
    cy.wait('@productpreferenceapi')
      

    selector.elementsquestions.productpreference()
    selector.elements.product_preference_pregnancysafe().click()      //product preference selection
    selector.elements.continue_btn().click()     //continue bbutton
    cy.wait('@answerapi')
     

    selector.elements.staying_month_textbox().clear().type('Lahore')     //click on text box
    selector.genericwait()
    selector.elements.city_selection().click()         //city selection from dropdown
    selector.genericwait()
    selector.elements.continue_btn().click()     //continue bbutton
    cy.wait('@>20weatherapi')
    selector.elements.continue_btn().click()     //continue button
    cy.wait('@mp4videoapi')

    selector.elements.skipto_results_btn().click()      // skip to results button
    cy.wait('@resultpage')
    cy.wait('@resultonproductpage')

    
    selector.producttype.dayserum().should('exist')           //verifing the product type
    selector.producttype.nightserum().should('exist')          //verifing the product type
    selector.producttype.moisturiser().should('exist')         //verifing the product type
    //selector.producttype.nightcream().should('exist')           //verifing the product type
    selector.genericwait()


    selector.elements.add_day_night_set().click()               //add product set button
    cy.wait('@addsetbtnapi')


    selector.elements.product_btn().click()                    //product button
    cy.wait('@resultonproductpage')
    
     
    selector.productname.daydropoflight().should('exist')        //verifing the day serum
    selector.productname.nightdropofsoftness().should('exist')       //verifing the night serum
    selector.productname.mm().should('exist')                     //verifing the day cream
    selector.productname.milkyway().should('exist')              //verifing the night cream
    //cy.wait(3000)

}

testcase74()
{
  cy.get("body > div:nth-child(1) > div:nth-child(1) > div:nth-child(1) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > a:nth-child(1)").click()
  selector.genericwait()
  cy.xpath("(//button[@type='button'])[5]").click()
  selector.genericwait()
  cy.xpath("//body/div[@id='__next']/div/div/div/div/div/div/div/div/div/button[1]").click()
  selector.genericwait()
  cy.contains("One-time purchase").click()
  selector.genericwait()
  selector.elements.continue_btn().click()     //continue button
  selector.genericwait()
  
  //cy.frameLoaded()

  cy.get("#name").click().type('usman')
  cy.get("#email").click().type('abcxyzz@gmail.com')
  cy.contains("Submit").click()
  selector.genericwait()
  //cy.get("body > div:nth-child(1) > div:nth-child(1) > div:nth-child(3) > div:nth-child(1) > div:nth-child(1) > div:nth-child(4) > div:nth-child(5) > div:nth-child(1) > div:nth-child(2) > form:nth-child(1) > div:nth-child(1) > div:nth-child(1) > div:nth-child(1) > div:nth-child(1) > div:nth-child(1) > div:nth-child(1)").click()
  //cy.contains("Singapore").click()
  cy.get("input[autocomplete='new-firstname']").click().clear().type('Bob')
  cy.get("input[autocomplete='new-lastName']").click().clear().type('Tom')
  //cy.get("#address-auto").click().clear().type('abc')
  cy.get("input[autocomplete='new-apartment']").click().clear().type('abc')
  cy.get("input[autocomplete='new-city']").click().clear().type('Boon Lay')
  cy.get("input[autocomplete='new-zipCode']").click().clear().type('54000')
  cy.xpath("//input[@type='number']").click().clear().type('3205656453')

  /*cy.intercept({method: 'POST', url: 'https://dev-api.lovefromyours.com/api/v1/orders/prebuilt-checkout',}).as('prebuiltapi')
  .then((interception) => {
    console.log("interception", interception)})*/

  cy.contains('Proceed to pay').click()  //proceed to Pay button
  cy.wait(5000)
  cy.on('uncaught:exception', (err) => {
    // Allow stripe error: "paymentRequest Element didn't mount normally"
    if (err.message.includes('paymentRequest')) {
      return false;
    }
  });
  //cy.frameLoaded()
  
  

 /* cy.wait('@prebuiltapi').then((interception) => {
  cy.log(JSON.stringify(interception))
  console.log("interception", interception)})*/
  



  /*
  cy.request("POST", "https://dev-api.lovefromyours.com/api/v1/orders/prebuilt-checkout")
  .then((response) => {
    console.log(response)})
    expect(response.status).to.eq(200)});
    expect(response.body).to.have.property("url");
    cy.visit(response.body.url);
    cy.url().should("contains", "https://checkout.lovefromyours.com/pay/")});*/

    

  cy.wait(7000)
//   cy.get("#billingName").click().type('Bob')
//   cy.get("#cardExpiry").click().type('0129')
//   cy.get("#cardCvc").click().type('012')
//   cy.get("#cardCvc").click().type('012')
//   cy.contains("Pay").click()
//   cy.wait(10000)



}
}
    
    export default Assessment_Methods