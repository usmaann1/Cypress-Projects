/// <reference types = "Cypress"  />
import "cypress-localstorage-commands"
import CSS_Selecters from './Selecters'
const selector = new CSS_Selecters()



class Product_Methods{

testcase1()
{   
    selector.assessment_apis()              //inculuded assessment/result/answer's api's
    selector.elements.product_btn().should('be.visible').click()         //product button
    cy.wait('@productbtnapi')

    selector.elements.essentials_btn().eq(2).click({force:true})             //essesntials btn
    //cy.contains(/^(Day Cream&Night Creamm)/,)
    selector.genericwait()
}



testcase2()
{   
    selector.assessment_apis()              //inculuded assessment/result/answer's api's
    selector.elements.product_btn().should('be.visible').click()         //product button

    selector.elements.personalised_singles_btn().eq(1).click({force:true})       //personalised singles btn
}



testcase3()
{   
    selector.assessment_apis()                //inculuded assessment/result/answer's api's
    selector.elements.product_btn().should('be.visible').click()         //product button

    selector.elements.personalised_routine_btn().eq(0).click({force:true})             //personalised routine btn
}



testcase4()
{   
    selector.assessment_apis()                //inculuded assessment/result/answer's api's
    cy.visit('/products')
    cy.wait('@productbtnapi')
    selector.elements.personalised_routine_btn().eq(0).click({force:true})             //personalised routine btn
    selector.genericwait()
    selector.elements.startassessment_ps_btn().eq(0).click()
    selector.genericwait()
    cy.url('https://dev-web.lovefromyours.com/assessment').should('exist')   
}



testcase5()
{   
    selector.assessment_apis()                //inculuded assessment/result/answer's api's
    selector.elements.product_btn().should('be.visible').click()         //product button

    selector.elements.personalised_routine_btn().eq(0).click({force:true})              //personalised routine btn
    cy.get(".molecules-authorization-buttons").find('.molecules-authorization-buttons__link')
    .eq(0).click()
    selector.genericwait()
    cy.url("https://dev-web.lovefromyours.com/assessment-sign-in").should('exist') 
    
}



testcase6()
{   
    selector.assessment_apis()                //inculuded assessment/result/answer's api's
    cy.visit('/products')
    cy.wait('@productbtnapi')

    selector.elements.personalised_singles_btn().eq(1).click({force:true})             //personalised routine btn
    selector.genericwait()
    selector.elements.startassessment_ps_btn().eq(0).click()
    selector.genericwait()
    cy.url('https://dev-web.lovefromyours.com/assessment').should('exist')  
}



testcase7()
{   
    selector.assessment_apis()                //inculuded assessment/result/answer's api's
    selector.elements.product_btn().should('be.visible').click()         //product button
    cy.wait('@productbtnapi')

    selector.elements.personalised_singles_btn().eq(1).click({force:true})              //personalised singles btn
    cy.get(".molecules-authorization-buttons").find('.molecules-authorization-buttons__link')
    .eq(1).click()
    selector.genericwait()
    cy.url("https://dev-web.lovefromyours.com/assessment-sign-in").should('exist')   
}



testcase8()
{   
    selector.assessment_apis()                //inculuded assessment/result/answer's api's
    selector.elements.product_btn().should('be.visible').click()         //product button
    cy.wait('@productbtnapi')

    selector.elements.personalised_singles_btn().eq(1).click({force:true})
    cy.contains('Day Cream').should('exist')
    cy.contains('Face Serum').should('exist')
    cy.contains('Night Cream').should('exist')    
}



testcase9()
{   
    selector.assessment_apis()         //inculuded assessment/result/answer's api's
    selector.elements.product_btn().should('be.visible').click()         //product button

    selector.elements.personalised_singles_btn().eq(1).click({force:true})
    cy.get(".organisms-products-list").find('.atoms-button atoms-button_primary').should('not.exist')    
}



testcase10()
{   
    selector.assessment_apis()                //inculuded assessment/result/answer's api's
    selector.elements.product_btn().should('be.visible').click()         //product button

    selector.elements.personalised_singles_btn().eq(1).click({force:true})
    cy.contains('Day Cream').should('exist')
    cy.contains('Face Serum').should('exist')
    cy.contains('Night Cream').should('exist') 
}



testcase11()
{   
    selector.assessment_apis()                //inculuded assessment/result/answer's api's
    selector.elements.product_btn().should('be.visible').click()         //product button
    //cy.wait('@productbtnapi')

    selector.elements.personalised_singles_btn().eq(1).click({force:true})
    cy.get(".molecules-product-block__description-product-wrapper > p").eq(0).should('have.text', "Personalised to work for your skin and lifestyle, it’s filled with the goodness of Swiss active ingredients to hydrate, lock in moisture and shield your skin from damage. A moisturiser you can rely on!")  
    cy.get(".molecules-product-block__description-product-wrapper > p").eq(1).should('have.text', 'A nourishing cream filled with Swiss active ingredients, personalised to repair damage from your lifestyle habits and environmental factors like UV and pollution.')   
    cy.get(".molecules-product-block__description-product-wrapper > p").eq(2).should('have.text', 'A lightweight formula packed with Swiss active ingredients, personalised to target your specific skin concerns: acne, blackheads, pigmentation, wrinkles – you name it! ')
}



testcase13()
{   
    selector.assessment_apis()                //inculuded assessment/result/answer's api's
    selector.elements.product_btn().should('be.visible').click()         //product button

    selector.elements.personalised_singles_btn().eq(1).click({force:true})
    selector.genericwait()

    cy.get(".organisms-products-list").find('div.molecules-product-block')
    .eq(0).and('contain', 'Day Cream').contains('USD 20')
    cy.get(".organisms-products-list").find('div.molecules-product-block')
    .eq(1).and('contain', 'Night Cream').contains('USD 25')
    cy.get(".organisms-products-list").find('div.molecules-product-block')
    .eq(2).and('contain', 'Face Serum').contains('USD 25')   
}



testcase18()
{   
    selector.assessment_apis()                //inculuded assessment/result/answer's api's
    selector.elements.product_btn().should('be.visible').click()         //product button

    selector.elements.personalised_singles_btn().eq(1).click({force:true})
    selector.genericwait()

    cy.get(".organisms-products-list").find('div.molecules-product-block')
    .eq(0).and('contain', 'Day Cream').contains('30 ml')
    cy.get(".organisms-products-list").find('div.molecules-product-block')
    .eq(1).and('contain', 'Night Cream').contains('30 ml')
    cy.get(".organisms-products-list").find('div.molecules-product-block')
    .eq(2).and('contain', 'Face Serum').contains('25 ml')
}



testcase23()
{   
    selector.assessment_apis()                //inculuded assessment/result/answer's api's
    selector.elements.product_btn().should('be.visible').click()         //product button

    selector.elements.personalised_singles_btn().eq(1).click({ force: true })
    cy.get(".molecules-product-block__price-product-wrapper").contains('ml')
    
}



testcase24()
{   
    selector.assessment_apis()                //inculuded assessment/result/answer's api's
    cy.visit('/products')
    cy.wait('@productbtnapi')

    selector.elements.personalised_singles_btn().eq(1).click({force:true})
    selector.genericwait()
    cy.get(".molecules-authorization-buttons").find('a.link').should('not.exist')   
}



testcase25()    
{   
    selector.assessment_apis()                //inculuded assessment/result/answer's api's
    selector.elements.product_btn().should('be.visible').click()         //product button
    selector.elements.personalised_singles_btn().eq(1).click({force:true})
    selector.genericwait()
    cy.get(".molecules-authorization-buttons").find('a.molecules-authorization-buttons__link')
    .eq(1).click()
    cy.wait(3000)
    cy.url('https://dev-web.lovefromyours.com/sign-in').should('exist')     
}



testcase26()
{   
    selector.assessment_apis()                //inculuded assessment/result/answer's api's
    cy.visit('/products')                 
    cy.wait('@productbtnapi')
    selector.genericwait()

    cy.contains('Start Assessment').eq(0).click()
    selector.genericwait()
    cy.url('https://dev-web.lovefromyours.com/assessment').should('exist')      
}


testcase27()         //yaha se start krna hai
{   
    selector.assessment_apis()                //inculuded assessment/result/answer's api's
    selector.mockassessment()                // mock assessment

    selector.elements.add_day_night_set().click()               //add product set button
    cy.wait('@addsetbtnapi')

    cy.contains('Day Serum')
    cy.contains('Night Serum')
    cy.contains('Moisturizer')
}


testcase28()
{   
    
    selector.assessment_apis()                //inculuded assessment/result/answer's api's
    selector.mockassessment()                   //mock assessment
    Cypress.on('uncaught:exception', (err, runnable) => {
    // returning false here prevents Cypress from
    // failing the test
    return false})
    selector.elements.add_day_night_set().click()               //add product set button
    cy.wait('@addsetbtnapi')

    selector.elements.product_btn().click()                    //product button
    cy.wait('@resultonproductpage')
    
    cy.contains('Update assessment').click()
    selector.genericwait()

    cy.get('.customModal').should('be.visible')  // update assessment popup class
    cy.get(".react-responsive-modal-overlay").should('have.length', 1)          
}


testcase29()
{   
    selector.assessment_apis()                //inculuded assessment/result/answer's api's
    selector.mockassessment()                 //mock assessment 
    selector.genericwait()


    selector.elements.add_day_night_set().click()               //add product set button
    cy.wait('@addsetbtnapi')


    selector.elements.product_btn().click()                    //product button
    cy.wait('@resultonproductpage')
    
    selector.elements.personalised_singles_btn().eq(1).click({force:true})      //personlised singles btn

    selector.productname.daydropoflight().should('exist')            //verifing the day serum
    selector.productname.nightdropofsoftness().should('exist')       //verifing the night serum
    //selector.productname.crazyrichmoisturiser().should('exist')   //verifing the day cream
    //selector.productname.dndnights().should('exist')              //verifing the night cream
    cy.wait(2000) 
}


testcase32()
{   
    selector.assessment_apis()                //inculuded assessment/result/answer's api's
    selector.mockassessment()                                 //mock assessment
    selector.genericwait()

    selector.elements.add_day_night_set().click()            //add product set button
    cy.wait('@addsetbtnapi')
    cy.get(".m").should('have.text', '4')                  //cart button class


     selector.elements.product_btn().click()                    //product button
     cy.wait('@resultonproductpage')

     cy.get(".molecules-product-block__change-button").eq(1).click()
     selector.genericwait()
     cy.get(".m").should('have.text', '5')                //cart button class
     selector.genericwait()

     cy.get(".molecules-product-block__change-button").eq(0).click()
     selector.genericwait()
     cy.get(".m").should('have.text', '4')                //cart button class
}


testcase33()
{   
    selector.assessment_apis()                //inculuded assessment/result/answer's api's
    selector.mockassessment()   

    selector.genericwait()

    selector.elements.add_day_night_set().click()               //add product set button
    cy.wait('@addsetbtnapi')
    selector.genericwait()

    selector.elements.remove_set().click()               //remove product set button
    cy.wait('@removesetbtnapi')
    
    selector.elements.product_btn().click()                    //product button
    cy.wait('@resultonproductpage')

    cy.get('.organisms-products-list__wrapper').eq(1).find('.atoms-button_primary').should('have.length', 3)
    selector.genericwait()  
}


testcase38()
{   
    selector.assessment_apis()                //inculuded assessment/result/answer's api's
    selector.mockassessment()                 //mock assessment
    selector.genericwait()
    
    selector.elements.add_day_night_set().click()               //add product set button
    cy.wait('@addsetbtnapi')
    selector.genericwait()

    selector.elements.product_btn().click()                    //product button
    cy.wait('@resultonproductpage')

    cy.get(".organisms-products-list").find('div.molecules-product-block')  //1st product name verifying
    .eq(0).contains('Day Serum - Drop of Light')
    cy.get(".organisms-products-list").find('div.molecules-product-block')  //1st product price and unit verifying
    .eq(0).contains('USD 25 | 15 ml')
    cy.get("div.molecules-product-block__img-wrapper").find('img').eq(0)    //1st product img verifying
    .should('have.attr', 'src', 'https://yours-dev.s3-ap-southeast-1.amazonaws.com/Drop-of-Light.png')


    cy.get(".organisms-products-list").find('.molecules-product-block')     //2nd product name verifyong
    .eq(1).contains('Night Serum - Drop of Softness')
    cy.get(".organisms-products-list").find('div.molecules-product-block')  //2nd product price and unit verifying
    .eq(1).contains('USD 25 | 15 ml')
    cy.get("div.molecules-product-block__img-wrapper").find('img').eq(1)    //2nd product img verifying
    .should('have.attr', 'src', 'https://yours-dev.s3-ap-southeast-1.amazonaws.com/Drop-of-Softness.png')


    cy.get(".organisms-products-list").find('.molecules-product-block')    //3rd product name verifying
    .eq(2).contains(/Moisturiser - Crazy Rich Moisturiser|Moisturiser - Dew Date/)
    cy.get(".organisms-products-list").find('div.molecules-product-block')  //3rd product price and unit verifying
    .eq(2).contains('USD 20 | 30 ml')
    cy.get("div.molecules-product-block__img-wrapper").find('img').eq(2)    //3rd product img verifying
    .should('have.attr', 'src', 'https://yours-dev.s3-ap-southeast-1.amazonaws.com/Crazy-Rich.png')
}
    


testcase39()
{   
    selector.assessment_apis()                //inculuded assessment/result/answer's api's
    cy.visit('/products')
    cy.wait('@productbtnapi')

    cy.contains('Add to cart').eq(0).click()
    cy.wait('@addsetbtnapi')

    cy.get('body').then($body => {            //if cart doesn't open auto then this if condition open up the cart
    if ($body.find('Checkout') == false)
    {
        cy.get(".m").click({force:true})
    }
  })
    cy.waitUntil(() => cy.get('.css-18ps62j')).should('have.text', 'Checkout')
    cy.wait(5000)

    cy.contains('Checkout').click({force:true})
    cy.url('https://dev-web.lovefromyours.com/checkout').should('exist')
    selector.genericwait()
    
}


testcase40()
{   
    selector.assessment_apis()                //inculuded assessment/result/answer's api's
    cy.visit('/products')
    cy.wait('@productbtnapi')

    cy.get("#reviewsWidgetProductSnippets").should('have.length.greaterThan', 0)
    selector.genericwait()
    
}

}
    
    export default Product_Methods