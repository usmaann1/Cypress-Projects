/// <reference types = "Cypress"  />



class CSS_Selecters{

elements = {
    continue_btn: () => cy.contains('Continue'),
    //continue_btn: () => cy.xpath("//button[@id='#continue']"),
    gender_male: () => cy.xpath("//h4[@id='#male']"),
    age_any: () => cy.xpath("//div[@id='#20-30']"),


    cheeks_morning_verydry: () => cy.xpath("//div[@id='#very dry']"),
    cheeks_morning_dry: () => cy.xpath("//div[@id='#dry']"),
    cheeks_morning_normal: () => cy.xpath("//div[@id='#normal']"),
    cheeks_morning_oily: () => cy.xpath("//div[@id='#oily']"),
    cheeks_morning_veryoily: () => cy.xpath("//div[@id='#very oily']"),


    tzone_verydry: () => cy.xpath("//div[@id='#very dry']"),
    tzone_dry: () => cy.xpath("//div[@id='#dry']"),
    tzone_normal: () => cy.xpath("//div[@id='#normal']"),
    tzone_oily: () => cy.xpath("//div[@id='#oily']"),
    tzone_veryoily: () => cy.xpath("//div[@id='#very oily']"),

    top2_skin_concerns_wrinkles: () => cy.xpath("//h4[@id='#wrinkles / age spots']"),
    top2_skin_concerns_redness: () => cy.xpath("//h4[@id='#redness']"),
    top2_skin_concerns_acne: () => cy.xpath("//h4[@id='#acne']"),
    top2_skin_concerns_pigmentation: () => cy.xpath("//h4[@id='#pigmentation']"),
    top2_skin_concerns_blackWhitehead: () => cy.xpath("//h4[@id='#blackheads / whiteheads']"),


    levelofredness_mild: () => cy.xpath("//h4[@id='#mild']"),
    get_acne_always: () => cy.xpath("//h4[@id='#always']"),
    

    acnehardones: () => cy.xpath("//body/div[@id='__next']/div/div/div/div/div/div/div/div[1]/img[1]"),

    

    skishade_2nd: () => cy.xpath("//img[@id='5dd3eac16a24011295a1ae73']"),

    skinReactions_yes: () => cy.xpath("//h4[@id='#yes']"),
    skinReactions_no: () => cy.xpath("//h4[@id='#no']"),

    ingredients_retinol: () => cy.xpath("//h4[@id='#retinol']"),
    ingredients_salicylicacid: () => cy.xpath("//h4[@id='#salicylic acid']"),

    little_stress: () => cy.xpath("(//img[@alt='pill icon'])[2]"),
    sleep_5to6: () => cy.xpath("//div[@id='#5-6']"),
    water_consumption: () => cy.xpath("//div[@id='#6-7']"),
    indoors_wtoutAC: () => cy.xpath("//h4[@id='#indoors without ac']"),
    lifestyle_regular_workout: () => cy.xpath("(//img[@alt='pill icon'])[2]"),

    wear_makeup_occasionally: () => cy.xpath("//h4[@id='#occasionally']"),
    smoke_occasionally: () => cy.xpath("//h4[@id='#occasionally']"),

    product_preference_vegan: () => cy.xpath("//h4[@id='#vegan']"),
    product_preference_pregnancysafe: () => cy.xpath("//h4[@id='#pregnancy safe']"),
    product_preference_none: () => cy.xpath("//h4[@id='#none']"),
    
    staying_month_textbox: () => cy.get("#city-autocomplete"),
    city_selection: () => cy.get("div[class='molecules-address-listing'] div:nth-child(1) div:nth-child(2) span:nth-child(1)"),
    skipto_results_btn: () => cy.xpath("//button[@id='#skip to results']"),
    start_new_assessment: () => cy.xpath("//p[@id='#Start a new assessment']"),
    add_day_night_set: () => cy.xpath("//button[@id='#add set']"),
    remove_set: () => cy.xpath("//button[@id='#remove set']"),
    add_cart_btn: () => cy.xpath("//div[@id='__next']//div//div//div//div//div//div//div//div//div//img[@id='#cart']"),
    product_btn: () => cy.xpath("//a[@id='#products']"),
    essentials_btn: () => cy.get('.atoms-submenu__list-item'),
    personalised_routine_btn: () => cy.get(".atoms-submenu__list-item"),
    personalised_singles_btn: () => cy.get(".atoms-submenu__list-item"),
    startassessment_ps_btn: () => cy.contains("Start Assessment")
}

elementsquestions  = {
age: () => cy.contains("What's your age?").should('exist'),
cheeksinthemorning: () => cy.contains("How would you best describe your cheeks in the morning?").should('exist'),
tzone: () => cy.contains("How would you best describe your T-Zone in the morning?").should('exist'),
top2skinconcerns: () => cy.contains("What are your top 2 skin concerns?").should('exist'),
levelofredness: () => cy.contains("What is the level of redness?").should('exist'),
skinshade: () => cy.contains("Which shade card does your skin tone fall in?").should('exist'),
skinreaction: () => cy.contains("Ever had any adverse reactions to a skincare ingredient?").should('exist'),
ingredients: () => cy.contains("Which ingredient caused it?").should('exist'),
stress: () => cy.contains("How much stress do you experience on a regular basis?").should('exist'),
sleep: () => cy.contains("How much sleep do you regularly get?").should('exist'),
waterconsumption: () => cy.contains("How much water do you consume daily?").should('exist'),
dayspend: () => cy.contains("Where do you spend most of your day?").should('exist'),
lifestylepart: () => cy.contains("Which of these are a part of your lifestyle?").should('exist'),
makeup: () => cy.contains("How often do you wear make-up?").should('exist'),
smoke: () => cy.contains("Do you smoke?").should('exist'),
productpreference: () => cy.contains("Any product preference you'd like us to consider?").should('exist'),
staymonth: () => cy.contains("Where would you be staying for the next 2 months?").should('exist'),
getacne: () => cy.contains("How often do you get acne?"),
describeacne: () => cy.contains("How would you best describe your acne?")
}

producttype = {
    dayserum: () => cy.contains("Bob's Day Serum"),
    nightserum: () => cy.contains("Bob's Night Serum"),
    moisturiser: () => cy.contains("Bob's Moisturiser"),
    nightcream: () => cy.contains("Bob's Night Cream")
}

productname = {

    daydropoflight: () => cy.contains("Day Serum - Drop of Light"),
    day_dropofbalance: () => cy.contains("Day Serum - Drop of Balance"),
    nightdropoflight: () => cy.contains("Night Serum - Drop of Light"),
    daydropofsoftness: () => cy.contains("Day Serum - Drop of Softness"),
    daydropofperfection: () => cy.contains("Day Serum - Drop of Perfection"),
    nightdropofperfection: () => cy.contains("Night Serum - Drop of Perfection"),
    nightdropofsoftness: () => cy.contains("Night Serum - Drop of Softness"),
    dropofyouth: () => cy.contains("Night Serum - Drop of Youth"),
    night_dropofbalance: () => cy.contains("Night Serum - Drop of Balance"),
    crazyrichmoisturiser: () => cy.contains("Moisturiser - Crazy Rich Moisturiser"),
    mm: () => cy.contains("Moisturiser - Matte & Moist"),
    dewdatemoisturiser: () => cy.contains("Moisturiser - Dew Date"),
    dndnights: () => cy.contains("Night Cream - DND Nights"),
    milkyway: () => cy.contains("Night Cream - Milky Way")
    

    
}

genericwait(){
  cy.wait(3000)
}

/*
home_login_apis(){
cy.intercept({method: "GET", url: Cypress.env("devapi")+'/api/v1/banner',}).as('homebannerapi')
cy.intercept({method: "POST", url: Cypress.env("devapi")+'/api/v1/auth/login/guest',}).as('guestapi')
cy.intercept({method: "GET", url: Cypress.env("devapi")+'/api/v1/skin-assessment/assessment/published',}).as('publishapi')
cy.intercept({method: "GET", url: Cypress.env("devapi")+'/api/v1/skin-assessment/question/5dd3ca802e035d1060c98c36',}).as('genderquestionapi')
}*/

assessment_apis(){

cy.intercept({method: "GET", url: Cypress.env("devapi")+'/api/v1/banner',}).as('homebannerapi')
cy.intercept({method: "POST", url: Cypress.env("devapi")+'/api/v1/auth/login/guest',}).as('guestapi')
cy.intercept({method: "GET", url: Cypress.env("devapi")+'/api/v1/skin-assessment/assessment/published',}).as('publishapi')
cy.intercept({method: "GET", url: Cypress.env("devapi")+'/api/v1/skin-assessment/question/5dd3ca802e035d1060c98c36',}).as('genderquestionapi')

cy.intercept({method: 'POST', url: Cypress.env("devapi")+'/api/v1/skin-assessment/assessment/answer/',}).as('answerapi')
cy.intercept({method: "GET", url: Cypress.env("devapi")+'/api/v1/skin-assessment/assessment/weather?lat=31.5203696&lon=74.35874729999999&location=Lahore,%20Punjab,%20Pakistan',}).as('>20weatherapi')
cy.intercept({method: "GET", url: Cypress.env("devapi")+'/api/v1/skin-assessment/assessment/weather?lat=47.3768866&lon=8.541694&location=Z%C3%BCrich,%20Switzerland',}).as('<20weatherapi')
cy.intercept({method: 'GET', url: 'https://cdn.lovefromyours.com/static/video/camy_scan.mp4',}).as('mp4videoapi')
cy.intercept({method: 'GET', url: Cypress.env("devapi")+'/api/v1/results/latest',}).as('resultpage')
cy.intercept({method: 'GET', url: Cypress.env("devapi")+'/api/v1/results/generated',}).as('resultonproductpage')
cy.intercept({method: 'GET', url: Cypress.env("devapi")+'/api/v1/skin-assessment/question/5dd3d23a6a24011295a1ae35',}).as('agequestionapi')
cy.intercept({method: 'GET', url: Cypress.env("devapi")+'/api/v1/skin-assessment/question/5dd3daa16a24011295a1ae40',}).as('cheeksapi')
cy.intercept({method: 'GET', url: Cypress.env("devapi")+'/api/v1/skin-assessment/question/5dd3e2e56a24011295a1ae4b',}).as('tzoneapi')
cy.intercept({method: 'GET', url: Cypress.env("devapi")+'/api/v1/skin-assessment/question/5dd3e3e06a24011295a1ae56',}).as('skinconcernapi')
cy.intercept({method: 'GET', url: Cypress.env("devapi")+'/api/v1/skin-assessment/question/5dd3e4e66a24011295a1ae5c',}).as('getacneapi')
cy.intercept({method: 'GET', url: Cypress.env("devapi")+'/api/v1/skin-assessment/question/5dd3e5716a24011295a1ae60',}).as('describeacneapi')
cy.intercept({method: 'GET', url: Cypress.env("devapi")+'/api/v1/skin-assessment/question/5dd3e6986a24011295a1ae65',}).as('levelofrednessapi')
cy.intercept({method: 'GET', url: Cypress.env("devapi")+'/api/v1/skin-assessment/question/5dd3e8ba6a24011295a1ae70',}).as('skinshadeapi')
cy.intercept({method: 'GET', url: Cypress.env("devapi")+'/api/v1/skin-assessment/question/5dd3ed206a24011295a1ae7f',}).as('reactionapi')
cy.intercept({method: 'GET', url: Cypress.env("devapi")+'/api/v1/skin-assessment/question/5dd3ee906a24011295a1ae82',}).as('ingredientapi')
cy.intercept({method: 'GET', url: Cypress.env("devapi")+'/api/v1/skin-assessment/question/5dd635b3693d032e4d156bec',}).as('stressapi')
cy.intercept({method: 'GET', url: Cypress.env("devapi")+'/api/v1/skin-assessment/question/5dd65088cc1e553d5a377c82',}).as('sleepapi')
cy.intercept({method: 'GET', url: Cypress.env("devapi")+'/api/v1/skin-assessment/question/5dd6523fcc1e553d5a377c9e',}).as('waterapi')
cy.intercept({method: 'GET', url: Cypress.env("devapi")+'/api/v1/skin-assessment/question/5dd65781cc1e553d5a377d27',}).as('spenddayapi')
cy.intercept({method: 'GET', url: Cypress.env("devapi")+'/api/v1/skin-assessment/question/5dd658ddcc1e553d5a377d2e',}).as('lifestyleapi')
cy.intercept({method: 'GET', url: Cypress.env("devapi")+'/api/v1/skin-assessment/question/5dd664adcc1e553d5a377dc3',}).as('makeupapi')
cy.intercept({method: 'GET', url: Cypress.env("devapi")+'/api/v1/skin-assessment/question/5dd66642cc1e553d5a377dd8',}).as('smokeapi')
cy.intercept({method: 'GET', url: Cypress.env("devapi")+'/api/v1/skin-assessment/question/606d5caeac5406165ad1d031',}).as('productpreferenceapi')
cy.intercept({method: 'POST', url: Cypress.env("devapi")+'/api/v1/orders/cart/add',}).as('addsetbtnapi')
cy.intercept({method: 'PATCH', url: Cypress.env("devapi")+'/api/v1/orders/cart/update',}).as('removesetbtnapi')
cy.intercept({method: 'GET', url: 'https://dev-api.lovefromyours.com/api/v1/catalogue/product/search?type=active&country=PK',}).as('productbtnapi')
}

mockassessment()
{
    this.elements.gender_male().click({force:true}) //gender selection
    cy.wait('@answerapi')
    cy.wait('@agequestionapi')
     

     this.elementsquestions.age()
     this.elements.age_any().click()   //age selection
    cy.wait('@answerapi')
    cy.wait('@cheeksapi')

     
     this.elementsquestions.cheeksinthemorning()
     this.elements.cheeks_morning_verydry().click()  //cheeks selection
    cy.wait('@answerapi')
    cy.wait('@tzoneapi')

     
     this.elementsquestions.tzone()
     this.elements.tzone_verydry().click()   //tzone selection
    cy.wait('@answerapi')
    cy.wait('@skinconcernapi')

     
     this.elementsquestions.top2skinconcerns()
     this.elements.top2_skin_concerns_wrinkles().click()  //skin concerns selection
     
     this.elements.continue_btn().click()    //continue button
    cy.wait('@answerapi')
    cy.wait('@skinshadeapi')
     

     this.elementsquestions.skinshade()
     this.elements.skishade_2nd().click()     //skin shade selection
    cy.wait('@answerapi')
    cy.wait('@reactionapi')
     

     this.elementsquestions.skinreaction()
     this.elements.skinReactions_yes().click()   //skin reaction selection
    cy.wait('@answerapi')
    cy.wait('@ingredientapi')
     

     this.elementsquestions.ingredients()
     this.elements.ingredients_retinol().click()    //ingredients selection
     this.elements.continue_btn().click()    //continue button
    cy.wait('@answerapi')
    cy.wait('@stressapi')
     
    
     this.elementsquestions.stress()
     this.elements.little_stress().click()    // stress selection
    cy.wait('@answerapi')
    cy.wait('@sleepapi')
     

     this.elementsquestions.sleep()
     this.elements.sleep_5to6().click()   //sleep selection
    cy.wait('@answerapi')
    cy.wait('@waterapi')
     

     this.elementsquestions.waterconsumption()
     this.elements.water_consumption().click()    //water consumption selection
    cy.wait('@answerapi')
    cy.wait('@spenddayapi')
     

     this.elementsquestions.dayspend()
     this.elements.indoors_wtoutAC().click()     //environment selection
    cy.wait('@answerapi')
    cy.wait('@lifestyleapi')
     

     this.elementsquestions.lifestylepart()
     this.elements.lifestyle_regular_workout().click()   //lifestyle selection
     this.elements.continue_btn().click()     //continue button
    cy.wait('@answerapi')
    cy.wait('@makeupapi')
     

     this.elementsquestions.makeup()
     this.elements.wear_makeup_occasionally().click()    //makeup wearing selection
    cy.wait('@answerapi')
    cy.wait('@smokeapi')
     

     this.elementsquestions.smoke()
     this.elements.smoke_occasionally().click()      //smoking selection
    cy.wait('@answerapi')
    cy.wait('@productpreferenceapi')
      

     this.elementsquestions.productpreference()
     this.elements.product_preference_vegan().click()      //product preference selection
     this.elements.continue_btn().click()    //continue button
    cy.wait('@answerapi')
     

     this.elements.staying_month_textbox().clear().type('Lahore')     //click on text box
     this.genericwait()
     this.elements.city_selection().click()         //city selection from dropdown
     this.genericwait()
     this.elements.continue_btn().click()     //continue bbutton
    cy.wait('@>20weatherapi')
    

     this.elements.continue_btn().click()     //continue button
    cy.wait('@mp4videoapi')

    this.elements.skipto_results_btn().click()      // skip to results button
    cy.wait('@resultpage')
    cy.wait('@resultonproductpage')
    

}
}

export default CSS_Selecters