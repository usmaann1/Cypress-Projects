/// <reference types = "Cypress"  />
//import { method } from 'cypress/types/bluebird'

import "cypress-localstorage-commands"
import 'cypress-iframe'

import Test_Cases_Methods from '../PageObejects/Assessment-Methods'
import CSS_Selecters from '../PageObejects/Selecters'
const payment = new Test_Cases_Methods()
const wait = new CSS_Selecters()




describe('Verify Payment',function () {

  // Cypress.Cookies.defaults({
  //   preserve: ['token', 'ajs_user_id'],          //Another Method to preserve Cookies for whole tests
  // })


  beforeEach(() => {
    
  // wait.home_login_apis()                          //loading API's here
  // cy.restoreLocalStorage();                       // restoring the local storage from before method
  // Cypress.Cookies.preserveOnce('token')          // preserving token from before method 
  // Cypress.Cookies.preserveOnce('ajs_user_id')    // preserving user_id from before method
  
  
  cy.visit('/') 
  Cypress.on('uncaught:exception', (err, runnable) => {
    // returning false here prevents Cypress from
    // failing the test
    return false
    })
  cy.wait(3000)
  
})


/*
  before(function () {
   cy.clearCookies();                        // removing token from the start
   wait.home_login_apis()                    //loading API's here
  
  cy.visit("/")
  Cypress.on('uncaught:exception', (err, runnable) => {
  // returning false here prevents Cypress from
  // failing the test
  return false
  })
    
  cy.wait('@homebannerapi')
  cy
    .title().should('eq', 'Yours - Personalised Skincare | Swiss-Made | Clean Beauty')
    .get("body > div:nth-child(1) > div:nth-child(1) > div:nth-child(3) > section:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(2) > div:nth-child(5) > button:nth-child(1)").should('be.visible').click()  //analyze button
    cy.wait(3000)
    cy.contains("Let's get personal").should('exist')
    .get("#name").type('Bob')
    .xpath("//button[@id='continue']").click()
    cy.saveLocalStorage();                 //saving the local storage
     
    cy.contains("Hey Bob,").should('exist')
    .get("#email").should('be.visible').type('usmaann1@gmail.com')
    cy.xpath("//button[@id='continue']").should('be.visible').click()
    cy.wait('@guestapi')
    cy.wait('@publishapi')
    cy.wait(3000)
    //need if condition
    cy.get('body').then($body => {
     if ($body.find("#__next > div > div > div > div.util-show-modal.flex.justify-center.items-center > div > div.dont-save-util-container > div > div > p").length > 0) 
      {   //evaluates as true
         cy.get("#__next > div > div > div > div.util-show-modal.flex.justify-center.items-center > div > div.dont-save-util-container > div > div > p").click();
         cy.wait(3000)
      }
  })   
   
})*/

/*

it('Yours Payment Test Case # 74',() => {

  payment.testcase74()
    
})
*/
})
