/// <reference types = "Cypress"  />
//import { method } from 'cypress/types/bluebird'
import "cypress-localstorage-commands"

import Assessment_Methods from '../PageObejects/Assessment-Methods'
import CSS_Selecters from '../PageObejects/Selecters'
const assessment = new Assessment_Methods()
const wait = new CSS_Selecters()




describe('Verify Assessment',
/*{
  retries: {
  runMode: 6,                                  //retries will run the current test agian if our current test fails
  openMode: 6,
  }
},*/ function () {

  // Cypress.Cookies.defaults({
  //   preserve: ['token', 'ajs_user_id'],          //Another Method to preserve Cookies for whole tests
  // })


  beforeEach(() => {
    
  wait.assessment_apis()                         //loading API's here
  cy.restoreLocalStorage();                       // restoring the local storage from before method
  Cypress.Cookies.preserveOnce('token')          // preserving token from before method 
  Cypress.Cookies.preserveOnce('ajs_user_id')    // preserving user_id from before method
  
  
  cy.visit('/assessment') 
  cy.wait(5000)
  cy.get('body').then($body => {
  if ($body.find("#__next > div > div > div > div.util-show-modal.flex.justify-center.items-center > div > div.dont-save-util-container > div > div > p").length > 0) 
   {   //evaluates as true
    cy.get("#__next > div > div > div > div.util-show-modal.flex.justify-center.items-center > div > div.dont-save-util-container > div > div > p").click();
    cy.wait(3000)
   }
   })

  cy.wait('@genderquestionapi')
  Cypress.on('uncaught:exception', (err, runnable) => {
  // returning false here prevents Cypress from
  // failing the test
    return false
  }); 
})



  before(function () {
   cy.clearCookies();                        // removing token from the start
   wait.assessment_apis()                    //loading API's here
  
  cy.visit("/")
  Cypress.on('uncaught:exception', (err, runnable) => {
  // returning false here prevents Cypress from
  // failing the test
  return false
  })
    
  cy.wait('@homebannerapi')
  cy
    .title().should('eq', 'Yours - Personalised Skincare | Swiss-Made | Clean Beauty')
    .get("body > div:nth-child(1) > div:nth-child(1) > div:nth-child(3) > section:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(2) > div:nth-child(5) > button:nth-child(1)").should('be.visible').click()  //analyze button
    cy.wait(3000)
    cy.contains("Let's get personal").should('exist')
    .get("#name").type('Bob')
    .xpath("//button[@id='continue']").click()
    cy.saveLocalStorage();                 //saving the local storage
     
    cy.contains("Hey Bob,").should('exist')
    .get("#email").should('be.visible').type('usmaann1@gmail.com')
    cy.xpath("//button[@id='continue']").should('be.visible').click()
    cy.wait('@guestapi')
    cy.wait('@publishapi')
    cy.wait(3000)
    //need if condition
    cy.get('body').then($body => {
     if ($body.find("#__next > div > div > div > div.util-show-modal.flex.justify-center.items-center > div > div.dont-save-util-container > div > div > p").length > 0) 
      {   //evaluates as true
         cy.get("#__next > div > div > div > div.util-show-modal.flex.justify-center.items-center > div > div.dont-save-util-container > div > div > p").click();
         cy.wait(3000)
      }
  })   
   
})



it('Assessment Test Case # 1',() => {

  assessment.testcase1()
    
})

it('Assessment Test Case # 2', () => {
  assessment.testcase2()
 
})
/*
it('Assessment Test Case # 3', () => {
   
 assessment.testcase3()
 
})

it('Assessment Test Case # 4', () => {
   
  assessment.testcase4()
  
 })

 it('Assessment Test Case # 5', () => {
   
  assessment.testcase5()
  
 })

 it('Assessment Test Case # 6', () => {
   
  assessment.testcase6()
  
 })

 it('Assessment Test Case # 7', () => {
   
  assessment.testcase7()
  
 })

 it('Assessment Test Case # 8', () => {
   
  assessment.testcase8()
  
 })

 it('Assessment Test Case # 9', () => {
   
  assessment.testcase9()
  
 })


 it('Assessment Test Case # 10', () => {
   
  assessment.testcase10()
  
 })

 it('Assessment Test Case # 11', () => {
   
  assessment.testcase11()
  
 })


 it('Assessment Test Case # 12', () => {
   
  assessment.testcase12()
  
 })

 it('Assessment Test Case # 13', () => {
   
  assessment.testcase13()
  
 })


 it('Assessment Test Case # 14', () => {
   
  assessment.testcase14()
  
 })

 it('Assessment Test Case # 15', () => {
   
  assessment.testcase15()
  
 })

 it('Assessment Test Case # 16', () => {
   
  assessment.testcase16()
  
 })

 it('Assessment Test Case # 17', () => {
   
  assessment.testcase17()

 })

 it('Assessment Test Case # 18', () => {
   
  assessment.testcase18()                         
  
 })

 it('Assessment Test Case # 19', () => {
   
  assessment.testcase19()                 
  
 })


 it('Assessment Test Case # 21', () => {
   
  assessment.testcase21()
  
 })

 it('Assessment Test Case # 22', () => {
   
  assessment.testcase22()
  
 })

 it('Assessment Test Case # 23', () => {
   
  assessment.testcase23()
  
 })

 it('Assessment Test Case # 24', () => {
   
  assessment.testcase24()
  
 })

 it('Assessment Test Case # 25', () => {
   
  assessment.testcase25()
  
 })

 it('Assessment Test Case # 26', () => {
   
  assessment.testcase26()
  
 })

 it('Assessment Test Case # 27', () => {
   
  assessment.testcase27()
  
 })

 it('Assessment Test Case # 28', () => {
   
  assessment.testcase28()
  
 })

 it('Assessment Test Case # 29', () => {
   
  assessment.testcase29()
  
 })

 it('Assessment Test Case # 30', () => {
   
  assessment.testcase30()
  
 })

 it('Assessment Test Case # 31', () => {
   
  assessment.testcase31()               
  
 })

 it('Assessment Test Case # 32', () => {
                                           
  assessment.testcase32()
  
 })

 it('Assessment Test Case # 33', () => {
   
  assessment.testcase33()
  
 })

 it('Assessment Test Case # 34', () => {
   
  assessment.testcase34()
  
 })

 it('Assessment Test Case # 35', () => {
   
  assessment.testcase35()
  
 })

 it('Assessment Test Case # 36', () => {
   
  assessment.testcase36()
  
 })

 it('Assessment Test Case # 38', () => {
   
  assessment.testcase38()
  
 })

 it('Assessment Test Case # 39', () => {
   
  assessment.testcase39()
  
 })

 it('Assessment Test Case # 40', () => {
   
  assessment.testcase40()
  
 })

 it('Assessment Test Case # 41', () => {
   
  assessment.testcase41()
  
 })

 it('Assessment Test Case # 42', () => {
   
  assessment.testcase42()
  
 })

 it('Assessment Test Case # 43', () => {
   
  assessment.testcase43()
  
 })

 it('Assessment Test Case # 44', () => {
   
  assessment.testcase44()
  
 })

 it('Assessment Test Case # 45', () => {
   
  assessment.testcase45()
  
 })

 it('Assessment Test Case # 46', () => {
   
  assessment.testcase46()
  
 })

 it('Assessment Test Case # 48', () => {
   
  assessment.testcase48()
  
 })

 it('Assessment Test Case # 49', () => {
   
  assessment.testcase49()
  
 })

 it('Assessment Test Case # 51', () => {
   
  assessment.testcase51()
  
 })

 it('Assessment Test Case # 52', () => {
   
  assessment.testcase52()
  
 })

 it('Assessment Test Case # 54', () => {
   
  assessment.testcase54()
  
 })

 it('Assessment Test Case # 55', () => {
   
  assessment.testcase55()
  
 })

 it('Assessment Test Case # 56', () => {
   
  assessment.testcase56()
  
 })

 it('Assessment Test Case # 57', () => {
   
  assessment.testcase57()
  
 })

 it('Assessment Test Case # 60', () => {
   
  assessment.testcase60()
  
 })

 it('Assessment Test Case # 61', () => {
   
  assessment.testcase61()
  
 })

 it('Assessment Test Case # 63', () => {
   
  assessment.testcase63()
  
 })

 it('Assessment Test Case # 64', () => {
   
  assessment.testcase64()
  
 })

 it('Assessment Test Case # 65', () => {
   
  assessment.testcase65()
  
 })

 it('Assessment Test Case # 66', () => {
   
  assessment.testcase66()
  
 })

 it('Assessment Test Case # 67', () => {
   
  assessment.testcase67()
  
 })

 it('Assessment Test Case # 68', () => {
   
  assessment.testcase68()
  
 })

 it('Assessment Test Case # 69', () => {
   
  assessment.testcase69()
  
 })

 it('Assessment Test Case # 70', () => {
   
  assessment.testcase70()
  
 })

 it('Assessment Test Case # 71', () => {
   
  assessment.testcase71()
  
 })

 it('Assessment Test Case # 72', () => {
   
  assessment.testcase72()
  
 })

 it('Assessment Test Case # 73', () => {
   
  assessment.testcase73()
  
 })*/
})
