/// <reference types = "Cypress"  />
//import { method } from 'cypress/types/bluebird'
import "cypress-localstorage-commands"

import Product_Methods from '../PageObejects/Products-Methods'
import CSS_Selecters from '../PageObejects/Selecters'
const product = new Product_Methods()
const wait = new CSS_Selecters()




describe('Verify Without Sign-in Product Scenarios',function () {
  
 before(function () {
  cy.clearCookies();                        // removing cookies from the start
  wait.assessment_apis()                    //loading API's here
  
  cy.visit("/")
  Cypress.on('uncaught:exception', (err, runnable) => {
  return false
  })
  cy.wait('@homebannerapi')
 })



it('Product Test Case # 1',() => {

  product.testcase1()
    
})

it('Product Test Case # 2',() => {

  product.testcase2()
    
})

it('Product Test Case # 3',() => {

  product.testcase3()
    
})


it('Product Test Case # 5',() => {

  product.testcase5()
    
})


it('Product Test Case # 7',() => {

  product.testcase7()
    
})

it('Product Test Case # 8',() => {

  product.testcase8()
    
})

it('Product Test Case # 9',() => {

  product.testcase9()
    
})

it('Product Test Case # 10',() => {

  product.testcase10()
    
})

it('Product Test Case # 11',() => {

  product.testcase11()
    
})

it('Product Test Case # 13',() => {

  product.testcase13()
    
})

it('Product Test Case # 18',() => {

  product.testcase18()
    
})

it('Product Test Case # 23',() => {

  product.testcase23()
    
})


it('Product Test Case # 25',() => {

  product.testcase25()
    
})

it('Product Test Case # 39',() => {

  product.testcase39()
    
})

it('Product Test Case # 40',() => {

  product.testcase40()
    
})

})



describe('Verify With Sign-in Product Scenarios',function () {

  beforeEach(() => {
    
    wait.assessment_apis()                           //loading API's here
    cy.restoreLocalStorage();                       // restoring the local storage from before method
    Cypress.Cookies.preserveOnce('token')          // preserving token from before method 
    Cypress.Cookies.preserveOnce('ajs_user_id')    // preserving user_id from before method
    
    
    cy.visit('/assessment') 
    cy.wait(5000)
    cy.get('body').then($body => {
    if ($body.find("#__next > div > div > div > div.util-show-modal.flex.justify-center.items-center > div > div.dont-save-util-container > div > div > p").length > 0) 
     {   //evaluates as true
      cy.get("#__next > div > div > div > div.util-show-modal.flex.justify-center.items-center > div > div.dont-save-util-container > div > div > p").click();
      cy.wait(3000)
     }
     })
  
    cy.wait('@genderquestionapi')
    Cypress.on('uncaught:exception', (err, runnable) => {
    return false
    }); 
  })
  
  
  
  before(function () {
    cy.clearCookies();                        // removing token from the start
    wait.assessment_apis()                    //loading API's here
    
    cy.visit("/")
    Cypress.on('uncaught:exception', (err, runnable) => {
    return false
    })
      
    cy.wait('@homebannerapi')
    cy
      .title().should('eq', 'Yours - Personalised Skincare | Swiss-Made | Clean Beauty')
      .get("button[id='#analyse your skin'] span").should('be.visible').click()  //analyze button
      cy.wait(3000)
      cy.contains("Let's get personal").should('exist')
      .get("#name").type('Bob')
      .xpath("//button[@id='continue']").click()
      //cy.saveLocalStorage();                 //saving the local storage
       
      cy.contains("Hey Bob,").should('exist')
      .get("#email").should('be.visible').type('usmaann1@gmail.com')
      cy.xpath("//button[@id='continue']").should('be.visible').click()
      cy.wait('@guestapi')
      cy.wait('@publishapi')
      cy.wait(3000)
      cy.saveLocalStorage();                 //saving the local storage

      //need if condition
      cy.get('body').then($body => {
       if ($body.find("#__next > div > div > div > div.util-show-modal.flex.justify-center.items-center > div > div.dont-save-util-container > div > div > p").length > 0) 
        {   //evaluates as true
           cy.get("#__next > div > div > div > div.util-show-modal.flex.justify-center.items-center > div > div.dont-save-util-container > div > div > p").click();
           cy.wait(3000)
        }
    })   
     
  })



it('Product Test Case # 4',() => {
  cy.clearLocalStorage();
  product.testcase4()
    
})

it('Product Test Case # 6',() => {
  cy.clearLocalStorage();
  product.testcase6()
    
})

it('Product Test Case # 24',() => {
  cy.clearLocalStorage();
  product.testcase24()
    
})


it('Product Test Case # 26',() => {
  cy.clearLocalStorage();
  product.testcase26()
    
})

it('Product Test Case # 27',() => {
  
  product.testcase27()
    
})

it('Product Test Case # 28',() => {        

  product.testcase28()
    
})

it('Product Test Case # 29',() => {
 
  product.testcase29()
    
})

it('Product Test Case # 32',() => {
  
  product.testcase32()
    
})

it('Product Test Case # 33',() => {
  
  product.testcase33()
    
})

it('Product Test Case # 38',() => {

  product.testcase38()
    
})

})